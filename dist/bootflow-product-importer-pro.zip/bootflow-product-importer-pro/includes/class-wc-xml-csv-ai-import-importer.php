<?php
/**
 * Import Engine for processing imports.
 *
 * @since      1.0.0
 * @package    WC_XML_CSV_AI_Import
 * @subpackage WC_XML_CSV_AI_Import/includes
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Import Engine class.
 */
class WC_XML_CSV_AI_Import_Importer {

    /**
     * Field processor instance
     *
     * @var WC_XML_CSV_AI_Import_Processor
     */
    private $processor;

    /**
     * XML parser instance
     *
     * @var WC_XML_CSV_AI_Import_XML_Parser
     */
    private $xml_parser;

    /**
     * CSV parser instance
     *
     * @var WC_XML_CSV_AI_Import_CSV_Parser
     */
    private $csv_parser;

    /**
     * Import configuration
     *
     * @var array
     */
    private $config;

    /**
     * Import ID
     *
     * @var int
     */
    private $import_id;

    /**
     * Current raw product data (for image placeholder parsing)
     *
     * @var array
     */
    private $current_raw_product_data = array();

    /**
     * Current row number for SKU generation
     *
     * @var int
     */
    private $current_row_number = 1;

    /**
     * Flag for CSV variable product mode
     *
     * @var bool
     */
    private $csv_variable_mode = false;

    /**
     * Constructor.
     */
    public function __construct() {
        $this->processor = new WC_XML_CSV_AI_Import_Processor();
        $this->xml_parser = new WC_XML_CSV_AI_Import_XML_Parser();
        $this->csv_parser = new WC_XML_CSV_AI_Import_CSV_Parser();
    }

    /**
     * Start import process.
     *
     * @since    1.0.0
     * @param    array $import_data Import configuration
     * @return   int Import ID
     */
    public function start_import($import_data) {
        global $wpdb;

        try {
            // Validate import data
            $this->validate_import_data($import_data);
            
            // Check if this is updating an existing import or creating new
            $import_id = isset($import_data['import_id']) ? intval($import_data['import_id']) : 0;
            $is_update = ($import_id > 0);
            
            if ($is_update) {
            } else {
            }
            
            // Prepare import filters (PRO-only feature)
            $import_filters = array();
            
            // Only process filters if PRO license is active
            if (WC_XML_CSV_AI_Import_Features::is_available('import_filters')) {
                if (isset($import_data['import_filters']) && is_array($import_data['import_filters'])) {
                    foreach ($import_data['import_filters'] as $filter) {
                        if (!empty($filter['field']) && !empty($filter['operator'])) {
                            // Validate operator is in allowed list (including PRO regex operators)
                            $allowed_operators = array('=', '!=', '>', '<', '>=', '<=', 'contains', 'not_contains', 'empty', 'not_empty', 'regex_match', 'regex_not_match');
                            $operator = in_array($filter['operator'], $allowed_operators) ? $filter['operator'] : '=';
                            
                            $import_filters[] = array(
                                'field' => sanitize_text_field($filter['field']),
                                'operator' => $operator,  // Don't sanitize - use validated value
                                'value' => sanitize_text_field($filter['value'] ?? '')
                            );
                        }
                    }
                }
            }
            // FREE version: $import_filters stays empty, filters are ignored
            
            $import_record = array(
                'name' => sanitize_text_field($import_data['import_name']),
                'file_url' => sanitize_text_field($import_data['file_path']),
                'file_type' => sanitize_text_field($import_data['file_type'] ?? 'xml'),
                'product_wrapper' => sanitize_text_field($import_data['product_wrapper'] ?? 'product'),
                'field_mappings' => json_encode($import_data['field_mapping'] ?? array()),
                'processing_modes' => json_encode($import_data['processing_modes'] ?? array()),
                'processing_configs' => json_encode($import_data['processing_configs'] ?? array()),
                'ai_settings' => json_encode($import_data['ai_settings'] ?? array()),
                'custom_fields' => json_encode($import_data['custom_fields'] ?? array()),
                'schedule_type' => sanitize_text_field($import_data['schedule_type'] ?? 'disabled'),
                'update_existing' => isset($import_data['update_existing']) ? (int)$import_data['update_existing'] : 0,
                'import_filters' => json_encode($import_filters),
                'filter_logic' => sanitize_text_field($import_data['filter_logic'] ?? 'AND'),
                'draft_non_matching' => isset($import_data['draft_non_matching']) ? (int)$import_data['draft_non_matching'] : 0,
                'processed_products' => 0,
                'status' => 'processing'  // Set to processing so progress page kickstarts it
            );
            
            // Count total products - ALWAYS calculate (even for updates/re-runs)
            $total_products = 0;
            if ($import_data['file_type'] === 'xml') {
                // Load XML parser if not already loaded
                if (!class_exists('WC_XML_CSV_AI_Import_XML_Parser')) {
                    require_once WC_XML_CSV_AI_IMPORT_PLUGIN_DIR . 'includes/class-wc-xml-csv-ai-import-xml-parser.php';
                }
                $this->xml_parser = new WC_XML_CSV_AI_Import_XML_Parser();
                $total_products = $this->xml_parser->count_products($import_data['file_path'], $import_data['product_wrapper']);
            } else {
                // Load CSV parser if not already loaded  
                if (!class_exists('WC_XML_CSV_AI_Import_CSV_Parser')) {
                    require_once WC_XML_CSV_AI_IMPORT_PLUGIN_DIR . 'includes/class-wc-xml-csv-ai-import-csv-parser.php';
                }
                $this->csv_parser = new WC_XML_CSV_AI_Import_CSV_Parser();
                $total_products = $this->csv_parser->count_products($import_data['file_path']) - 1; // Subtract header
            }
            $import_record['total_products'] = $total_products;
            
            // Note: No product count limits in any tier (removed in v1.0.0)
            // Both FREE and PRO have unlimited products
            
            if ($is_update) {
                // UPDATE existing import
                $result = $wpdb->update(
                    $wpdb->prefix . 'wc_itp_imports',
                    $import_record,
                    array('id' => $import_id),
                    null,
                    array('%d')
                );
                
                if ($result === false) {
                    $error = $wpdb->last_error;
                    throw new Exception(esc_html__('Failed to update import record: ', 'bootflow-product-importer') . $error);
                }
                
                $this->import_id = $import_id;
            } else {
                // INSERT new import
                $result = $wpdb->insert(
                    $wpdb->prefix . 'wc_itp_imports',
                    $import_record
                );
                
                if ($result === false) {
                    $error = $wpdb->last_error;
                    throw new Exception(esc_html__('Failed to create import record: ', 'bootflow-product-importer') . $error);
                }

                $this->import_id = $wpdb->insert_id;
            }
            
            // Load config from database to ensure proper format
            $this->load_import_config($this->import_id);

            // translators: %1$s is the import name, %2$d is the number of products
            // Log import start
            // translators: %1$s is a string, %2$d is a number
            $this->log('info', sprintf(__('Import "%1$s" started with %2$d products.', 'bootflow-product-importer'), $import_record['name'], $total_products));

            // Return import ID - processing will be kickstarted by progress page
            return $this->import_id;

        } catch (Exception $e) {
            if (isset($this->import_id)) {
                $this->log('error', $e->getMessage());
                $this->update_import_status('failed');
            }
            throw $e;
        }
    }

    /**
     * Load import configuration from database.
     *
     * @since    1.0.0
     * @param    int $import_id Import ID
     */
    private function load_import_config($import_id) {
        global $wpdb;

        $import = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}wc_itp_imports WHERE id = %d",
            $import_id
        ));

        if (!$import) {
            throw new Exception(esc_html__('Import not found.', 'bootflow-product-importer'));
        }

        $this->import_id = $import_id;
        
        $field_mappings = json_decode($import->field_mappings, true) ?: array();
        
        // Extract custom fields from field_mappings (they are saved with '_custom_' prefix)
        $custom_fields = array();
        foreach ($field_mappings as $key => $mapping) {
            if (strpos($key, '_custom_') === 0) {
                $custom_fields[] = $mapping;
            }
        }
        // Also check the dedicated custom_fields column for backwards compatibility
        $legacy_custom_fields = json_decode($import->custom_fields ?? '[]', true) ?: array();
        if (!empty($legacy_custom_fields) && empty($custom_fields)) {
            $custom_fields = $legacy_custom_fields;
        }
        
        $this->config = array(
            'file_path' => $import->file_path ?: $import->file_url,  // Fallback to file_url if file_path is NULL
            'file_type' => $import->file_type ?? 'xml',
            'product_wrapper' => $import->product_wrapper,
            'field_mapping' => $field_mappings,
            'processing_modes' => json_decode($import->processing_modes ?? '[]', true) ?: array(),
            'processing_configs' => json_decode($import->processing_configs ?? '[]', true) ?: array(),
            'custom_fields' => $custom_fields,
            'import_filters' => json_decode($import->import_filters ?? '[]', true) ?: array(),
            'filter_logic' => $import->filter_logic ?? 'AND',
            'draft_non_matching' => isset($import->draft_non_matching) ? (int)$import->draft_non_matching : 0,
            'schedule_type' => $import->schedule_type,
            'update_existing' => $import->update_existing ?? '0',
            'handle_missing' => isset($import->handle_missing) ? (int)$import->handle_missing : 0,
            'missing_action' => $import->missing_action ?? 'draft',
            'delete_variations' => isset($import->delete_variations) ? (int)$import->delete_variations : 1
        );
        
        if (isset($this->config['field_mapping']['name'])) {
        }
        // Debug sale_price mapping specifically
        if (isset($this->config['field_mapping']['sale_price'])) {
        } else {
        }
        // Debug loaded config
    }

    /**
     * Process import chunk.
     *
     * @since    1.0.0
     * @param    int $offset Starting position
     * @param    int $limit Number of products to process
     * @param    int $import_id Import ID (optional, for cron jobs)
     * @return   array Processing result
     */
    public function process_import_chunk($offset, $limit, $import_id = null) {
        // Ensure offset and limit are integers
        $offset = intval($offset);
        $limit = intval($limit);
        
        global $wpdb;

        try {
            // Load config if import_id provided (for cron jobs)
            if ($import_id && empty($this->config)) {
                $this->load_import_config($import_id);
            }
            
            // CHECK KILL FLAG FIRST - stop immediately if killed
            $kill_flag_specific = WC_XML_CSV_AI_IMPORT_PLUGIN_DIR . 'IMPORT_KILLED_' . $this->import_id . '.flag';
            $kill_flag_global = WC_XML_CSV_AI_IMPORT_PLUGIN_DIR . 'IMPORT_KILLED.flag';
            if (file_exists($kill_flag_specific) || file_exists($kill_flag_global)) {
                // Delete specific flag after detecting it
                if (file_exists($kill_flag_specific)) {
                    @unlink($kill_flag_specific);
                }
                // Only delete global flag if it's for this import
                if (file_exists($kill_flag_global)) {
                    $global_content = file_get_contents($kill_flag_global);
                    if (strpos($global_content, $this->import_id . ':') === 0) {
                        @unlink($kill_flag_global);
                    }
                }
                return array(
                    'processed' => 0,
                    'errors' => array(),
                    'total_processed' => 0,
                    'total_products' => 0,
                    'completed' => false,
                    'stopped' => true,
                    'message' => 'Import killed by user'
                );
            }
            
            // CRITICAL: Use transient lock to prevent parallel execution
            $lock_key = 'wc_import_lock_' . $this->import_id;
            $lock_time_key = 'wc_import_lock_time_' . $this->import_id;
            $lock_value = get_transient($lock_key);
            $lock_time = get_transient($lock_time_key);
            
            if ($lock_value !== false) {
                // Check if lock is stale (older than 3 minutes = likely timed out process)
                $lock_age = $lock_time ? (time() - intval($lock_time)) : 999;
                if ($lock_age < 180) {
                    // Another process is still working on this import (lock is fresh)
                    return array(
                        'processed' => 0,
                        'errors' => array(),
                        'total_processed' => 0,
                        'total_products' => 0,
                        'completed' => false,
                        'locked' => true
                    );
                } else {
                    // Lock is stale - likely previous process timed out
                    delete_transient($lock_key);
                    delete_transient($lock_time_key);
                }
            }
            
            // Set lock with unique value and 5 minute expiry + timestamp
            $my_lock = uniqid('lock_', true);
            set_transient($lock_key, $my_lock, 300);
            set_transient($lock_time_key, time(), 300);
            
            // Verify we got the lock (race condition check)
            if (get_transient($lock_key) !== $my_lock) {
                return array(
                    'processed' => 0,
                    'errors' => array(),
                    'total_processed' => 0,
                    'total_products' => 0,
                    'completed' => false,
                    'locked' => true
                );
            }
            
            
            // CRITICAL: Check if this chunk was already processed (prevent double processing)
            $current_import = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}wc_itp_imports WHERE id = %d",
                $this->import_id
            ));
            
            
            if ($current_import) {
                // If import already completed, skip
                if ($current_import->status === 'completed') {
                    delete_transient($lock_key); // Release lock
                    delete_transient($lock_time_key);
                    return array(
                        'processed' => 0,
                        'errors' => array(),
                        'total_processed' => $current_import->processed_products,
                        'total_products' => $current_import->total_products,
                        'completed' => true,
                        'skipped' => true
                    );
                }
                
                // If import is stopped (failed) or paused, abort
                if ($current_import->status === 'failed' || $current_import->status === 'paused') {
                    delete_transient($lock_key); // Release lock
                    delete_transient($lock_time_key);
                    return array(
                        'processed' => 0,
                        'errors' => array(),
                        'total_processed' => $current_import->processed_products,
                        'total_products' => $current_import->total_products,
                        'completed' => false,
                        'stopped' => ($current_import->status === 'failed'),
                        'paused' => ($current_import->status === 'paused')
                    );
                }
                
                // If offset is 0 but already processed some products, skip (prevent restart from beginning)
                $already_processed = intval($current_import->processed_products);
                if ($offset == 0 && $already_processed > 0) {
                    delete_transient($lock_key); // Release lock
                    delete_transient($lock_time_key);
                    return array(
                        'processed' => 0,
                        'errors' => array(),
                        'total_processed' => $already_processed,
                        'total_products' => $current_import->total_products,
                        'completed' => $already_processed >= intval($current_import->total_products),
                        'skipped' => true
                    );
                }
                
                // CRITICAL FIX: Skip if this offset was already processed
                // This prevents double-processing when AJAX and Cron both try to process same offset
                // The correct check is: if we've already processed past this offset, skip it
                if ($offset > 0 && $already_processed > $offset) {
                    delete_transient($lock_key); // Release lock
                    delete_transient($lock_time_key);
                    return array(
                        'processed' => 0,
                        'errors' => array(),
                        'total_processed' => $already_processed,
                        'total_products' => $current_import->total_products,
                        'completed' => $already_processed >= intval($current_import->total_products),
                        'skipped' => true
                    );
                }
            }
            
            // CRITICAL FIX: Save import start time when first chunk begins
            // This is used by handle_missing_products() to correctly identify products not updated in THIS run
            $import_start_option_key = 'wc_import_start_time_' . $this->import_id;
            if ($offset == 0 && intval($current_import->processed_products ?? 0) == 0) {
                update_option($import_start_option_key, current_time('mysql'), false);
            }
            
            $this->update_import_status('processing');

            // Extract products from file - determine type by file_type config
            if (isset($this->config['file_type']) && $this->config['file_type'] === 'csv') {
                
                // Check if CSV has variable products (grouped by parent SKU)
                $attributes_config = $this->config['field_mapping']['attributes_variations'] ?? array();
                $product_mode = $attributes_config['product_mode'] ?? 'simple';
                $csv_var_config = $attributes_config['csv_variation_config'] ?? array();
                
                if ($product_mode === 'variable' && !empty($csv_var_config['parent_sku_column'])) {
                    // CSV Variable Products Mode - extract grouped by parent
                    $grouped_result = $this->csv_parser->extract_products_grouped(
                        $this->config['file_path'],
                        $csv_var_config['parent_sku_column'],
                        $csv_var_config['type_column'] ?? '',
                        $offset,
                        $limit
                    );
                    $products = $grouped_result['products'] ?? array();
                    
                    // Update total_products to reflect grouped count (not row count)
                    $grouped_total = $grouped_result['total'] ?? 0;
                    if ($grouped_total > 0 && $offset == 0) {
                        // Only update on first chunk to avoid race conditions
                        $wpdb->update(
                            $wpdb->prefix . 'wc_itp_imports',
                            array('total_products' => $grouped_total),
                            array('id' => $this->import_id)
                        );
                    }
                    
                    // Mark that we're in CSV variable mode for import_single_product
                    $this->csv_variable_mode = true;
                } else {
                    // Standard CSV mode - each row is a product
                    $this->csv_variable_mode = false;
                    $products = $this->csv_parser->extract_products(
                        $this->config['file_path'],
                        $offset,
                        $limit
                    );
                }
            } else {
                $this->csv_variable_mode = false;
                $products = $this->xml_parser->extract_products(
                    $this->config['file_path'],
                    $this->config['product_wrapper'],
                    $offset,
                    $limit
                );
            }

            $processed_count = 0;
            $errors = array();
            $lock_key = 'wc_import_lock_' . $this->import_id;

            
            // Note: No product count limits in any tier (removed in v1.0.0)
            // Both FREE and PRO have unlimited products
            
            foreach ($products as $index => $product_data) {
                // Check if import was stopped/paused between products
                $current_status = $wpdb->get_var($wpdb->prepare(
                    "SELECT status FROM {$wpdb->prefix}wc_itp_imports WHERE id = %d",
                    $this->import_id
                ));
                
                if ($current_status === 'failed' || $current_status === 'paused') {
                    delete_transient($lock_key);
                    delete_transient($lock_time_key);
                    
                    // Update processed count before stopping
                    if ($processed_count > 0) {
                        $wpdb->query($wpdb->prepare(
                            "UPDATE {$wpdb->prefix}wc_itp_imports SET processed_products = processed_products + %d WHERE id = %d",
                            $processed_count,
                            $this->import_id
                        ));
                    }
                    
                    return array(
                        'processed' => $processed_count,
                        'errors' => $errors,
                        'total_processed' => 0,
                        'total_products' => 0,
                        'completed' => false,
                        'stopped' => ($current_status === 'failed'),
                        'paused' => ($current_status === 'paused')
                    );
                }
                
                try {
                    // Set current row number for SKU generation
                    $this->current_row_number = $offset + $index + 1;
                    $this->import_single_product($product_data);
                } catch (Exception $e) {
                    $errors[] = $e->getMessage();
                    $this->log('error', $e->getMessage(), isset($product_data['sku']) ? $product_data['sku'] : '');
                }
                // Always increment processed count (both success and skip/error)
                $processed_count++;
            }

            // Update processed count using atomic SQL (prevents race conditions)
            $wpdb->query($wpdb->prepare(
                "UPDATE {$wpdb->prefix}wc_itp_imports SET processed_products = processed_products + %d, last_run = %s WHERE id = %d",
                $processed_count,
                current_time('mysql'),
                $this->import_id
            ));

            // Check if import is complete or stopped
            $import = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}wc_itp_imports WHERE id = %d",
                $this->import_id
            ));

            // Release lock
            $lock_key = 'wc_import_lock_' . $this->import_id;
            $lock_time_key = 'wc_import_lock_time_' . $this->import_id;
            delete_transient($lock_key);
            delete_transient($lock_time_key);

            // Check if stopped or paused - don't schedule next chunk
            if ($import->status === 'failed' || $import->status === 'paused') {
                return array(
                    'processed' => $processed_count,
                    'errors' => $errors,
                    'total_processed' => $import->processed_products,
                    'total_products' => $import->total_products,
                    'completed' => false,
                    'stopped' => ($import->status === 'failed'),
                    'paused' => ($import->status === 'paused')
                );
            }

            if ($import->processed_products >= $import->total_products) {
                // Safety check: don't mark as completed if total_products is NULL or 0 (invalid)
                if (empty($import->total_products) || intval($import->total_products) <= 0) {
                    // Don't mark as completed, just return current state
                    return array(
                        'processed' => $processed_count,
                        'errors' => array('total_products is not set - import configuration error'),
                        'total_processed' => $import->processed_products,
                        'total_products' => 0,
                        'completed' => false
                    );
                }
                
                // Handle missing products before marking as completed
                if (!empty($this->config['handle_missing'])) {
                    $this->handle_missing_products();
                }
                
                // Phase 2: Resolve product relationships (grouped children, upsells, cross-sells)
                $this->resolve_product_relationships();
                
                // Phase 3: Final stock status sync for all variable products
                // This must happen LAST to avoid any WooCommerce hooks overriding our stock status
                // Schedule it on shutdown to ensure all WooCommerce hooks have completed
                add_action('shutdown', array($this, 'sync_variable_products_stock_status'), 999);
                
                $this->update_import_status('completed');
                // translators: %d is the number of processed products
                $this->log('info', sprintf(__('Import completed successfully. Processed %d products.', 'bootflow-product-importer'), $import->processed_products));
            } else {
                // Schedule next chunk automatically to prevent hanging
                // This ensures continuous processing even if AJAX times out
                // Use processed_products from DB as next offset (more accurate than offset + limit)
                $next_offset = intval($import->processed_products);
                $this->schedule_next_chunk($next_offset, $limit);
            }

            return array(
                'processed' => $processed_count,
                'errors' => $errors,
                'total_processed' => $import->processed_products,
                'total_products' => $import->total_products,
                'completed' => $import->processed_products >= $import->total_products
            );

        } catch (Exception $e) {
            // Release lock on error
            $lock_key = 'wc_import_lock_' . $this->import_id;
            $lock_time_key = 'wc_import_lock_time_' . $this->import_id;
            delete_transient($lock_key);
            delete_transient($lock_time_key);
            
            $this->log('error', $e->getMessage());
            $this->update_import_status('failed');
            throw $e;
        } catch (Throwable $e) {
            // Release lock on any error (including TypeError, Error, etc.)
            $lock_key = 'wc_import_lock_' . $this->import_id;
            $lock_time_key = 'wc_import_lock_time_' . $this->import_id;
            delete_transient($lock_key);
            delete_transient($lock_time_key);
            
            $this->log('error', $e->getMessage());
            $this->update_import_status('failed');
            throw $e;
        }
    }

    /**
     * Import single product.
     *
     * @since    1.0.0
     * @param    array $product_data Raw product data
     * @return   int Product ID
     */
    private function import_single_product($product_data) {
        try {
            
            // Check if this is a grouped CSV product (parent + variations)
            if (!empty($this->csv_variable_mode) && isset($product_data['type']) && $product_data['type'] === 'variable') {
                return $this->import_csv_variable_product($product_data);
            }
            
            
            // For grouped products, extract the actual data
            if (isset($product_data['data']) && is_array($product_data['data'])) {
                $product_data = $product_data['data'];
            }
            
            // Store raw product data for image placeholder parsing
            $this->current_raw_product_data = $product_data;
            
            // DEBUG: Log raw product data keys
            $image_keys = array_filter(array_keys($product_data), function($key) {
                return strpos($key, 'image') !== false;
            });
            $this->log('debug', 'Raw product data image keys: ' . implode(', ', $image_keys));
            
            // Check import filters BEFORE processing
            $passes_filters = $this->passes_import_filters($product_data);
            $force_status = null;
            
            if (!$passes_filters) {
                $sku = $product_data['sku'] ?? $product_data['id'] ?? 'Unknown';
                
                // If draft_non_matching is enabled, import as Draft instead of skipping
                if (!empty($this->config['draft_non_matching'])) {
                    $force_status = 'draft';
                    // translators: %s is the product SKU
                    $this->log('info', sprintf(__('Product does not match filters - will be imported as Draft (SKU: %s)', 'bootflow-product-importer'), $sku));
                } else {
                    // Skip product if checkbox not enabled
                    // translators: %s is the product SKU
                    $this->log('info', sprintf(__('Product skipped by import filters (SKU: %s)', 'bootflow-product-importer'), $sku));
                    return;
                }
            } else {
                // Product passes filters
                if (!empty($this->config['draft_non_matching'])) {
                    // When draft_non_matching is enabled, products that pass filters should be published
                    $force_status = 'publish';
                    $sku = $product_data['sku'] ?? $product_data['id'] ?? 'Unknown';
                    // translators: %s is the product SKU
                    $this->log('info', sprintf(__('Product matches filters - will be imported as Published (SKU: %s)', 'bootflow-product-importer'), $sku));
                }
            }
            
            // Map raw data to WooCommerce fields
            if (defined('WP_DEBUG') && WP_DEBUG) { error_log('[IMPORT_PROCESS] About to map product fields'); }
            $mapped_data = $this->map_product_fields($product_data);
            if (defined('WP_DEBUG') && WP_DEBUG) { error_log('[IMPORT_PROCESS] Mapped data keys: ' . json_encode(array_keys($mapped_data))); }

            // Check if product already exists BEFORE processing fields
            // This allows us to skip expensive AI/formula processing for fields that won't be updated
            $existing_product_id = null;
            if (!empty($mapped_data['sku'])) {
                $existing_product_id = wc_get_product_id_by_sku($mapped_data['sku']);
            }
            $is_existing_product = !empty($existing_product_id);

            // Get update_existing and skip_unchanged settings from import record (cached per import)
            global $wpdb;
            if (!isset($this->_cached_import_settings)) {
                $this->_cached_import_settings = $wpdb->get_row($wpdb->prepare("SELECT update_existing, skip_unchanged FROM {$wpdb->prefix}wc_itp_imports WHERE id = %d", $this->import_id), ARRAY_A);
            }
            $import_record = $this->_cached_import_settings;
            $update_existing = ($import_record && $import_record['update_existing'] === '1') ? true : false;
            $skip_unchanged = ($import_record && $import_record['skip_unchanged'] === '1') ? true : false;

            // ─── FAST SYNC PATH ────────────────────────────────────────────────
            // When an existing product only needs simple meta fields synced (price, qty, stock_status),
            // bypass the entire WooCommerce product load/save pipeline and do direct DB updates.
            // This reduces ~20 DB queries per product down to ~3-5.
            if ($is_existing_product && $update_existing) {
                $fast_sync_result = $this->try_fast_sync($existing_product_id, $mapped_data, $product_data, $skip_unchanged);
                if ($fast_sync_result !== false) {
                    return $fast_sync_result;
                }
            }
            // ─── END FAST SYNC PATH ────────────────────────────────────────────

            // Process fields through configured processors
            // Pass existing_product_id to skip expensive processing for fields with update_on_sync=0
            if (defined('WP_DEBUG') && WP_DEBUG) { error_log('[IMPORT_PROCESS] About to process product fields (existing: ' . ($is_existing_product ? 'YES' : 'NO') . ')'); }
            $processed_data = $this->process_product_fields($mapped_data, $product_data, $existing_product_id);
            if (defined('WP_DEBUG') && WP_DEBUG) { error_log('[IMPORT_PROCESS] Processed data keys: ' . json_encode(array_keys($processed_data))); }
            
            // Apply Pricing Engine rules to calculate final price
            if (defined('WP_DEBUG') && WP_DEBUG) { error_log('[IMPORT_PROCESS] About to apply Pricing Engine'); }
            $processed_data = $this->apply_pricing_engine($processed_data, $product_data);
            if (defined('WP_DEBUG') && WP_DEBUG) { error_log('[IMPORT_PROCESS] After Pricing Engine - regular_price: ' . ($processed_data['regular_price'] ?? 'NOT SET')); }
            
            // Force status based on filter result (when draft_non_matching is enabled)
            if ($force_status !== null) {
                $processed_data['status'] = $force_status;
            }

            // Validate required fields (name only required for new products)
            $this->validate_product_data($processed_data, $existing_product_id);

            if ($existing_product_id && !$update_existing) {
                // translators: placeholder values
                throw new Exception(sprintf(esc_html__('Product with SKU "%s" already exists and update is disabled.', 'bootflow-product-importer'), esc_html($processed_data['sku'])));
            }

            // Create or update product
            if ($existing_product_id && $update_existing) {
                // Check if we should skip unchanged products
                if ($skip_unchanged && !$this->has_product_data_changed($existing_product_id, $processed_data)) {
                    // CRITICAL: Still update import tracking even for unchanged products!
                    // handle_missing_products() uses _wc_import_date to identify products in the feed.
                    // Without this, skipped products get incorrectly treated as "missing" and moved to draft.
                    update_post_meta($existing_product_id, '_wc_import_id', $this->import_id);
                    update_post_meta($existing_product_id, '_wc_import_date', current_time('mysql'));

                    $product_name = !empty($processed_data['name']) ? $processed_data['name'] : 'Product';
                    // translators: %1$s is the product name, %2$d is the product ID
                    $this->log('info', sprintf(__('Skipped product (unchanged): %1$s (ID: %2$d)', 'bootflow-product-importer'), $product_name, $existing_product_id), esc_html($processed_data['sku']));
                    return $existing_product_id; // Return existing ID without updating
                }
                
                // Store raw product data for Shipping Class Engine (variable products need variation prices)
                $this->_current_raw_product_data = $product_data;
                $product_id = $this->update_product($existing_product_id, $processed_data, $mapped_data);
                $product_name = !empty($processed_data['name']) ? $processed_data['name'] : 'Product';
                // translators: %1$s is the product name, %2$d is the product ID
                $this->log('info', sprintf(__('Updated product: %1$s (ID: %2$d)', 'bootflow-product-importer'), $product_name, $product_id), esc_html($processed_data['sku']));
            } else {
                // Store raw product data for Shipping Class Engine (variable products need variation prices)
                $this->_current_raw_product_data = $product_data;
                $product_id = $this->create_product($processed_data, $mapped_data);
                $product_name = !empty($processed_data['name']) ? $processed_data['name'] : 'Product';
                // translators: %1$s is the product name, %2$d is the product ID
                $this->log('info', sprintf(__('Created product: %1$s (ID: %2$d)', 'bootflow-product-importer'), $product_name, $product_id), esc_html($processed_data['sku']));
            }

            // Process custom fields
            $this->process_custom_fields($product_id, $product_data);

            // Process attributes & variations
            
            // DEBUG: Log if product_data has variations
            $attr_debug_file = WP_CONTENT_DIR . '/product_data_debug.log';
            if (defined('WP_DEBUG') && WP_DEBUG) {
                $product_name = $processed_data['name'] ?? 'Unknown';
                
                if (isset($product_data['variations'])) {
                    if (is_array($product_data['variations'])) {
                        if (isset($product_data['variations']['variation'])) {
                            if (is_array($product_data['variations']['variation'])) {
                                $varCount = isset($product_data['variations']['variation'][0]) ? count($product_data['variations']['variation']) : 1;
                            }
                        } else {
                        }
                    }
                } else {
                }
            }
            
            $this->process_product_attributes($product_id, $product_data);

            // CRITICAL SAFETY CHECK: Ensure variable products without variations are converted to simple
            // This catches cases where type=variable is set but no variations exist in source data
            // IMPORTANT: Clear cache first so we get fresh data after variations were created
            // Note: Do NOT use wc_delete_product_transients() here as it can trigger hooks that reset stock status
            wp_cache_delete($product_id, 'post_meta');
            clean_post_cache($product_id);
            $final_product = wc_get_product($product_id);
            if ($final_product && $final_product->is_type('variable')) {
                // Use direct database query instead of get_children() which can be cached
                $variation_count = (int) $GLOBALS['wpdb']->get_var($GLOBALS['wpdb']->prepare(
                    "SELECT COUNT(*) FROM {$GLOBALS['wpdb']->posts} WHERE post_parent = %d AND post_type = 'product_variation' AND post_status = 'publish'",
                    $product_id
                ));
                if ($variation_count === 0) {
                    wp_set_object_terms($product_id, 'simple', 'product_type');
                    // Ensure stock status is set correctly
                    $stock_status = get_post_meta($product_id, '_stock_status', true);
                    if (empty($stock_status) || $stock_status === 'outofstock') {
                        update_post_meta($product_id, '_stock_status', 'instock');
                    }
                    // Clear WooCommerce product cache to reflect the change
                    wc_delete_product_transients($product_id);
                } else {
                    // FINAL STOCK STATUS FIX: Variable product with variations - ensure stock status is synced
                    // WooCommerce sync can sometimes override our stock status, so we force it one final time
                    // Use direct DB query to avoid caching issues with get_posts()
                    global $wpdb;
                    $children = $wpdb->get_col($wpdb->prepare(
                        "SELECT ID FROM {$wpdb->posts} WHERE post_parent = %d AND post_type = 'product_variation'",
                        $product_id
                    ));
                    $has_stock = false;
                    if (!empty($children)) {
                        // Check if any variation has instock status via direct DB query
                        $placeholders = implode(',', array_fill(0, count($children), '%d'));
                        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Placeholders dynamically built for IN clause
                        $instock_count = (int) $wpdb->get_var($wpdb->prepare(
                            "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE post_id IN ({$placeholders}) AND meta_key = '_stock_status' AND meta_value = 'instock'",
                            array_map('intval', $children)
                        ));
                        $has_stock = ($instock_count > 0);
                    }
                    $final_stock_status = $has_stock ? 'instock' : 'outofstock';
                    
                    // Use direct DB update to bypass any WooCommerce hooks
                    $wpdb->update(
                        $wpdb->postmeta,
                        array('meta_value' => $final_stock_status),
                        array('post_id' => $product_id, 'meta_key' => '_stock_status'),
                        array('%s'),
                        array('%d', '%s')
                    );
                    // Also update object cache
                    wp_cache_delete($product_id, 'post_meta');
                }
            }

            return $product_id;

        } catch (Exception $e) {
            // translators: %s is the error message
            throw new Exception(sprintf(esc_html__('Error importing product: %s', 'bootflow-product-importer'), esc_html($e->getMessage())));
        }
    }

    /**
     * Import CSV variable product (parent + variations from grouped data).
     *
     * @since    1.0.0
     * @param    array $grouped_data Grouped product data with 'data' (parent) and 'variations' array
     * @return   int Product ID
     */
    private function import_csv_variable_product($grouped_data) {
        $log_file = WP_CONTENT_DIR . '/csv_variable_import.log';
        
        $parent_data = $grouped_data['data'] ?? array();
        $variations = $grouped_data['variations'] ?? array();
        $synthetic_parent = !empty($grouped_data['synthetic_parent']);
        
        
        // Store raw product data
        $this->current_raw_product_data = $parent_data;
        
        // Get CSV variation config
        $attributes_config = $this->config['field_mapping']['attributes_variations'] ?? array();
        $csv_var_config = $attributes_config['csv_variation_config'] ?? array();
        $csv_attributes = $csv_var_config['attributes'] ?? array();
        $csv_fields = $csv_var_config['fields'] ?? array();
        
        
        // Map parent data to WooCommerce fields
        $mapped_data = $this->map_product_fields($parent_data);
        
        // Check if parent exists BEFORE processing (to skip AI for update_on_sync=0 fields)
        $existing_product_id = null;
        $parent_sku_column = $csv_var_config['parent_sku_column'] ?? 'Parent SKU';
        $check_sku = $mapped_data['sku'] ?? ($parent_data[$parent_sku_column] ?? null);
        if (!empty($check_sku)) {
            $existing_product_id = wc_get_product_id_by_sku($check_sku);
        }
        
        // Process fields - pass existing_product_id to skip AI for update_on_sync=0 fields
        $processed_data = $this->process_product_fields($mapped_data, $parent_data, $existing_product_id);
        
        // Apply Pricing Engine rules to calculate final price
        $processed_data = $this->apply_pricing_engine($processed_data, $parent_data);
        
        // For CSV variable products: if SKU is empty, use Parent SKU as the product SKU
        if (empty($processed_data['sku']) && !empty($parent_data[$parent_sku_column])) {
            $processed_data['sku'] = $parent_data[$parent_sku_column];
        }
        
        // Get update settings
        global $wpdb;
        $import_record = $wpdb->get_row($wpdb->prepare("SELECT update_existing FROM {$wpdb->prefix}wc_itp_imports WHERE id = %d", $this->import_id), ARRAY_A);
        $update_existing = ($import_record && $import_record['update_existing'] === '1') ? true : false;
        
        // IMPORTANT: Remove stock_status from processed_data for variable products
        // Variable products should NOT have their own stock_status - it's calculated from variations
        // If we set it here, create_product() will overwrite it and cause "out of stock" issue
        unset($processed_data['stock_status']);
        unset($processed_data['stock_quantity']);
        unset($processed_data['manage_stock']);
        
        // Create or update parent product
        // Store raw product data for Shipping Class Engine (Format A parent)
        $this->_current_raw_product_data = $parent_data;
        if ($existing_product_id && $update_existing) {
            $product_id = $this->update_product($existing_product_id, $processed_data, $mapped_data);
        } else if ($existing_product_id && !$update_existing) {
            // translators: placeholder values
            throw new Exception(sprintf(esc_html__('Product with SKU "%s" already exists and update is disabled.', 'bootflow-product-importer'), esc_html($processed_data['sku'])));
        } else {
            $product_id = $this->create_product($processed_data, $mapped_data);
        }
        
        // Convert to variable product type
        wp_set_object_terms($product_id, 'variable', 'product_type');
        
        // Collect all attribute values from variations
        $all_attribute_values = array();
        foreach ($csv_attributes as $attr_config) {
            $attr_name = $attr_config['name'] ?? '';
            $source_column = $attr_config['source'] ?? '';
            if (empty($attr_name) || empty($source_column)) continue;
            
            $all_attribute_values[$attr_name] = array(
                'source' => $source_column,
                'values' => array()
            );
        }
        
        // Collect unique values from all variations
        foreach ($variations as $var_data) {
            foreach ($all_attribute_values as $attr_name => &$attr_info) {
                $value = $var_data[$attr_info['source']] ?? '';
                if (!empty($value) && !in_array($value, $attr_info['values'])) {
                    $attr_info['values'][] = $value;
                }
            }
            unset($attr_info); // Break reference to prevent PHP foreach reference bug
        }
        unset($attr_info); // Ensure reference is fully broken before next foreach
        
        
        // Create product attributes
        $product_attributes = array();
        $attr_position = 0;
        
        foreach ($all_attribute_values as $attr_name => $attr_info) {
            if (empty($attr_info['values'])) continue;
            
            // Sanitize attribute name for taxonomy
            $taxonomy_name = 'pa_' . sanitize_title($attr_name);
            
            // Register taxonomy
            $this->register_attribute_taxonomy($taxonomy_name, $attr_name);
            
            // Create terms
            $term_ids = array();
            foreach ($attr_info['values'] as $value) {
                $term_result = $this->get_or_create_attribute_term($value, $taxonomy_name);
                if ($term_result && isset($term_result->term_id)) {
                    $term_ids[] = $term_result->term_id;
                }
            }
            
            // Set terms to product
            wp_set_object_terms($product_id, $term_ids, $taxonomy_name);
            
            // Add to product attributes
            $product_attributes[$taxonomy_name] = array(
                'name' => $taxonomy_name,
                'value' => '',
                'position' => $attr_position++,
                'is_visible' => 1,
                'is_variation' => 1,
                'is_taxonomy' => 1
            );
            
        }
        
        // Save attributes to parent product
        update_post_meta($product_id, '_product_attributes', $product_attributes);
        
        // Delete existing variations
        $existing_variations = get_posts(array(
            'post_type' => 'product_variation',
            'post_parent' => $product_id,
            'posts_per_page' => -1,
            'fields' => 'ids'
        ));
        foreach ($existing_variations as $var_id) {
            wp_delete_post($var_id, true);
        }
        
        // Create variations from CSV rows
        $variation_count = 0;
        foreach ($variations as $var_index => $var_data) {
            // Debug: Log variation data
            
            // Set variation attributes
            $var_attributes = array();
            foreach ($all_attribute_values as $attr_name => $attr_info) {
                $source_col = $attr_info['source'];
                $value = $var_data[$source_col] ?? '';
                if (!empty($value)) {
                    $taxonomy_name = 'pa_' . sanitize_title($attr_name);
                    $var_attributes[$taxonomy_name] = sanitize_title($value);
                }
            }
            
            // Set variation fields from CSV
            $var_sku = $var_data[$csv_fields['sku'] ?? 'SKU'] ?? '';
            
            // Check if variation with this SKU already exists (for update scenario)
            $existing_variation_id = null;
            if (!empty($var_sku)) {
                $existing_variation_id = wc_get_product_id_by_sku($var_sku);
                if ($existing_variation_id) {
                    // Found existing variation - load it instead of creating new
                    $existing_product = wc_get_product($existing_variation_id);
                    if ($existing_product && $existing_product->is_type('variation')) {
                        // Update parent to new product and update variation
                        $variation = $existing_product;
                        $variation->set_parent_id($product_id);
                    } else {
                        // SKU exists but not a variation - skip with warning
                        continue;
                    }
                } else {
                    $variation = new WC_Product_Variation();
                    $variation->set_parent_id($product_id);
                }
            } else {
                $variation = new WC_Product_Variation();
                $variation->set_parent_id($product_id);
            }
            
            $variation->set_attributes($var_attributes);
            
            if (!empty($var_sku)) {
                $variation->set_sku($var_sku);
            }
            
            $var_price = $var_data[$csv_fields['regular_price'] ?? 'Price'] ?? '';
            if (!empty($var_price) && is_numeric($var_price)) {
                // Apply Pricing Engine to variation price
                $var_price = $this->apply_pricing_engine_to_price(floatval($var_price), $var_data);
                $variation->set_regular_price($var_price);
            }
            
            $var_sale_price = $var_data[$csv_fields['sale_price'] ?? 'Sale Price'] ?? '';
            if (!empty($var_sale_price) && is_numeric($var_sale_price)) {
                $variation->set_sale_price($var_sale_price);
            }
            
            // Handle stock management properly
            $var_stock_qty = $var_data[$csv_fields['stock_quantity'] ?? 'Stock Quantity'] ?? '';
            $var_stock_status = $var_data[$csv_fields['stock_status'] ?? 'Stock Status'] ?? '';
            $var_manage_stock = $var_data[$csv_fields['manage_stock'] ?? 'Manage Stock'] ?? '';
            
            // Normalize manage_stock value
            $should_manage_stock = in_array(strtolower(trim($var_manage_stock)), array('yes', '1', 'true', 'on'), true);
            
            if (!empty($var_stock_qty) && is_numeric($var_stock_qty)) {
                // Stock quantity provided - enable stock management
                $variation->set_manage_stock(true);
                $variation->set_stock_quantity(intval($var_stock_qty));
                $variation->set_stock_status(intval($var_stock_qty) > 0 ? 'instock' : 'outofstock');
            } elseif ($var_manage_stock !== '') {
                // manage_stock field is explicitly set
                $variation->set_manage_stock($should_manage_stock);
                if (!$should_manage_stock) {
                    // Not managing stock - use stock_status from mapping or default to instock
                    $status = !empty($var_stock_status) ? strtolower(trim($var_stock_status)) : 'instock';
                    $status = ($status === 'outofstock') ? 'outofstock' : 'instock';
                    $variation->set_stock_status($status);
                }
            } else {
                // No stock info - don't manage stock, set status from mapping or default instock
                $variation->set_manage_stock(false);
                $status = !empty($var_stock_status) ? strtolower(trim($var_stock_status)) : 'instock';
                $status = ($status === 'outofstock') ? 'outofstock' : 'instock';
                $variation->set_stock_status($status);
            }
            
            // Set enabled
            $variation->set_status('publish');
            
            // Apply Shipping Class Engine per-variation (Format A CSV)
            // First check if variation has direct shipping_class field in CSV
            $var_shipping_field = $var_data[$csv_fields['shipping_class'] ?? 'Shipping Class'] ?? '';
            if (!empty($var_shipping_field)) {
                $sc_id = $this->get_shipping_class_id($var_shipping_field);
                if ($sc_id) {
                    $variation->set_shipping_class_id($sc_id);
                }
            } else {
                $var_product_data = array(
                    'regular_price' => $variation->get_regular_price(),
                    'price'         => $variation->get_price(),
                    'weight'        => $variation->get_weight(),
                    'length'        => $variation->get_length(),
                    'width'         => $variation->get_width(),
                    'height'        => $variation->get_height(),
                    'sku'           => $variation->get_sku(),
                );
                $saved_raw = $this->_current_raw_product_data ?? null;
                $this->_current_raw_product_data = null;
                $this->apply_shipping_class_engine($variation, $var_product_data);
                $this->_current_raw_product_data = $saved_raw;
            }
            
            // Save variation with error handling
            try {
                $variation_id = $variation->save();
            } catch (Exception $e) {
                continue;
            }
            
            // Set variation image if provided (skip on error to not block import)
            $var_image = $var_data[$csv_fields['image'] ?? 'Image'] ?? '';
            if (!empty($var_image) && filter_var($var_image, FILTER_VALIDATE_URL)) {
                try {
                    $image_id = $this->download_and_attach_image($var_image, $variation_id);
                    if ($image_id) {
                        set_post_thumbnail($variation_id, $image_id);
                    }
                } catch (Exception $e) {
                }
            }
            
            $variation_count++;
        }
        
        // Sync variable product - this calculates prices and stock from variations
        WC_Product_Variable::sync($product_id);
        
        // Force sync stock status - WooCommerce sometimes doesn't do this correctly
        // Check if any variation is in stock by looking at meta directly
        $children = get_posts(array(
            'post_type' => 'product_variation',
            'post_parent' => $product_id,
            'posts_per_page' => -1,
            'fields' => 'ids'
        ));
        
        $has_stock = false;
        foreach ($children as $child_id) {
            $child_stock_status = get_post_meta($child_id, '_stock_status', true);
            if ($child_stock_status === 'instock') {
                $has_stock = true;
            }
        }
        
        // Update parent stock status directly in meta
        $new_stock_status = $has_stock ? 'instock' : 'outofstock';
        update_post_meta($product_id, '_stock_status', $new_stock_status);
        
        // Clear WooCommerce product cache
        wc_delete_product_transients($product_id);
        wp_cache_delete('product-' . $product_id, 'products');
        
        
        $product_name = !empty($processed_data['name']) ? $processed_data['name'] : 'Variable Product';
        // translators: %1$s is the product name, %2$d is the number of variations
        $this->log('info', sprintf(__('Imported variable product: %1$s with %2$d variations', 'bootflow-product-importer'), $product_name, $variation_count), $processed_data['sku'] ?? '');
        
        
        return $product_id;
    }

    /**
     * Check if product passes import filters.
     *
     * @since    1.0.0
     * @param    array $product_data Raw product data
     * @return   bool True if passes all filters, false otherwise
     */
    private function passes_import_filters($product_data) {
        // PRO-only feature: if not PRO, skip all filters and import everything
        if (!WC_XML_CSV_AI_Import_Features::is_available('import_filters')) {
            return true; // FREE version = no filtering, import all
        }
        
        // Get import filters from config
        if (empty($this->config['import_filters']) || !is_array($this->config['import_filters'])) {
            return true; // No filters = import all
        }

        $filters = $this->config['import_filters'];

        if (empty($filters)) {
            return true; // No filters = import all
        }

        // Evaluate filters sequentially with their individual logic operators
        $cumulative_result = null;
        
        foreach ($filters as $index => $filter) {
            if (empty($filter['field']) || empty($filter['operator'])) {
                continue; // Skip invalid filters
            }

            $field = $filter['field'];
            $operator = $filter['operator'];
            $expected_value = isset($filter['value']) ? $filter['value'] : '';
            $logic = isset($filter['logic']) ? $filter['logic'] : 'AND'; // Default to AND

            // Get field value from product data (supports nested paths with dots)
            $actual_value = $this->xml_parser->extract_field_value($product_data, $field);

            // Evaluate filter condition
            $result = $this->evaluate_filter_condition($actual_value, $operator, $expected_value);

            // Log filter evaluation
            $this->log('debug', sprintf(
                'Filter #%d: %s %s "%s" | Actual: "%s" | Result: %s | Logic: %s',
                $index + 1,
                $field,
                $operator,
                $expected_value,
                $actual_value,
                $result ? 'PASS' : 'FAIL',
                $logic
            ));
            
            // Apply logic with previous result
            if ($cumulative_result === null) {
                // First filter
                $cumulative_result = $result;
            } else {
                // Combine with previous result using the PREVIOUS filter's logic
                $prev_index = $index - 1;
                $prev_logic = isset($filters[$prev_index]['logic']) ? $filters[$prev_index]['logic'] : 'AND';
                
                if ($prev_logic === 'OR') {
                    $cumulative_result = $cumulative_result || $result;
                } else {
                    $cumulative_result = $cumulative_result && $result;
                }
            }
        }

        return $cumulative_result !== null ? $cumulative_result : true;
    }

    /**
     * Evaluate single filter condition.
     *
     * @since    1.0.0
     * @param    mixed $actual_value Actual field value
     * @param    string $operator Comparison operator
     * @param    mixed $expected_value Expected value
     * @return   bool True if condition passes
     */
    private function evaluate_filter_condition($actual_value, $operator, $expected_value) {
        // Convert to string for comparison
        $actual = (string) $actual_value;
        $expected = (string) $expected_value;

        switch ($operator) {
            case '=':
                return $actual === $expected;

            case '!=':
                return $actual !== $expected;

            case '>':
                return is_numeric($actual) && is_numeric($expected) && floatval($actual) > floatval($expected);

            case '<':
                return is_numeric($actual) && is_numeric($expected) && floatval($actual) < floatval($expected);

            case '>=':
                return is_numeric($actual) && is_numeric($expected) && floatval($actual) >= floatval($expected);

            case '<=':
                return is_numeric($actual) && is_numeric($expected) && floatval($actual) <= floatval($expected);

            case 'contains':
                return stripos($actual, $expected) !== false;

            case 'not_contains':
                return stripos($actual, $expected) === false;

            case 'empty':
                return empty($actual);

            case 'not_empty':
                return !empty($actual);

            case 'regex_match':
                // Validate regex pattern to prevent fatal errors
                if (@preg_match($expected, '') === false) {
                    // translators: placeholder values
                    $this->log('warning', sprintf(__('Invalid regex pattern: %s', 'bootflow-product-importer'), $expected));
                    return true; // Invalid regex = pass (safe default)
                }
                return preg_match($expected, $actual) === 1;

            case 'regex_not_match':
                // Validate regex pattern to prevent fatal errors
                if (@preg_match($expected, '') === false) {
                    // translators: placeholder values
                    $this->log('warning', sprintf(__('Invalid regex pattern: %s', 'bootflow-product-importer'), $expected));
                    return true; // Invalid regex = pass (safe default)
                }
                return preg_match($expected, $actual) !== 1;

            default:
                return true; // Unknown operator = pass
        }
    }

    /**
     * Map raw product data to WooCommerce fields.
     *
     * @since    1.0.0
     * @param    array $product_data Raw product data
     * @return   array Mapped data
     */
    private function map_product_fields($product_data) {
        $mapped_data = array();
        $field_mappings = $this->config['field_mapping'];

        // Debug field mappings and source data
        if (defined('WP_DEBUG') && WP_DEBUG) { error_log('WC XML CSV AI Import - Field mappings: ' . print_r($field_mappings, true)); }
        if (defined('WP_DEBUG') && WP_DEBUG) { error_log('WC XML CSV AI Import - Product data keys: ' . print_r(array_keys($product_data), true)); }

        if (empty($field_mappings) || !is_array($field_mappings)) {
            if (defined('WP_DEBUG') && WP_DEBUG) { error_log('WC XML CSV AI Import - Field mappings are empty or not an array! Creating default mappings...'); }
            
            // Create basic default field mappings based on actual XML fields
            $field_mappings = array(
                'name' => array('source' => 'product_name', 'processing' => 'direct'),
                'regular_price' => array('source' => 'price', 'processing' => 'direct'),
                'sku' => array('source' => 'id', 'processing' => 'direct'),
                'short_description' => array('source' => 'short_specs', 'processing' => 'direct'),
                'description' => array('source' => 'description_lv', 'processing' => 'direct'),
                // Ensure stock quantity gets mapped by default from common XML field name
                'stock_quantity' => array('source' => 'quantity', 'processing' => 'direct'),
            );
            
            if (defined('WP_DEBUG') && WP_DEBUG) { error_log('WC XML CSV AI Import - Using default field mappings: ' . print_r($field_mappings, true)); }
        } else {
            // Check if field mappings have empty sources and fix them
            foreach ($field_mappings as $wc_field => &$mapping_config) {
                // Ensure mapping_config is an array
                if (!is_array($mapping_config)) {
                    if (defined('WP_DEBUG') && WP_DEBUG) { error_log('WC XML CSV AI Import - Invalid mapping config for ' . $wc_field . ': ' . print_r($mapping_config, true)); }
                    continue;
                }
                
                if (empty($mapping_config['source'])) {
                    // Auto-assign common field mappings
                    switch ($wc_field) {
                        case 'name':
                            $mapping_config['source'] = 'product_name';
                            $mapping_config['processing'] = 'direct';
                            if (defined('WP_DEBUG') && WP_DEBUG) { error_log('WC XML CSV AI Import - Auto-assigned name field to product_name'); }
                            break;
                        case 'regular_price':
                            $mapping_config['source'] = 'price';
                            $mapping_config['processing'] = 'direct';
                            break;
                        case 'sku':
                            $mapping_config['source'] = 'id';
                            $mapping_config['processing'] = 'direct';
                            break;
                        case 'short_description':
                            $mapping_config['source'] = 'short_specs';
                            $mapping_config['processing'] = 'direct';
                            break;
                    }
                }
            }
            
            if (defined('WP_DEBUG') && WP_DEBUG) { error_log('WC XML CSV AI Import - Updated field mappings: ' . print_r($field_mappings, true)); }
        }

        // Ensure field_mappings is an array before foreach
        if (!is_array($field_mappings)) {
            if (defined('WP_DEBUG') && WP_DEBUG) { error_log('WC XML CSV AI Import - Field mappings is not an array after all fixes! Type: ' . gettype($field_mappings)); }
            $field_mappings = array();
        }

        foreach ($field_mappings as $wc_field => $mapping_config) {
            // Skip if not an array
            if (!is_array($mapping_config)) {
                if (defined('WP_DEBUG') && WP_DEBUG) { error_log('WC XML CSV AI Import - Skipping invalid mapping config for ' . $wc_field); }
                continue;
            }
            
            // Handle boolean fields (Yes/No/Map mode)
            if (isset($mapping_config['boolean_mode'])) {
                $boolean_mode = $mapping_config['boolean_mode'];
                if ($boolean_mode === 'yes') {
                    $mapped_data[$wc_field] = 'yes';
                    continue;
                } elseif ($boolean_mode === 'no') {
                    $mapped_data[$wc_field] = 'no';
                    continue;
                }
                // If mode is 'map', continue to extract from source
            }
            
            // Handle select fields (Fixed/Map mode)
            if (isset($mapping_config['select_mode'])) {
                $select_mode = $mapping_config['select_mode'];
                if ($select_mode === 'fixed' && isset($mapping_config['fixed_value'])) {
                    $mapped_data[$wc_field] = $mapping_config['fixed_value'];
                    continue;
                }
                // If mode is 'map', continue to extract from source
            }
            
            // Handle SKU field with generate option
            if ($wc_field === 'sku' && isset($mapping_config['sku_mode']) && $mapping_config['sku_mode'] === 'generate') {
                $pattern = isset($mapping_config['sku_pattern']) ? $mapping_config['sku_pattern'] : 'PROD-{row}';
                $row_number = isset($this->current_row_number) ? $this->current_row_number : 1;
                
                // Get product name for {name} placeholder
                $product_name = '';
                if (isset($product_data['name'])) {
                    $product_name = sanitize_title(substr($product_data['name'], 0, 20));
                } elseif (isset($product_data['title'])) {
                    $product_name = sanitize_title(substr($product_data['title'], 0, 20));
                }
                
                // Generate SKU from pattern
                $generated_sku = $pattern;
                $generated_sku = str_replace('{row}', $row_number, $generated_sku);
                $generated_sku = str_replace('{timestamp}', time(), $generated_sku);
                $generated_sku = str_replace('{random}', strtoupper(substr(md5(uniqid(wp_rand(), true)), 0, 6)), $generated_sku);
                $generated_sku = str_replace('{name}', $product_name, $generated_sku);
                $generated_sku = str_replace('{md5}', substr(md5($product_name . $row_number), 0, 8), $generated_sku);
                
                $mapped_data[$wc_field] = $generated_sku;
                if (defined('WP_DEBUG') && WP_DEBUG) { error_log("WC XML CSV AI Import - Generated SKU: $generated_sku (pattern: $pattern, row: $row_number)"); }
                continue;
            }
            
            if (empty($mapping_config['source'])) {
                continue;
            }

            $source_field = $mapping_config['source'];

            // Special handling for 'images' and 'featured_image' fields - keep as template string for later placeholder parsing
            if ($wc_field === 'images' || $wc_field === 'featured_image') {
                $mapped_data[$wc_field] = $source_field; // Keep the template string like "{image*}" or "{image2}"
                $log_file = WP_CONTENT_DIR . '/import_debug.log';
                continue;
            }

            // Check if source contains {placeholder} syntax (template string)
            // This allows combining multiple fields like "{price.#text} {price.@currency}"
            if (strpos($source_field, '{') !== false && strpos($source_field, '}') !== false) {
                // Parse template string - replace all {field} with actual values
                $value = $this->parse_template_string($source_field, $product_data);
            } else {
                // Simple field name - extract directly
                // Detect file type by available parser to avoid relying on config drift
                if (!empty($this->xml_parser)) {
                    $value = $this->xml_parser->extract_field_value($product_data, $source_field);
                } else {
                    $value = $this->csv_parser->extract_field_value($product_data, $source_field);
                }
            }

            if ($value !== null) {
                $mapped_data[$wc_field] = $value;
                // Debug mapping
                if (defined('WP_DEBUG') && WP_DEBUG) { error_log("WC XML CSV AI Import - Mapping $wc_field from $source_field: " . print_r($value, true)); }
                
                // Extra debug for brand
                if ($wc_field === 'brand') {
                    if (defined('WP_DEBUG') && WP_DEBUG) { error_log("BRAND MAPPING: WC field='brand', source='$source_field', value=" . print_r($value, true)); }
                }
            }
        }

        // Debug final mapped data
        if (defined('WP_DEBUG') && WP_DEBUG) { error_log('WC XML CSV AI Import - Final mapped data: ' . print_r($mapped_data, true)); }

        return $mapped_data;
    }

    /**
     * Process mapped product fields through configured processors.
     *
     * @since    1.0.0
     * @param    array $mapped_data Mapped field data
     * @param    array $product_data Raw product data for context
     * @param    int|null $existing_product_id If product exists, its ID (to skip processing for update_on_sync=0 fields)
     * @return   array Processed data
     */
    private function process_product_fields($mapped_data, $product_data, $existing_product_id = null) {
        $field_mappings = $this->config['field_mapping'];
        $processed_data = array();
        $is_existing_product = !empty($existing_product_id);

        // Debug: Check if sale_price is in mapped_data
        if (defined('WP_DEBUG') && WP_DEBUG) {
            if (isset($mapped_data['sale_price'])) {
            } else {
            }
            if (isset($field_mappings['sale_price'])) {
            } else {
            }
        }

        // Process all fields with full raw XML data as context
        // This allows any field to use any XML data as variables in formulas
        foreach ($mapped_data as $field_key => $value) {
            // Special handling for 'images' and 'featured_image' fields - keep template string unchanged
            if ($field_key === 'images' || $field_key === 'featured_image') {
                $processed_data[$field_key] = $value; // Keep as-is for placeholder parsing later
                continue;
            }
            
            if (isset($field_mappings[$field_key])) {
                $config = $field_mappings[$field_key];
                
                // OPTIMIZATION: Skip expensive processing (AI, PHP formulas) for existing products
                // if the field has update_on_sync disabled - the value won't be used anyway!
                if ($is_existing_product && isset($config['update_on_sync']) && $config['update_on_sync'] !== '1' && $config['update_on_sync'] !== 1 && $config['update_on_sync'] !== true) {
                    $processing_mode = $config['processing_mode'] ?? 'direct';
                    // Only skip expensive processing modes (AI and PHP formulas)
                    if ($processing_mode === 'ai_processing' || $processing_mode === 'php_formula') {
                        if (defined('WP_DEBUG') && WP_DEBUG) {
                        }
                        // Just pass the raw value - it won't be saved anyway
                        $processed_data[$field_key] = $value;
                        continue;
                    }
                }
                
                // Debug: log what we're about to process
                if ($field_key === 'sale_price' || $field_key === 'regular_price') {
                    if (defined('WP_DEBUG') && WP_DEBUG) { 
                    }
                }
                // Pass full raw product_data as context so all XML fields are available as variables
                $processed_data[$field_key] = $this->processor->process_field($value, $config, $product_data);
            } else {
                $processed_data[$field_key] = $value;
            }
        }

        // If quantity is mapped, ensure we will manage stock
        if (isset($processed_data['stock_quantity'])) {
            $processed_data['manage_stock'] = true;
        }

        return $processed_data;
    }

    /**
     * Apply Pricing Engine rules to calculate final price.
     *
     * @since    1.0.0
     * @param    array $processed_data Processed product data
     * @param    array $raw_data Raw product data for condition checking
     * @return   array Updated processed data with calculated price
     */
    private function apply_pricing_engine($processed_data, $raw_data) {
        $pricing_config = $this->config['field_mapping']['pricing_engine'] ?? null;
        
        // Check if pricing engine is enabled
        if (empty($pricing_config) || empty($pricing_config['enabled'])) {
            return $processed_data;
        }
        
        if (defined('WP_DEBUG') && WP_DEBUG) { 
        }
        
        // Get base price from configured source field
        $base_price_field = $pricing_config['base_price'] ?? 'price';
        $base_price = 0;
        
        // Try to get base price from raw data
        if (isset($raw_data[$base_price_field])) {
            $base_price = floatval(str_replace(',', '.', $raw_data[$base_price_field]));
        } elseif (isset($processed_data['regular_price'])) {
            $base_price = floatval(str_replace(',', '.', $processed_data['regular_price']));
        }
        
        if ($base_price <= 0) {
            if (defined('WP_DEBUG') && WP_DEBUG) { 
            }
            return $processed_data;
        }
        
        if (defined('WP_DEBUG') && WP_DEBUG) { 
        }
        
        // Find matching rule
        $matched_rule = null;
        $rules = $pricing_config['rules'] ?? array();
        
        foreach ($rules as $rule) {
            if (empty($rule['enabled'])) {
                continue;
            }
            
            if ($this->check_pricing_rule_conditions($rule, $base_price, $raw_data)) {
                $matched_rule = $rule;
                if (defined('WP_DEBUG') && WP_DEBUG) { 
                }
                break; // First matching rule wins
            }
        }
        
        // Use default rule if no rule matched
        if (!$matched_rule) {
            $matched_rule = $pricing_config['default_rule'] ?? array(
                'markup_percent' => 0,
                'fixed_amount' => 0,
                'rounding' => 'none'
            );
            if (defined('WP_DEBUG') && WP_DEBUG) { 
            }
        }
        
        // Calculate final price
        $markup_percent = floatval($matched_rule['markup_percent'] ?? 0);
        $fixed_amount = floatval($matched_rule['fixed_amount'] ?? 0);
        $rounding = $matched_rule['rounding'] ?? 'none';
        $min_price = !empty($matched_rule['min_price']) ? floatval($matched_rule['min_price']) : null;
        $max_price = !empty($matched_rule['max_price']) ? floatval($matched_rule['max_price']) : null;
        
        // If rule uses "inherit" rounding, get from default rule
        if ($rounding === 'inherit' && isset($pricing_config['default_rule']['rounding'])) {
            $rounding = $pricing_config['default_rule']['rounding'];
        }
        
        // Apply markup: price * (1 + markup%/100) + fixed
        $final_price = $base_price * (1 + $markup_percent / 100) + $fixed_amount;
        
        // Apply rounding
        $final_price = $this->apply_pricing_rounding($final_price, $rounding);
        
        // Apply min/max constraints
        if ($min_price !== null && $final_price < $min_price) {
            $final_price = $min_price;
        }
        if ($max_price !== null && $final_price > $max_price) {
            $final_price = $max_price;
        }
        
        // Ensure price is not negative
        if ($final_price < 0) {
            $final_price = 0;
        }
        
        if (defined('WP_DEBUG') && WP_DEBUG) { 
        }
        
        // Update regular_price in processed data
        $processed_data['regular_price'] = number_format($final_price, 2, '.', '');
        
        return $processed_data;
    }
    
    /**
     * Check if pricing rule conditions match.
     *
     * @param array $rule Rule configuration
     * @param float $base_price Base price value
     * @param array $raw_data Raw product data
     * @return bool True if all/any conditions match
     */
    private function check_pricing_rule_conditions($rule, $base_price, $raw_data) {
        $conditions = $rule['conditions'] ?? array();
        
        if (empty($conditions)) {
            return true; // No conditions = always matches
        }
        
        $logic = $rule['logic'] ?? 'AND';
        $results = array();
        
        foreach ($conditions as $condition) {
            $type = $condition['type'] ?? '';
            $result = false;
            
            switch ($type) {
                case 'price_range':
                    $from = floatval(str_replace(',', '.', $condition['from'] ?? 0));
                    $to = floatval(str_replace(',', '.', $condition['to'] ?? PHP_INT_MAX));
                    $result = ($base_price >= $from && $base_price <= $to);
                    break;
                    
                case 'category':
                case 'brand':
                case 'supplier':
                    $operator = $condition['operator'] ?? 'equals';
                    $value = $condition['value'] ?? '';
                    $field_value = '';
                    
                    // Try to find the field in raw data
                    $possible_fields = array($type, ucfirst($type), strtoupper($type));
                    if ($type === 'category') {
                        $possible_fields = array_merge($possible_fields, array('category_id', 'categoryId', 'cat', 'categories'));
                    } elseif ($type === 'brand') {
                        $possible_fields = array_merge($possible_fields, array('brand_id', 'brandId', 'manufacturer'));
                    } elseif ($type === 'supplier') {
                        $possible_fields = array_merge($possible_fields, array('supplier_id', 'supplierId', 'vendor'));
                    }
                    
                    foreach ($possible_fields as $field) {
                        if (isset($raw_data[$field]) && !empty($raw_data[$field])) {
                            $field_value = (string)$raw_data[$field];
                            break;
                        }
                    }
                    
                    $result = $this->check_condition_operator($field_value, $operator, $value);
                    break;
                    
                case 'xml_field':
                    $field = $condition['field'] ?? '';
                    $operator = $condition['operator'] ?? 'equals';
                    $value = $condition['value'] ?? '';
                    $field_value = isset($raw_data[$field]) ? (string)$raw_data[$field] : '';
                    $result = $this->check_condition_operator($field_value, $operator, $value);
                    break;
                    
                case 'sku_pattern':
                    $pattern = $condition['pattern'] ?? '';
                    $sku = isset($raw_data['sku']) ? $raw_data['sku'] : (isset($raw_data['id']) ? $raw_data['id'] : '');
                    if (!empty($pattern)) {
                        $result = (preg_match('/' . preg_quote($pattern, '/') . '/i', $sku) === 1);
                    }
                    break;
            }
            
            $results[] = $result;
            
            if (defined('WP_DEBUG') && WP_DEBUG) { 
            }
        }
        
        // Apply logic (AND/OR)
        if ($logic === 'OR') {
            return in_array(true, $results, true);
        } else {
            return !in_array(false, $results, true);
        }
    }
    
    /**
     * Check condition operator.
     *
     * @param string $field_value Field value
     * @param string $operator Operator
     * @param string $expected Expected value
     * @return bool
     */
    private function check_condition_operator($field_value, $operator, $expected) {
        switch ($operator) {
            case 'equals':
                return strtolower($field_value) === strtolower($expected);
            case 'not_equals':
                return strtolower($field_value) !== strtolower($expected);
            case 'contains':
                return stripos($field_value, $expected) !== false;
            case 'not_contains':
                return stripos($field_value, $expected) === false;
            case 'starts_with':
                return stripos($field_value, $expected) === 0;
            case 'ends_with':
                return substr(strtolower($field_value), -strlen($expected)) === strtolower($expected);
            default:
                return false;
        }
    }
    
    /**
     * Apply rounding to price.
     *
     * @param float $price Price value
     * @param string $rounding Rounding type
     * @return float Rounded price
     */
    private function apply_pricing_rounding($price, $rounding) {
        switch ($rounding) {
            case '0.01':
                return round($price, 2);
            case '0.05':
                return round($price * 20) / 20;
            case '0.10':
                return round($price * 10) / 10;
            case '0.50':
                return round($price * 2) / 2;
            case '1.00':
                return round($price);
            case '0.99':
                // Round to nearest .99 (e.g., 10.45 -> 10.99, 10.00 -> 9.99)
                return floor($price) + 0.99;
            case '0.95':
                // Round to nearest .95
                return floor($price) + 0.95;
            case 'none':
            default:
                return round($price, 2);
        }
    }
    
    /**
     * Apply Pricing Engine to a single price value.
     * Used for variations where we only have the price, not full product data.
     *
     * @param float $base_price Base price value
     * @param array $raw_data Raw data for condition checking
     * @return string Calculated price as string
     */
    private function apply_pricing_engine_to_price($base_price, $raw_data = array()) {
        $pricing_config = $this->config['field_mapping']['pricing_engine'] ?? null;
        
        // Check if pricing engine is enabled
        if (empty($pricing_config) || empty($pricing_config['enabled'])) {
            return number_format($base_price, 2, '.', '');
        }
        
        if ($base_price <= 0) {
            return number_format($base_price, 2, '.', '');
        }
        
        // Find matching rule
        $matched_rule = null;
        $rules = $pricing_config['rules'] ?? array();
        
        foreach ($rules as $rule) {
            if (empty($rule['enabled'])) {
                continue;
            }
            
            if ($this->check_pricing_rule_conditions($rule, $base_price, $raw_data)) {
                $matched_rule = $rule;
                break;
            }
        }
        
        // Use default rule if no rule matched
        if (!$matched_rule) {
            $matched_rule = $pricing_config['default_rule'] ?? array(
                'markup_percent' => 0,
                'fixed_amount' => 0,
                'rounding' => 'none'
            );
        }
        
        // Calculate final price
        $markup_percent = floatval($matched_rule['markup_percent'] ?? 0);
        $fixed_amount = floatval($matched_rule['fixed_amount'] ?? 0);
        $rounding = $matched_rule['rounding'] ?? 'none';
        $min_price = !empty($matched_rule['min_price']) ? floatval($matched_rule['min_price']) : null;
        $max_price = !empty($matched_rule['max_price']) ? floatval($matched_rule['max_price']) : null;
        
        // If rule uses "inherit" rounding, get from default rule
        if ($rounding === 'inherit' && isset($pricing_config['default_rule']['rounding'])) {
            $rounding = $pricing_config['default_rule']['rounding'];
        }
        
        // Apply markup: price * (1 + markup%/100) + fixed
        $final_price = $base_price * (1 + $markup_percent / 100) + $fixed_amount;
        
        // Apply rounding
        $final_price = $this->apply_pricing_rounding($final_price, $rounding);
        
        // Apply min/max constraints
        if ($min_price !== null && $final_price < $min_price) {
            $final_price = $min_price;
        }
        if ($max_price !== null && $final_price > $max_price) {
            $final_price = $max_price;
        }
        
        // Ensure price is not negative
        if ($final_price < 0) {
            $final_price = 0;
        }
        
        return number_format($final_price, 2, '.', '');
    }

    /**
     * Validate product data.
     *
     * @since    1.0.0
     * @param    array $product_data Product data
     */
    private function validate_product_data($product_data, $existing_product_id = null) {
        // Debug: log what data we're validating
        if (defined('WP_DEBUG') && WP_DEBUG) { error_log('WC XML CSV AI Import - Validating product data: ' . print_r($product_data, true)); }
        
        // Check required fields - name is only required for new products
        $required_fields = array();
        
        // If it's a new product (no existing ID), name is required
        if (!$existing_product_id) {
            $required_fields[] = 'name';
        }

        foreach ($required_fields as $field) {
            if (empty($product_data[$field])) {
                if (defined('WP_DEBUG') && WP_DEBUG) { error_log('WC XML CSV AI Import - Missing required field: ' . $field . ' - Product data keys: ' . print_r(array_keys($product_data), true)); }
                // translators: placeholder values
                throw new Exception(sprintf(esc_html__('Required field "%s" is missing or empty.', 'bootflow-product-importer'), esc_html($field)));
            }
        }

        // Validate SKU if provided
        if (!empty($product_data['sku']) && !preg_match('/^[a-zA-Z0-9\-_.]+$/', $product_data['sku'])) {
            // translators: placeholder values
            throw new Exception(sprintf(esc_html__('Invalid SKU format: %s', 'bootflow-product-importer'), esc_html($product_data['sku'])));
        }

        // Validate prices (allow empty — variable products may have prices only on variations)
        if (isset($product_data['regular_price']) && $product_data['regular_price'] !== '' && $product_data['regular_price'] !== null && !is_numeric($product_data['regular_price'])) {
            // translators: placeholder values
            throw new Exception(sprintf(esc_html__('Invalid regular price: %s', 'bootflow-product-importer'), esc_html($product_data['regular_price'])));
        }

        if (isset($product_data['sale_price']) && !empty($product_data['sale_price']) && !is_numeric($product_data['sale_price'])) {
            // translators: placeholder values
            throw new Exception(sprintf(esc_html__('Invalid sale price: %s', 'bootflow-product-importer'), esc_html($product_data['sale_price'])));
        }
    }

    /**
     * Create new WooCommerce product.
     *
     * @since    1.0.0
     * @param    array $product_data Product data
     * @param    array $product_data Processed product data
     * @param    array $mapped_data Mapped data with template strings for images
     * @return   int Product ID
     */
    private function create_product($product_data, $mapped_data = array()) {
        // Determine product type - check explicit type field first
        $product_type = isset($product_data['type']) ? strtolower(trim($product_data['type'])) : '';
        
        // Auto-detect product type if not explicitly set
        if (empty($product_type) || $product_type === 'simple') {
            // If grouped_products field has values, it's a Grouped product
            if (!empty($product_data['grouped_products'])) {
                $product_type = 'grouped';
                // translators: placeholder values
                $this->log('info', sprintf(__('Auto-detected Grouped product type for "%s" (has grouped_products field)', 'bootflow-product-importer'), $product_data['name'] ?? $product_data['sku'] ?? 'Unknown'));
            }
            // If external_url is set, it's an External product
            elseif (!empty($product_data['external_url'])) {
                $product_type = 'external';
                // translators: placeholder values
                $this->log('info', sprintf(__('Auto-detected External product type for "%s" (has external_url field)', 'bootflow-product-importer'), $product_data['name'] ?? $product_data['sku'] ?? 'Unknown'));
            }
            // Default to simple
            else {
                $product_type = 'simple';
            }
        }
        
        // Create appropriate product object based on type
        switch ($product_type) {
            case 'grouped':
                // PRO feature check
                if (!WC_XML_CSV_AI_Import_Features::is_available('variable_products')) {
                    // translators: placeholder values
                    $this->log('warning', sprintf(__('Grouped products require PRO license. Importing "%s" as Simple product.', 'bootflow-product-importer'), $product_data['name']));
                    $product = new WC_Product_Simple();
                    $product_type = 'simple';
                } else {
                    $product = new WC_Product_Grouped();
                }
                break;
                
            case 'external':
            case 'affiliate':
                // PRO feature check
                if (!WC_XML_CSV_AI_Import_Features::is_available('variable_products')) {
                    // translators: placeholder values
                    $this->log('warning', sprintf(__('External products require PRO license. Importing "%s" as Simple product.', 'bootflow-product-importer'), $product_data['name']));
                    $product = new WC_Product_Simple();
                    $product_type = 'simple';
                } else {
                    $product = new WC_Product_External();
                }
                break;
                
            case 'variable':
                $product = new WC_Product_Variable();
                break;
                
            default:
                $product = new WC_Product_Simple();
                $product_type = 'simple';
        }

        // Set basic properties
        $product->set_name($product_data['name']);
        
        if (!empty($product_data['sku'])) {
            $product->set_sku($product_data['sku']);
        }

        if (!empty($product_data['description'])) {
            $product->set_description($product_data['description']);
        }

        if (!empty($product_data['short_description'])) {
            $product->set_short_description($product_data['short_description']);
        }

        // Set pricing
        if (!empty($product_data['regular_price'])) {
            $product->set_regular_price($product_data['regular_price']);
        }

        if (!empty($product_data['sale_price'])) {
            $product->set_sale_price($product_data['sale_price']);
        }

        // Set sale price dates
        if (!empty($product_data['sale_price_dates_from'])) {
            $product->set_date_on_sale_from($product_data['sale_price_dates_from']);
        }
        if (!empty($product_data['sale_price_dates_to'])) {
            $product->set_date_on_sale_to($product_data['sale_price_dates_to']);
        }

        // Set tax status/class
        if (!empty($product_data['tax_status'])) {
            $product->set_tax_status($product_data['tax_status']);
        }
        if (isset($product_data['tax_class'])) {
            $product->set_tax_class($product_data['tax_class']);
        }

        // Set inventory (SKIP for External products - WooCommerce doesn't allow stock management for External)
        if ($product_type !== 'external') {
            if (isset($product_data['manage_stock'])) {
                $manage = $product_data['manage_stock'];
                $product->set_manage_stock($manage === 'yes' || $manage === '1' || $manage === true || $manage === 1);
            }

            // If stock quantity is provided, force-enable manage_stock and set quantity
            if (isset($product_data['stock_quantity'])) {
                $product->set_manage_stock(true);
                $product->set_stock_quantity((int) $product_data['stock_quantity']);
            }

            // Store stock_status for forcing after save
            $force_stock_status = null;
            if (!empty($product_data['stock_status'])) {
                $force_stock_status = $product_data['stock_status'];
                $product->set_stock_status($product_data['stock_status']);
            }
        } else {
            // External products: skip stock management, just set stock_status if provided
            $force_stock_status = null;
            if (!empty($product_data['stock_status'])) {
                $force_stock_status = $product_data['stock_status'];
            }
            $this->log('debug', sprintf('Skipping stock management for External product: %s', $product_data['sku'] ?? 'unknown'));
        }

        // Set dimensions
        if (!empty($product_data['weight'])) {
            $product->set_weight($product_data['weight']);
        }

        if (!empty($product_data['length'])) {
            $product->set_length($product_data['length']);
        }

        if (!empty($product_data['width'])) {
            $product->set_width($product_data['width']);
        }

        if (!empty($product_data['height'])) {
            $product->set_height($product_data['height']);
        }

        // Set sold individually
        if (isset($product_data['sold_individually'])) {
            $sold_ind = $product_data['sold_individually'];
            $product->set_sold_individually($sold_ind === 'yes' || $sold_ind === '1' || $sold_ind === true);
        }

        // Set virtual/downloadable
        if (isset($product_data['virtual'])) {
            $product->set_virtual($product_data['virtual'] === 'yes' || $product_data['virtual'] === '1');
        }
        if (isset($product_data['downloadable'])) {
            $product->set_downloadable($product_data['downloadable'] === 'yes' || $product_data['downloadable'] === '1');
        }

        // Set download limit/expiry
        if (isset($product_data['download_limit'])) {
            $product->set_download_limit((int) $product_data['download_limit']);
        }
        if (isset($product_data['download_expiry'])) {
            $product->set_download_expiry((int) $product_data['download_expiry']);
        }

        // Set backorders
        if (isset($product_data['backorders'])) {
            $product->set_backorders($product_data['backorders']);
        }

        // Set featured
        if (isset($product_data['featured'])) {
            $product->set_featured($product_data['featured'] === 'yes' || $product_data['featured'] === '1');
        }
        
        // Set reviews allowed
        if (isset($product_data['reviews_allowed'])) {
            $product->set_reviews_allowed($product_data['reviews_allowed'] === 'yes' || $product_data['reviews_allowed'] === '1' || $product_data['reviews_allowed'] === true);
        }

        // Set shipping class - direct mapping first, then engine, then old formula fallback
        if (isset($product_data['shipping_class']) && !empty($product_data['shipping_class'])) {
            $shipping_class_slug = sanitize_title($product_data['shipping_class']);
            $shipping_class_term = get_term_by('slug', $shipping_class_slug, 'product_shipping_class');
            
            // Create shipping class if it doesn't exist
            if (!$shipping_class_term || is_wp_error($shipping_class_term)) {
                $new_term = wp_insert_term(
                    $product_data['shipping_class'], // Original name
                    'product_shipping_class',
                    array('slug' => $shipping_class_slug)
                );
                if (!is_wp_error($new_term)) {
                    $shipping_class_term = get_term($new_term['term_id'], 'product_shipping_class');
                    $this->log('debug', sprintf('Created shipping class: %s', $product_data['shipping_class']));
                }
            }
            
            if ($shipping_class_term && !is_wp_error($shipping_class_term)) {
                $product->set_shipping_class_id($shipping_class_term->term_id);
                $this->log('debug', sprintf('Set shipping class: %s for product: %s', $product_data['shipping_class'], $product_data['sku'] ?? 'unknown'));
            }
        } else {
            // Try Shipping Class Engine first (rules-based)
            $engine_assigned = $this->apply_shipping_class_engine($product, $product_data);
            
            if (!$engine_assigned) {
                // Fallback: old formula-based auto-assignment
                $this->auto_assign_shipping_class($product, $product_data);
            }
        }

        // Set status - validate that status is a valid WordPress post_status
        $valid_statuses = array('publish', 'draft', 'pending', 'private', 'trash');
        $status = isset($product_data['status']) ? $product_data['status'] : 'publish';
        if (!in_array($status, $valid_statuses)) {
            // If status is not valid (e.g., accidentally mapped to wrong column), default to 'publish'
            $this->log('warning', 'Invalid product status "' . $status . '" - defaulting to "publish"');
            $status = 'publish';
        }
        $product->set_status($status);

        // Handle External product specific fields
        if ($product_type === 'external' && $product instanceof WC_Product_External) {
            if (!empty($product_data['external_url'])) {
                $product->set_product_url($product_data['external_url']);
            }
            if (!empty($product_data['button_text'])) {
                $product->set_button_text($product_data['button_text']);
            }
        }

        // Save product
        $product_id = $product->save();

        if (!$product_id) {
            throw new Exception(esc_html__('Failed to create product.', 'bootflow-product-importer'));
        }
        
        // SYNC _price meta - WooCommerce needs this for frontend display
        $regular_price = $product->get_regular_price();
        $sale_price = $product->get_sale_price();
        $price = ('' !== $sale_price && $sale_price !== null) ? $sale_price : $regular_price;
        if ('' !== $price && $price !== null) {
            update_post_meta($product_id, '_price', $price);
        }
        
        // FORCE stock_status after save - WooCommerce may have overridden it based on stock_quantity
        if ($force_stock_status) {
            global $wpdb;
            $wpdb->update(
                $wpdb->postmeta,
                array('meta_value' => $force_stock_status),
                array('post_id' => $product_id, 'meta_key' => '_stock_status'),
                array('%s'),
                array('%d', '%s')
            );
            wc_delete_product_transients($product_id);
            wp_cache_delete($product_id, 'post_meta');
            
            
            $this->log('debug', 'Forced stock_status to: ' . $force_stock_status . ' for new product ID: ' . $product_id);
        }
        
        // DEBUG: Verify saved stock_status from DB
        global $wpdb;
        $db_stock_status = $wpdb->get_var($wpdb->prepare("SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_stock_status'", $product_id));

        // Save product identifiers (EAN, UPC, ISBN, MPN, GTIN)
        $this->save_product_identifiers($product_id, $product_data);

        // Handle categories
        if (!empty($product_data['categories'])) {
            $this->set_product_categories($product_id, $product_data['categories']);
        }

        // Handle tags
        if (!empty($product_data['tags'])) {
            $this->set_product_tags($product_id, $product_data['tags']);
        }

        // Handle brand
        $this->log('debug', 'CREATE_PRODUCT: Checking brand in product_data: ' . print_r($product_data['brand'] ?? 'NOT SET', true));
        if (!empty($product_data['brand'])) {
            $this->log('debug', 'CREATE_PRODUCT: Brand value: ' . print_r($product_data['brand'], true));
            $this->set_product_brand($product_id, $product_data['brand']);
        } else {
            $this->log('warning', 'CREATE_PRODUCT: No brand data found');
        }

        // Handle images
        $this->log('debug', 'CREATE_PRODUCT: Starting image processing');
        $this->log('debug', 'mapped_data keys: ' . implode(', ', array_keys($mapped_data)));
        $this->log('debug', 'mapped images: ' . print_r($mapped_data['images'] ?? 'NOT SET', true));
        $this->log('debug', 'mapped featured_image: ' . print_r($mapped_data['featured_image'] ?? 'NOT SET', true));
        
        if (!empty($mapped_data['images']) || !empty($mapped_data['featured_image'])) {
            $this->log('debug', 'Calling set_product_images...');
            $this->set_product_images($product_id, $mapped_data);
        } else {
            $this->log('warning', 'Skipping images - both images and featured_image empty!');
        }

        // Handle SEO meta fields
        $this->set_product_seo_meta($product_id, $product_data);

        // Handle Grouped product children (store SKUs for later resolution)
        if ($product_type === 'grouped' && $product instanceof WC_Product_Grouped) {
            if (!empty($product_data['grouped_products'])) {
                // Store the SKU list for phase 2 resolution (after all products are imported)
                update_post_meta($product_id, '_pending_grouped_skus', $product_data['grouped_products']);
                // translators: placeholder values
                $this->log('info', sprintf(__('Grouped product "%1$s" - stored pending children SKUs: %2$s', 'bootflow-product-importer'), $product_data['name'], $product_data['grouped_products']));
            }
        }

        // Handle Upsells and Cross-sells (store SKUs for later resolution)
        if (!empty($product_data['upsell_ids'])) {
            update_post_meta($product_id, '_pending_upsell_skus', $product_data['upsell_ids']);
        }
        if (!empty($product_data['cross_sell_ids'])) {
            update_post_meta($product_id, '_pending_crosssell_skus', $product_data['cross_sell_ids']);
        }

        // Save import tracking meta
        update_post_meta($product_id, '_wc_import_id', $this->import_id);
        update_post_meta($product_id, '_wc_import_date', current_time('mysql'));
        update_post_meta($product_id, '_wc_import_source', 'create');

        return $product_id;
    }

    /**
     * Fast sync path for simple meta field updates (price, qty, stock_status).
     * Bypasses WooCommerce product load/save pipeline and does direct DB updates.
     * Returns product ID if fast sync was used, or false to fall back to full pipeline.
     *
     * @since    1.3.0
     * @param    int   $product_id      Existing product ID
     * @param    array $mapped_data     Mapped field data (raw from XML/CSV)
     * @param    array $raw_product_data Raw product data from source
     * @param    bool  $skip_unchanged  Whether to skip unchanged products
     * @return   int|false Product ID if fast synced, false to use full pipeline
     */
    private function try_fast_sync($product_id, $mapped_data, $raw_product_data, $skip_unchanged) {
        // Fast sync only works for fields that can be updated via direct post_meta
        $fast_sync_fields = array(
            'regular_price' => '_regular_price',
            'sale_price'    => '_sale_price',
            'stock_quantity'=> '_stock',
            'stock_status'  => '_stock_status',
            'manage_stock'  => '_manage_stock',
        );

        // Post fields that can be updated via wp_update_post (not post_meta)
        $fast_sync_post_fields = array('status' => 'post_status');

        $field_mappings = $this->config['field_mapping'] ?? array();

        // Determine which fields have update_on_sync=1
        $sync_fields = array();
        foreach ($field_mappings as $field_key => $mapping) {
            if (!is_array($mapping)) continue;
            if (isset($mapping['update_on_sync']) && ($mapping['update_on_sync'] === '1' || $mapping['update_on_sync'] === 1 || $mapping['update_on_sync'] === true)) {
                $sync_fields[] = $field_key;
            }
        }

        // If NO sync fields defined, can't use fast path (will update everything)
        if (empty($sync_fields)) {
            return false;
        }

        // Check if ALL sync fields are fast-syncable (meta fields OR simple post fields like status)
        foreach ($sync_fields as $field) {
            if (!isset($fast_sync_fields[$field]) && !isset($fast_sync_post_fields[$field])) {
                // This field requires the full WooCommerce pipeline (e.g., name, description, categories, images)
                return false;
            }
        }

        // Check if any sync field uses AI processing (API calls - needs full pipeline)
        // PHP formulas are OK - they are processed inline by the processor
        foreach ($sync_fields as $field) {
            $processing_mode = $field_mappings[$field]['processing_mode'] ?? 'direct';
            if ($processing_mode === 'ai_processing') {
                return false;
            }
        }

        // Check if Pricing Engine is active (needs full pipeline for price calculations)
        $pricing_config = $field_mappings['pricing_engine'] ?? null;
        if ($pricing_config && !empty($pricing_config['enabled'])) {
            // Only bail if price fields are being synced
            if (in_array('regular_price', $sync_fields) || in_array('sale_price', $sync_fields)) {
                return false;
            }
        }

        // ── All checks passed - we can use fast sync! ──

        global $wpdb;

        // Extract new values from source data using field mappings
        $new_values = array();
        foreach ($sync_fields as $field) {
            $mapping = $field_mappings[$field];
            
            // Handle select_mode: "fixed" (e.g., status field with fixed_value "publish")
            $select_mode = $mapping['select_mode'] ?? 'source';
            if ($select_mode === 'fixed') {
                $fixed_value = $mapping['fixed_value'] ?? '';
                if (!empty($fixed_value)) {
                    $new_values[$field] = $fixed_value;
                }
                continue;
            }
            
            $source = $mapping['source'] ?? '';
            if (empty($source)) continue;

            // Extract value from raw data (simple direct extraction)
            if (strpos($source, '{') !== false) {
                // Template string - extract with parser
                $value = $this->parse_template_string($source, $raw_product_data);
            } else {
                if (!empty($this->xml_parser)) {
                    $value = $this->xml_parser->extract_field_value($raw_product_data, $source);
                } else {
                    $value = $this->csv_parser->extract_field_value($raw_product_data, $source);
                }
            }

            if ($value !== null) {
                $new_values[$field] = $value;
            }
        }

        if (empty($new_values)) {
            return false; // No values extracted, fall back
        }

        // Process field values through the processor (for direct/simple modes only)
        foreach ($new_values as $field => &$value) {
            $config = $field_mappings[$field] ?? array();
            $processing_mode = $config['processing_mode'] ?? 'direct';
            if ($processing_mode === 'direct' || empty($processing_mode)) {
                // Direct mode - keep value as is (maybe trim)
                $value = trim((string)$value);
            } else {
                // Process through the standard processor
                $value = $this->processor->process_field($value, $config, $raw_product_data);
            }
        }
        unset($value);

        // ── Skip unchanged check (direct DB comparison) ──
        if ($skip_unchanged) {
            $changed = false;
            foreach ($new_values as $field => $new_value) {
                // Status is a post field, not meta
                if (isset($fast_sync_post_fields[$field])) {
                    $current = get_post_status($product_id);
                    if (trim((string)$current) !== trim((string)$new_value)) {
                        $changed = true;
                        break;
                    }
                    continue;
                }

                $meta_key = $fast_sync_fields[$field];
                $current = $wpdb->get_var($wpdb->prepare(
                    "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = %s",
                    $product_id, $meta_key
                ));

                // Normalize for comparison
                if (in_array($field, array('regular_price', 'sale_price'))) {
                    if (floatval($current) !== floatval($new_value)) {
                        $changed = true;
                        break;
                    }
                } elseif ($field === 'stock_quantity') {
                    if (intval($current) !== intval($new_value)) {
                        $changed = true;
                        break;
                    }
                } else {
                    if (trim((string)$current) !== trim((string)$new_value)) {
                        $changed = true;
                        break;
                    }
                }
            }

            if (!$changed) {
                // CRITICAL: Still update import tracking even for unchanged products!
                // handle_missing_products() uses _wc_import_date to identify products that were in the feed.
                // Without this, unchanged products get incorrectly treated as "missing from feed" and moved to draft.
                update_post_meta($product_id, '_wc_import_id', $this->import_id);
                update_post_meta($product_id, '_wc_import_date', current_time('mysql'));

                $sku = $mapped_data['sku'] ?? '?';
                $this->log('info', sprintf('Fast-sync skipped (unchanged) product ID %d, SKU: %s', $product_id, $sku), esc_html($sku));
                return $product_id;
            }
        }

        // ── Apply updates directly via post_meta ──
        $updated_fields = array();
        $post_update = array(); // For post fields (status) that need wp_update_post
        foreach ($new_values as $field => $new_value) {
            // Handle post fields (status → post_status)
            if (isset($fast_sync_post_fields[$field])) {
                $valid_statuses = array('publish', 'draft', 'pending', 'private');
                $status = sanitize_text_field($new_value);
                if (in_array($status, $valid_statuses)) {
                    $post_update['post_status'] = $status;
                    $updated_fields[] = "status={$status}";
                }
                continue;
            }

            $meta_key = $fast_sync_fields[$field];

            if ($field === 'stock_quantity') {
                update_post_meta($product_id, $meta_key, intval($new_value));
                update_post_meta($product_id, '_manage_stock', 'yes');
                // Auto-set stock status based on quantity
                $qty = intval($new_value);
                $stock_status = ($qty > 0) ? 'instock' : 'outofstock';
                update_post_meta($product_id, '_stock_status', $stock_status);
                $updated_fields[] = "qty={$qty}";
            } elseif (in_array($field, array('regular_price', 'sale_price'))) {
                $price_val = wc_format_decimal($new_value);
                update_post_meta($product_id, $meta_key, $price_val);
                $updated_fields[] = "{$field}={$price_val}";
            } elseif ($field === 'manage_stock') {
                $manage = ($new_value === 'yes' || $new_value === '1' || $new_value === true) ? 'yes' : 'no';
                update_post_meta($product_id, $meta_key, $manage);
            } elseif ($field === 'stock_status') {
                update_post_meta($product_id, $meta_key, sanitize_text_field($new_value));
                $updated_fields[] = "stock_status={$new_value}";
            }
        }

        // Apply post field updates (status) via direct SQL for speed
        if (!empty($post_update)) {
            $post_update['ID'] = $product_id;
            wp_update_post($post_update);
        }

        // Sync _price meta (WooCommerce needs this for frontend display/sorting)
        if (isset($new_values['regular_price']) || isset($new_values['sale_price'])) {
            $regular = get_post_meta($product_id, '_regular_price', true);
            $sale = get_post_meta($product_id, '_sale_price', true);
            $price = ('' !== $sale && $sale !== null && floatval($sale) > 0) ? $sale : $regular;
            update_post_meta($product_id, '_price', $price);
        }

        // Update import tracking (lightweight)
        update_post_meta($product_id, '_wc_import_id', $this->import_id);
        update_post_meta($product_id, '_wc_import_date', current_time('mysql'));

        // Clear WooCommerce transients for this product
        wc_delete_product_transients($product_id);

        $sku = $mapped_data['sku'] ?? '?';
        $this->log('info', sprintf('⚡ Fast-synced product ID %d, SKU: %s (%s)', $product_id, $sku, implode(', ', $updated_fields)), esc_html($sku));

        return $product_id;
    }

    /**
     * Compare product data to check if update is needed.
     *
     * @since    1.0.0
     * @param    int $product_id Existing product ID
     * @param    array $new_data New product data to import
     * @return   bool True if data has changed, false if identical
     */
    private function has_product_data_changed($product_id, $new_data) {
        $product = wc_get_product($product_id);
        
        if (!$product) {
            return true; // Product doesn't exist, needs creation
        }

        // Only compare fields that have update_on_sync=1
        // Comparing non-sync fields causes false positives (e.g. UTF-8 encoding diffs in description)
        $sync_fields = $this->get_sync_field_keys();

        // Compare basic fields
        $fields_to_compare = array(
            'name' => 'get_name',
            'description' => 'get_description',
            'short_description' => 'get_short_description',
            'regular_price' => 'get_regular_price',
            'sale_price' => 'get_sale_price',
            'stock_quantity' => 'get_stock_quantity',
            'weight' => 'get_weight',
            'length' => 'get_length',
            'width' => 'get_width',
            'height' => 'get_height',
        );

        foreach ($fields_to_compare as $field => $getter) {
            if (!isset($new_data[$field])) {
                continue; // Field not mapped, skip comparison
            }

            // Skip fields that are NOT being synced (update_on_sync=0)
            if (!empty($sync_fields) && !in_array($field, $sync_fields)) {
                continue;
            }

            $current_value = $product->$getter();
            $new_value = $new_data[$field];

            // Normalize values for comparison
            $current_value = trim((string)$current_value);
            $new_value = trim((string)$new_value);

            // For prices, compare as floats
            if (in_array($field, array('regular_price', 'sale_price', 'weight', 'length', 'width', 'height'))) {
                $current_value = floatval($current_value);
                $new_value = floatval($new_value);
            }

            // For stock quantity, compare as integers
            if ($field === 'stock_quantity') {
                $current_value = intval($current_value);
                $new_value = intval($new_value);
            }

            if ($current_value !== $new_value) {
                $this->log('info', sprintf(
                    'Field "%s" changed: "%s" → "%s"',
                    $field,
                    substr($current_value, 0, 50),
                    substr($new_value, 0, 50)
                ));
                return true; // Data has changed
            }
        }

        // Compare categories - only if syncing categories
        if (isset($new_data['categories']) && (empty($sync_fields) || in_array('categories', $sync_fields))) {
            $current_categories = wp_get_post_terms($product_id, 'product_cat', array('fields' => 'names'));
            $new_categories = is_array($new_data['categories']) ? $new_data['categories'] : array($new_data['categories']);
            
            sort($current_categories);
            sort($new_categories);
            
            if ($current_categories !== $new_categories) {
                $this->log('debug', 'Categories changed');
                return true;
            }
        }

        // Compare tags - only if syncing tags
        if (isset($new_data['tags']) && (empty($sync_fields) || in_array('tags', $sync_fields))) {
            $current_tags = wp_get_post_terms($product_id, 'product_tag', array('fields' => 'names'));
            $new_tags = is_array($new_data['tags']) ? $new_data['tags'] : explode(',', $new_data['tags']);
            $new_tags = array_map('trim', $new_tags);
            
            sort($current_tags);
            sort($new_tags);
            
            if ($current_tags !== $new_tags) {
                $this->log('debug', 'Tags changed');
                return true;
            }
        }

        // Compare brand - only if syncing brand
        if (isset($new_data['brand']) && (empty($sync_fields) || in_array('brand', $sync_fields))) {
            $current_brands = wp_get_post_terms($product_id, 'product_brand', array('fields' => 'names'));
            $new_brand = is_array($new_data['brand']) ? $new_data['brand'] : array($new_data['brand']);
            $new_brand = array_map('trim', $new_brand);
            
            sort($current_brands);
            sort($new_brand);
            
            if ($current_brands !== $new_brand) {
                $this->log('debug', 'Brand changed');
                return true;
            }
        }

        $this->log('debug', 'No changes detected - all data identical');
        return false; // No changes detected
    }

    /**
     * Get list of field keys that have update_on_sync=1.
     * Returns empty array if no sync fields defined (means update all).
     *
     * @since    1.3.0
     * @return   array
     */
    private function get_sync_field_keys() {
        if (isset($this->_cached_sync_fields)) {
            return $this->_cached_sync_fields;
        }

        $field_mappings = $this->config['field_mapping'] ?? array();
        $sync_fields = array();
        $has_any_sync_setting = false;

        foreach ($field_mappings as $field_key => $mapping) {
            if (!is_array($mapping)) continue;
            if (isset($mapping['update_on_sync'])) {
                $has_any_sync_setting = true;
                if ($mapping['update_on_sync'] === '1' || $mapping['update_on_sync'] === 1 || $mapping['update_on_sync'] === true) {
                    $sync_fields[] = $field_key;
                }
            }
        }

        // If no fields have update_on_sync setting at all, return empty (update all for backwards compat)
        $this->_cached_sync_fields = $has_any_sync_setting ? $sync_fields : array();
        return $this->_cached_sync_fields;
    }

    /**
     * Check if a field should be updated based on update_on_sync setting.
     *
     * @since    1.2.0
     * @param    string $field_key Field key (e.g., 'name', 'description')
     * @param    mixed $value The value to be set (used to check if empty/null)
     * @param    bool $is_new_product Whether this is a new product being created
     * @return   bool True if field should be updated, false otherwise
     */
    private function should_update_field($field_key, $value = null, $is_new_product = false) {
        // For NEW products, always save all mapped fields (ignore checkboxes)
        if ($is_new_product) {
            return true;
        }

        // FREE version: always update all fields (selective update is PRO feature)
        if (!WC_XML_CSV_AI_Import_Features::is_available('update_existing')) {
            return true;
        }

        // For EXISTING products (PRO only from here):
        // If no field mappings configured, update all fields (backwards compatibility)
        if (empty($this->config['field_mapping'])) {
            return true;
        }

        // Check if field has mapping configuration
        if (!isset($this->config['field_mapping'][$field_key])) {
            return true; // No mapping = update (backwards compatibility)
        }

        $mapping = $this->config['field_mapping'][$field_key];

        // Check update_on_sync flag - default to true if not set (backwards compatibility)
        if (!isset($mapping['update_on_sync'])) {
            return true;
        }

        // Get checkbox state ('1' = update enabled, '0' = update disabled)
        $update_enabled = $mapping['update_on_sync'] === '1' || $mapping['update_on_sync'] === 1 || $mapping['update_on_sync'] === true;

        // If checkbox is ENABLED, always update
        if ($update_enabled) {
            return true;
        }

        // If checkbox is DISABLED, NEVER update this field for existing products
        // This ensures that fields configured to NOT update are truly preserved
        return false;
    }

    /**
     * Update existing WooCommerce product.
     *
     * @since    1.0.0
     * @param    int $product_id Product ID
     * @param    array $product_data Processed product data
     * @param    array $mapped_data Mapped data with template strings for images
     * @return   int Product ID
     */
    private function update_product($product_id, $product_data, $mapped_data = array()) {
        $product = wc_get_product($product_id);
        
        if (!$product) {
            // translators: placeholder values
            throw new Exception(sprintf(esc_html__('Product with ID %d not found.', 'bootflow-product-importer'), intval($product_id)));
        }
        
        // DEBUG: Log update_product call

        // Update properties only if update_on_sync is enabled for that field
        // Pass false for $is_new_product since this is update_product
        if ($this->should_update_field('name', $product_data['name'] ?? null, false)) {
            $product->set_name($product_data['name'] ?? '');
        }

        if ($this->should_update_field('description', $product_data['description'] ?? null, false)) {
            $product->set_description($product_data['description'] ?? '');
        }

        if ($this->should_update_field('short_description', $product_data['short_description'] ?? null, false)) {
            $product->set_short_description($product_data['short_description'] ?? '');
        }

        if ($this->should_update_field('regular_price', $product_data['regular_price'] ?? null, false)) {
            $product->set_regular_price($product_data['regular_price'] ?? '');
        }

        // DEBUG: Log sale_price before setting
        if (defined('WP_DEBUG') && WP_DEBUG) { 
        }

        if ($this->should_update_field('sale_price', $product_data['sale_price'] ?? null, false)) {
            $product->set_sale_price($product_data['sale_price'] ?? '');
            if (defined('WP_DEBUG') && WP_DEBUG) { 
            }
        }

        // Sale price dates
        if (isset($product_data['sale_price_dates_from']) && !empty($product_data['sale_price_dates_from'])) {
            $product->set_date_on_sale_from($product_data['sale_price_dates_from']);
        }
        
        if (isset($product_data['sale_price_dates_to']) && !empty($product_data['sale_price_dates_to'])) {
            $product->set_date_on_sale_to($product_data['sale_price_dates_to']);
        }

        // Update stock quantity
        if (isset($product_data['stock_quantity']) && $this->should_update_field('stock_quantity', $product_data['stock_quantity'], false)) {
            $product->set_manage_stock(true);
            $product->set_stock_quantity($product_data['stock_quantity']);
        }

        // Update manage_stock (boolean field)
        // IMPORTANT: If manage_stock is YES but no stock_quantity provided, we need to handle stock_status differently
        $manage_stock_enabled = false;
        if (isset($product_data['manage_stock']) && $this->should_update_field('manage_stock', $product_data['manage_stock'], false)) {
            $manage = $product_data['manage_stock'];
            $manage_stock_enabled = ($manage === 'yes' || $manage === '1' || $manage === true || $manage === 1);
            $product->set_manage_stock($manage_stock_enabled);
        }

        // Update stock_status (instock/outofstock/onbackorder)
        // Store for later - WooCommerce may override this based on stock_quantity
        $force_stock_status = null;
        if (!empty($product_data['stock_status']) && $this->should_update_field('stock_status', $product_data['stock_status'], false)) {
            $force_stock_status = $product_data['stock_status'];
            $product->set_stock_status($product_data['stock_status']);
            $this->log('debug', 'Setting stock_status to: ' . $product_data['stock_status']);
        }

        // Update tax_status (taxable/shipping/none)
        if (!empty($product_data['tax_status']) && $this->should_update_field('tax_status', $product_data['tax_status'], false)) {
            $product->set_tax_status($product_data['tax_status']);
        }

        // Update tax_class
        if (isset($product_data['tax_class']) && $this->should_update_field('tax_class', $product_data['tax_class'], false)) {
            $product->set_tax_class($product_data['tax_class']);
        }

        // Update weight and dimensions
        if ($this->should_update_field('weight', $product_data['weight'] ?? null, false)) {
            $product->set_weight($product_data['weight'] ?? '');
        }

        if ($this->should_update_field('length', $product_data['length'] ?? null, false)) {
            $product->set_length($product_data['length'] ?? '');
        }

        if ($this->should_update_field('width', $product_data['width'] ?? null, false)) {
            $product->set_width($product_data['width'] ?? '');
        }

        if ($this->should_update_field('height', $product_data['height'] ?? null, false)) {
            $product->set_height($product_data['height'] ?? '');
        }

        // Shipping class - direct mapping or formula
        if (isset($product_data['shipping_class']) && !empty($product_data['shipping_class'])) {
            $shipping_class_slug = sanitize_title($product_data['shipping_class']);
            $shipping_class_term = get_term_by('slug', $shipping_class_slug, 'product_shipping_class');
            
            // Create shipping class if it doesn't exist
            if (!$shipping_class_term || is_wp_error($shipping_class_term)) {
                $new_term = wp_insert_term(
                    $product_data['shipping_class'], // Original name
                    'product_shipping_class',
                    array('slug' => $shipping_class_slug)
                );
                if (!is_wp_error($new_term)) {
                    $shipping_class_term = get_term($new_term['term_id'], 'product_shipping_class');
                    $this->log('debug', sprintf('Created shipping class: %s', $product_data['shipping_class']));
                }
            }
            
            if ($shipping_class_term && !is_wp_error($shipping_class_term)) {
                $product->set_shipping_class_id($shipping_class_term->term_id);
            }
        } elseif ($this->should_update_field('shipping_class', null, false)) {
            // Try Shipping Class Engine first (rules-based)
            $engine_assigned = $this->apply_shipping_class_engine($product, $product_data);
            
            if (!$engine_assigned) {
                // Fallback: old formula-based auto-assignment
                $this->auto_assign_shipping_class($product, $product_data);
            }
        }

        // Update status if provided - validate that status is a valid WordPress post_status
        if (isset($product_data['status']) && $this->should_update_field('status', $product_data['status'], false)) {
            $valid_statuses = array('publish', 'draft', 'pending', 'private', 'trash');
            $status = $product_data['status'];
            if (in_array($status, $valid_statuses)) {
                $product->set_status($status);
            } else {
                $this->log('warning', 'Invalid product status "' . $status . '" - skipping status update');
            }
        }

        // Update sold_individually
        if ($this->should_update_field('sold_individually', $product_data['sold_individually'] ?? null, false)) {
            $sold_ind = $product_data['sold_individually'] ?? '';
            $product->set_sold_individually($sold_ind === 'yes' || $sold_ind === '1' || $sold_ind === true);
        }

        // Update virtual/downloadable
        if ($this->should_update_field('virtual', $product_data['virtual'] ?? null, false)) {
            $product->set_virtual($product_data['virtual'] === 'yes' || $product_data['virtual'] === '1');
        }
        if ($this->should_update_field('downloadable', $product_data['downloadable'] ?? null, false)) {
            $product->set_downloadable($product_data['downloadable'] === 'yes' || $product_data['downloadable'] === '1');
        }

        // Update download limit/expiry
        if ($this->should_update_field('download_limit', $product_data['download_limit'] ?? null, false)) {
            $product->set_download_limit((int) ($product_data['download_limit'] ?? -1));
        }
        if ($this->should_update_field('download_expiry', $product_data['download_expiry'] ?? null, false)) {
            $product->set_download_expiry((int) ($product_data['download_expiry'] ?? -1));
        }

        // Update backorders
        if ($this->should_update_field('backorders', $product_data['backorders'] ?? null, false)) {
            $product->set_backorders($product_data['backorders'] ?? 'no');
        }

        // Update featured
        if ($this->should_update_field('featured', $product_data['featured'] ?? null, false)) {
            $product->set_featured($product_data['featured'] === 'yes' || $product_data['featured'] === '1');
        }
        
        // Update reviews allowed
        if ($this->should_update_field('reviews_allowed', $product_data['reviews_allowed'] ?? null, false)) {
            $product->set_reviews_allowed($product_data['reviews_allowed'] === 'yes' || $product_data['reviews_allowed'] === '1' || $product_data['reviews_allowed'] === true);
        }

        $product->save();
        
        // SYNC _price meta - WooCommerce needs this for frontend display
        $regular_price = $product->get_regular_price();
        $sale_price = $product->get_sale_price();
        $price = ('' !== $sale_price && $sale_price !== null) ? $sale_price : $regular_price;
        if ('' !== $price && $price !== null) {
            update_post_meta($product_id, '_price', $price);
        }
        
        // FORCE stock_status after save - WooCommerce may have overridden it based on stock_quantity
        if ($force_stock_status) {
            // Use direct database update to bypass WooCommerce hooks
            global $wpdb;
            $wpdb->update(
                $wpdb->postmeta,
                array('meta_value' => $force_stock_status),
                array('post_id' => $product_id, 'meta_key' => '_stock_status'),
                array('%s'),
                array('%d', '%s')
            );
            
            // Also clear WooCommerce product cache
            wc_delete_product_transients($product_id);
            wp_cache_delete($product_id, 'post_meta');
            
            // Debug
            
            $this->log('debug', 'Forced stock_status to: ' . $force_stock_status . ' for product ID: ' . $product_id);
        }
        
        // DEBUG: Verify saved stock_status after update - read directly from DB
        global $wpdb;
        $db_stock_status = $wpdb->get_var($wpdb->prepare("SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_stock_status'", $product_id));

        // Save/update product identifiers (EAN, UPC, ISBN, MPN, GTIN)
        $this->save_product_identifiers($product_id, $product_data);

        // Handle categories - ONLY if categories data exists AND update is enabled
        $categories_to_set = $product_data['categories'] ?? null;
        if (!empty($categories_to_set) && $this->should_update_field('categories', $categories_to_set, false)) {
            $this->set_product_categories($product_id, $categories_to_set);
        }

        // Handle tags - ONLY if tags data exists AND update is enabled
        $tags_to_set = $product_data['tags'] ?? null;
        if (!empty($tags_to_set) && $this->should_update_field('tags', $tags_to_set, false)) {
            $this->set_product_tags($product_id, $tags_to_set);
        }

        // Handle brand
        $this->log('debug', 'UPDATE_PRODUCT: Checking brand in product_data: ' . print_r($product_data['brand'] ?? 'NOT SET', true));
        if ($this->should_update_field('brand', $product_data['brand'] ?? null, false)) {
            $this->log('debug', 'UPDATE_PRODUCT: Brand value: ' . print_r($product_data['brand'], true));
            $this->set_product_brand($product_id, $product_data['brand'] ?? '');
        } else {
            $this->log('warning', 'UPDATE_PRODUCT: No brand data found or update disabled');
        }

        // Handle images
        $this->log('debug', 'UPDATE_PRODUCT: Starting image processing');
        $this->log('debug', 'mapped_data keys: ' . implode(', ', array_keys($mapped_data)));
        $this->log('debug', 'mapped images: ' . print_r($mapped_data['images'] ?? 'NOT SET', true));
        $this->log('debug', 'mapped featured_image: ' . print_r($mapped_data['featured_image'] ?? 'NOT SET', true));
        
        if ($this->should_update_field('images', $mapped_data['images'] ?? null, false)) {
            $this->log('debug', 'Calling set_product_images from update_product...');
            $this->set_product_images($product_id, $mapped_data);
        } else {
            $this->log('warning', 'UPDATE: Skipping images - update disabled!');
        }

        // Handle SEO meta fields
        if ($this->should_update_field('seo_title', null, false) || $this->should_update_field('seo_description', null, false) || $this->should_update_field('seo_keywords', null, false)) {
            $this->set_product_seo_meta($product_id, $product_data);
        }

        // Update import tracking meta
        update_post_meta($product_id, '_wc_import_id', $this->import_id);
        update_post_meta($product_id, '_wc_import_date', current_time('mysql'));
        update_post_meta($product_id, '_wc_import_source', 'update');

        return $product_id;
    }

    /**
     * Set product categories.
     *
     * @since    1.0.0
     * @param    int $product_id Product ID
     * @param    mixed $categories Categories (array or string)
     */
    private function set_product_categories($product_id, $categories) {
        if (is_string($categories)) {
            $categories = array_map('trim', explode(',', $categories));
        }

        $category_ids = array();
        $all_tags = array(); // Collect all category elements as tags
        $settings = get_option('wc_xml_csv_ai_import_settings', array());
        $auto_create = isset($settings['auto_create_categories']) ? $settings['auto_create_categories'] : true;

        $this->log_debug('SET_PRODUCT_CATEGORIES: Processing categories for product', array(
            'product_id' => $product_id,
            'categories' => $categories,
            'auto_create' => $auto_create
        ));

        foreach ($categories as $category_path) {
            $category_path = trim($category_path);
            if (empty($category_path)) continue;

            // Auto-detect separator: >, -, |, //, ->
            $separator = $this->detect_category_separator($category_path);
            
            if ($separator) {
                $this->log_debug('CATEGORY_HIERARCHY: Detected separator', array(
                    'path' => $category_path,
                    'separator' => $separator
                ));
                
                // Hierarchical category path detected
                $hierarchy_id = $this->create_category_hierarchy($category_path, $separator, $auto_create);
                if ($hierarchy_id) {
                    $category_ids[] = $hierarchy_id;
                    $this->log_debug('CATEGORY_HIERARCHY: Created hierarchy', array(
                        'path' => $category_path,
                        'final_category_id' => $hierarchy_id
                    ));
                }
                
                // Extract each element as a tag
                $elements = array_map('trim', explode($separator, $category_path));
                foreach ($elements as $element) {
                    if (!empty($element) && $element !== '>' && $element !== '-') {
                        $all_tags[] = $element;
                    }
                }
            } else {
                $this->log_debug('CATEGORY_SIMPLE: Single category (no hierarchy)', array(
                    'path' => $category_path
                ));
                
                // Single category (no hierarchy)
                $category = get_term_by('name', $category_path, 'product_cat');
                
                if (!$category && $auto_create) {
                    $result = wp_insert_term($category_path, 'product_cat');
                    if (!is_wp_error($result)) {
                        $category_ids[] = $result['term_id'];
                        $this->log_debug('CATEGORY_CREATED: New category', array(
                            'name' => $category_path,
                            'term_id' => $result['term_id']
                        ));
                    }
                } elseif ($category) {
                    $category_ids[] = $category->term_id;
                }
                
                // Add as tag
                $all_tags[] = $category_path;
            }
        }

        // Set categories
        if (!empty($category_ids)) {
            wp_set_object_terms($product_id, $category_ids, 'product_cat');
            $this->log_debug('CATEGORIES_ASSIGNED: Product categories set', array(
                'product_id' => $product_id,
                'category_ids' => $category_ids
            ));
        }
        
        // Set tags (all category elements)
        if (!empty($all_tags)) {
            $all_tags = array_unique($all_tags); // Remove duplicates
            wp_set_object_terms($product_id, $all_tags, 'product_tag', true); // Append tags
            $this->log_debug('TAGS_ASSIGNED: Product tags set from categories', array(
                'product_id' => $product_id,
                'tags' => $all_tags,
                'count' => count($all_tags)
            ));
        }
        
        // Auto-set category thumbnails from first product image
        $this->auto_set_category_thumbnails($category_ids, $product_id);
    }
    
    /**
     * Auto-set category thumbnails from first product image.
     * Only sets thumbnail if category doesn't have one already.
     *
     * @since    1.0.0
     * @param    array $category_ids Array of category term IDs
     * @param    int $product_id Product ID to get image from
     */
    private function auto_set_category_thumbnails($category_ids, $product_id) {
        if (empty($category_ids)) {
            return;
        }
        
        // Get product's featured image
        $thumbnail_id = get_post_thumbnail_id($product_id);
        
        if (!$thumbnail_id) {
            return; // Product has no image
        }
        
        foreach ($category_ids as $category_id) {
            // Check if category already has a thumbnail
            $existing_thumbnail = get_term_meta($category_id, 'thumbnail_id', true);
            
            if (empty($existing_thumbnail)) {
                // Category has no thumbnail, set it from product image
                update_term_meta($category_id, 'thumbnail_id', $thumbnail_id);
                
                $category = get_term($category_id, 'product_cat');
                $category_name = $category ? $category->name : "ID: $category_id";
                
                $this->log_debug('AUTO_CATEGORY_THUMBNAIL: Set from product', array(
                    'category_id' => $category_id,
                    'category_name' => $category_name,
                    'product_id' => $product_id,
                    'thumbnail_id' => $thumbnail_id
                ));
            }
        }
    }

    /**
     * Detect category separator in path string.
     * Supports: >, -, |, //, ->
     *
     * @param string $path Category path string
     * @return string|false Detected separator or false
     */
    private function detect_category_separator($path) {
        $separators = array('->', '//', '>', '-', '|');
        
        foreach ($separators as $sep) {
            if (strpos($path, $sep) !== false) {
                return $sep;
            }
        }
        
        return false;
    }

    /**
     * Create hierarchical category structure.
     *
     * @param string $path Full category path (e.g., "ZOO preces - Barības trauki - Doggy Village")
     * @param string $separator Separator character
     * @param bool $auto_create Whether to auto-create categories
     * @return int|false Category ID of the deepest level, or false on failure
     */
    private function create_category_hierarchy($path, $separator, $auto_create = true) {
        $elements = array_map('trim', explode($separator, $path));
        $elements = array_filter($elements); // Remove empty elements
        
        if (empty($elements)) {
            return false;
        }
        
        $this->log_debug('CREATE_CATEGORY_HIERARCHY: Starting', array(
            'full_path' => $path,
            'separator' => $separator,
            'elements' => $elements,
            'element_count' => count($elements)
        ));
        
        $parent_id = 0;
        $category_id = false;
        $hierarchy_path = array();
        
        foreach ($elements as $index => $category_name) {
            if (empty($category_name)) continue;
            
            $hierarchy_path[] = $category_name;
            $current_path = implode(' > ', $hierarchy_path);
            
            // Check if category exists with this parent
            $existing = get_term_by('name', $category_name, 'product_cat');
            
            if ($existing && $existing->parent == $parent_id) {
                // Category exists with correct parent
                $category_id = $existing->term_id;
                $this->log_debug('CATEGORY_EXISTS: Using existing category', array(
                    'level' => $index + 1,
                    'name' => $category_name,
                    'term_id' => $category_id,
                    'parent_id' => $parent_id,
                    'current_path' => $current_path
                ));
            } elseif ($existing && $existing->parent != $parent_id) {
                // Category exists but with different parent - check for duplicate
                $term_args = array(
                    'name' => $category_name,
                    'parent' => $parent_id,
                    'taxonomy' => 'product_cat',
                    'hide_empty' => false
                );
                $matching_terms = get_terms($term_args);
                
                if (!empty($matching_terms)) {
                    $category_id = $matching_terms[0]->term_id;
                    $this->log_debug('CATEGORY_FOUND: Found matching category with correct parent', array(
                        'level' => $index + 1,
                        'name' => $category_name,
                        'term_id' => $category_id,
                        'parent_id' => $parent_id,
                        'current_path' => $current_path
                    ));
                } elseif ($auto_create) {
                    // Create with correct parent
                    $result = wp_insert_term($category_name, 'product_cat', array('parent' => $parent_id));
                    if (!is_wp_error($result)) {
                        $category_id = $result['term_id'];
                        $this->log_debug('CATEGORY_CREATED: New category with parent', array(
                            'level' => $index + 1,
                            'name' => $category_name,
                            'term_id' => $category_id,
                            'parent_id' => $parent_id,
                            'current_path' => $current_path
                        ));
                    } else {
                        $this->log_debug('CATEGORY_ERROR: Failed to create', array(
                            'level' => $index + 1,
                            'name' => $category_name,
                            'parent_id' => $parent_id,
                            'error' => $result->get_error_message()
                        ));
                    }
                }
            } elseif (!$existing && $auto_create) {
                // Create new category
                $result = wp_insert_term($category_name, 'product_cat', array('parent' => $parent_id));
                if (!is_wp_error($result)) {
                    $category_id = $result['term_id'];
                    $this->log_debug('CATEGORY_CREATED: New root category', array(
                        'level' => $index + 1,
                        'name' => $category_name,
                        'term_id' => $category_id,
                        'parent_id' => $parent_id,
                        'current_path' => $current_path
                    ));
                } else {
                    $this->log_debug('CATEGORY_ERROR: Failed to create root', array(
                        'level' => $index + 1,
                        'name' => $category_name,
                        'parent_id' => $parent_id,
                        'error' => $result->get_error_message()
                    ));
                }
            }
            
            // Move to next level
            if ($category_id) {
                $parent_id = $category_id;
            }
        }
        
        $this->log_debug('CREATE_CATEGORY_HIERARCHY: Completed', array(
            'full_path' => $path,
            'final_category_id' => $category_id,
            'final_path' => implode(' > ', $hierarchy_path)
        ));
        
        return $category_id;
    }

    /**
     * Set product tags.
     *
     * @since    1.0.0
     * @param    int $product_id Product ID
     * @param    mixed $tags Tags (array or string)
     */
    /**
     * Set product tags.
     * Supports comma-separated tags and hierarchical separator detection.
     *
     * @since    1.0.0
     * @param    int $product_id Product ID
     * @param    mixed $tags Tags (array or string)
     */
    private function set_product_tags($product_id, $tags) {
        if (is_string($tags)) {
            // First split by comma (for multiple tag entries)
            $tag_entries = array_map('trim', explode(',', $tags));
            $all_tags = array();
            
            foreach ($tag_entries as $tag_entry) {
                if (empty($tag_entry)) continue;
                
                // Check if this entry has hierarchical separators
                $separator = $this->detect_category_separator($tag_entry);
                
                if ($separator) {
                    // Split hierarchical path into individual tags
                    $elements = array_map('trim', explode($separator, $tag_entry));
                    foreach ($elements as $element) {
                        if (!empty($element) && $element !== '>' && $element !== '-') {
                            $all_tags[] = $element;
                        }
                    }
                    
                    $this->log_debug('TAGS_HIERARCHICAL: Split tag entry', array(
                        'entry' => $tag_entry,
                        'separator' => $separator,
                        'tags' => $elements
                    ));
                } else {
                    // Single tag
                    $all_tags[] = $tag_entry;
                }
            }
            
            $tags = array_unique($all_tags); // Remove duplicates
            
            $this->log_debug('TAGS_PROCESSED: Final tags list', array(
                'product_id' => $product_id,
                'tags' => $tags,
                'count' => count($tags)
            ));
        }

        if (!empty($tags)) {
            wp_set_object_terms($product_id, $tags, 'product_tag');
        }
    }

    /**
     * Set product brand.
     *
     * @since    1.0.0
     * @param    int $product_id Product ID
     * @param    array $product_data Product data
     */
    private function save_product_identifiers($product_id, $product_data) {
        $field_mappings = $this->config['field_mapping'] ?? array();
        $primary_identifier = null;
        $primary_value = null;
        
        // Find which identifier is marked as primary
        $identifier_fields = array('ean', 'upc', 'isbn', 'mpn', 'gtin');
        foreach ($identifier_fields as $id_field) {
            if (isset($field_mappings[$id_field]['is_primary']) && 
                ($field_mappings[$id_field]['is_primary'] === '1' || $field_mappings[$id_field]['is_primary'] === 1)) {
                $primary_identifier = $id_field;
                break;
            }
        }
        
        // EAN - European Article Number
        if (!empty($product_data['ean'])) {
            update_post_meta($product_id, '_ean', sanitize_text_field($product_data['ean']));
            if ($primary_identifier === 'ean') {
                $primary_value = $product_data['ean'];
            }
        }
        
        // UPC - Universal Product Code
        if (!empty($product_data['upc'])) {
            update_post_meta($product_id, '_upc', sanitize_text_field($product_data['upc']));
            if ($primary_identifier === 'upc') {
                $primary_value = $product_data['upc'];
            }
        }
        
        // ISBN - International Standard Book Number
        if (!empty($product_data['isbn'])) {
            update_post_meta($product_id, '_isbn', sanitize_text_field($product_data['isbn']));
            if ($primary_identifier === 'isbn') {
                $primary_value = $product_data['isbn'];
            }
        }
        
        // MPN - Manufacturer Part Number
        if (!empty($product_data['mpn'])) {
            update_post_meta($product_id, '_mpn', sanitize_text_field($product_data['mpn']));
            if ($primary_identifier === 'mpn') {
                $primary_value = $product_data['mpn'];
            }
        }
        
        // GTIN - Global Trade Item Number
        if (!empty($product_data['gtin'])) {
            update_post_meta($product_id, '_gtin', sanitize_text_field($product_data['gtin']));
            if ($primary_identifier === 'gtin') {
                $primary_value = $product_data['gtin'];
            }
        }
        
        // Save primary identifier to WooCommerce standard field (_global_unique_id)
        if ($primary_value) {
            update_post_meta($product_id, '_global_unique_id', sanitize_text_field($primary_value));
            $this->log('debug', 'PRIMARY IDENTIFIER set for product ' . $product_id . ': ' . strtoupper($primary_identifier) . '=' . $primary_value);
        } elseif (!empty($product_data['gtin'])) {
            // Fallback: if no primary selected, use GTIN
            update_post_meta($product_id, '_global_unique_id', sanitize_text_field($product_data['gtin']));
        } elseif (!empty($product_data['ean'])) {
            // Fallback: if no GTIN, use EAN
            update_post_meta($product_id, '_global_unique_id', sanitize_text_field($product_data['ean']));
        }
        
        $this->log('debug', 'IDENTIFIERS saved for product ' . $product_id . ': EAN=' . ($product_data['ean'] ?? 'N/A') . ', UPC=' . ($product_data['upc'] ?? 'N/A') . ', Primary=' . ($primary_identifier ?? 'auto'));
    }

    /**
     * Set product brand.
     *
     * @since    1.0.0
     * @param    int $product_id Product ID
     * @param    mixed $brand Brand (string or array)
     */
    private function set_product_brand($product_id, $brand) {
        $this->log('debug', 'SET_PRODUCT_BRAND called with: ' . print_r($brand, true));
        
        if (is_string($brand)) {
            $brand = trim($brand);
        }

        $this->log('debug', 'SET_PRODUCT_BRAND wp_set_object_terms with brand: ' . print_r($brand, true));
        $result = wp_set_object_terms($product_id, $brand, 'product_brand');
        $this->log('debug', 'SET_PRODUCT_BRAND result: ' . print_r($result, true));
    }

    /**
     * Set product SEO meta fields.
     * Supports Yoast SEO, Rank Math, and All in One SEO plugins.
     *
     * @since    1.0.0
     * @param    int $product_id Product ID
     * @param    array $product_data Product data containing SEO fields
     */
    private function set_product_seo_meta($product_id, $product_data) {
        // Meta Title
        if (!empty($product_data['meta_title'])) {
            $meta_title = $product_data['meta_title'];
            
            // Yoast SEO
            if (defined('WPSEO_VERSION')) {
                update_post_meta($product_id, '_yoast_wpseo_title', $meta_title);
            }
            // Rank Math
            if (class_exists('RankMath')) {
                update_post_meta($product_id, 'rank_math_title', $meta_title);
            }
            // All in One SEO
            if (function_exists('aioseo')) {
                update_post_meta($product_id, '_aioseo_title', $meta_title);
            }
        }

        // Meta Description
        if (!empty($product_data['meta_description'])) {
            $meta_description = $product_data['meta_description'];
            
            // Yoast SEO
            if (defined('WPSEO_VERSION')) {
                update_post_meta($product_id, '_yoast_wpseo_metadesc', $meta_description);
            }
            // Rank Math
            if (class_exists('RankMath')) {
                update_post_meta($product_id, 'rank_math_description', $meta_description);
            }
            // All in One SEO
            if (function_exists('aioseo')) {
                update_post_meta($product_id, '_aioseo_description', $meta_description);
            }
        }

        // Meta Keywords (Focus Keyword for SEO plugins)
        if (!empty($product_data['meta_keywords'])) {
            $meta_keywords = $product_data['meta_keywords'];
            
            // Yoast SEO
            if (defined('WPSEO_VERSION')) {
                update_post_meta($product_id, '_yoast_wpseo_focuskw', $meta_keywords);
            }
            // Rank Math
            if (class_exists('RankMath')) {
                update_post_meta($product_id, 'rank_math_focus_keyword', $meta_keywords);
            }
            // All in One SEO
            if (function_exists('aioseo')) {
                update_post_meta($product_id, '_aioseo_keywords', $meta_keywords);
            }
        }
    }

    /**
     * Parse image placeholder syntax.
     * Supports: image* = all values, image[1] = first, image[2] = second, image = first value
     * Also supports old {field_name} syntax for backward compatibility
     * Example: image*, image[2], image, {image*}, {image[2]}, {image}
     *
     * @since    1.0.0
     * @param    string $template Template string with placeholders
     * @param    array $product_data Product data containing all XML fields
     * @return   array Array of image URLs
     */
    private function parse_image_placeholders($template, $product_data) {
        if (empty($template)) {
            return array();
        }

        $result_urls = array();
        
        // DEBUG: Log all image-related keys in product_data
        $image_related_keys = array_filter(array_keys($product_data), function($k) { 
            return stripos($k, 'image') !== false || stripos($k, 'bilde') !== false || stripos($k, 'attels') !== false;
        });
        $this->log('debug', "PARSE_IMAGE_PLACEHOLDERS: All image-related keys: " . implode(', ', $image_related_keys));
        
        // Split by comma, space, or both to support multiple entries like "{image1} {image2},{image3}"
        $entries = array_filter(array_map('trim', preg_split('/[\s,]+/', $template)));
        
        if (defined('WP_DEBUG') && WP_DEBUG) { error_log("PARSE_IMAGE_PLACEHOLDERS: Template='$template', entries=" . json_encode($entries)); }
        if (defined('WP_DEBUG') && WP_DEBUG) { error_log("PARSE_IMAGE_PLACEHOLDERS: product_data keys sample: " . implode(', ', array_slice(array_keys($product_data), 0, 30))); }
        
        foreach ($entries as $entry) {
            if (defined('WP_DEBUG') && WP_DEBUG) { error_log("PARSE_IMAGE_PLACEHOLDERS: Processing entry='$entry'"); }
            
            // field_name* or {field_name*} - all values from field_nameN (e.g., image1, image2, image3...)
            // Also checks for field_name.0, field_name.1 and field_name array
            if (preg_match('/^([a-zA-Z0-9_]+)\*$/', $entry, $matches) || preg_match('/^\{([a-zA-Z0-9_]+)\*\}$/', $entry, $matches)) {
                $field_base = $matches[1];
                $this->log('debug', "WILDCARD: Matched field_base='$field_base'");
                if (defined('WP_DEBUG') && WP_DEBUG) { error_log("PARSE_IMAGE_PLACEHOLDERS: Wildcard match for '$field_base*'"); }
                
                // FIRST: Check for numbered fields like image1, image2, image3... (common XML format)
                $numbered_values = array();
                $consecutive_empty = 0;
                for ($i = 1; $i <= 100; $i++) {
                    $numbered_key = $field_base . $i;
                    if (isset($product_data[$numbered_key])) {
                        $val = $this->extract_text_value($product_data[$numbered_key]);
                        if (!empty($val)) {
                            $numbered_values[] = $val;
                            $consecutive_empty = 0; // Reset empty counter
                            $this->log('debug', "WILDCARD: Found $numbered_key = " . substr($val, 0, 60));
                            if (defined('WP_DEBUG') && WP_DEBUG) { error_log("PARSE_IMAGE_PLACEHOLDERS: Found $numbered_key = " . substr($val, 0, 50)); }
                        } else {
                            // Field exists but is empty (like image5, image6 with no URL)
                            $consecutive_empty++;
                            $this->log('debug', "WILDCARD: $numbered_key is EMPTY (consecutive=$consecutive_empty)");
                            if ($consecutive_empty > 3) {
                                // Stop after 3 consecutive empty fields
                                break;
                            }
                        }
                    } else {
                        // Field doesn't exist at all - stop
                        $this->log('debug', "WILDCARD: $numbered_key NOT SET - stopping loop");
                        break;
                    }
                }
                
                $this->log('debug', "WILDCARD: Total numbered_values found: " . count($numbered_values));
                
                if (!empty($numbered_values)) {
                    $result_urls = array_merge($result_urls, $numbered_values);
                } else {
                    // FALLBACK: Try old format (field.0, field.1 or field array)
                    $field_values = $this->get_all_field_values($field_base, $product_data);
                    $result_urls = array_merge($result_urls, $field_values);
                }
            }
            // field_name[N] or {field_name[N]} - specific value by index (1-based)
            elseif (preg_match('/^([a-zA-Z0-9_]+)\[(\d+)\]$/', $entry, $matches) || preg_match('/^\{([a-zA-Z0-9_]+)\[(\d+)\]\}$/', $entry, $matches)) {
                $field_base = $matches[1];
                $index = intval($matches[2]);
                
                // First try numbered key (image1, image2...)
                $numbered_key = $field_base . $index;
                if (isset($product_data[$numbered_key]) && !empty($product_data[$numbered_key])) {
                    $val = $this->extract_text_value($product_data[$numbered_key]);
                    if (!empty($val)) {
                        $result_urls[] = $val;
                    }
                } else {
                    // Fallback to dot notation (0-based)
                    $field_key = $field_base . '.' . ($index - 1);
                    if (isset($product_data[$field_key])) {
                        $result_urls[] = $product_data[$field_key];
                    }
                }
            }
            // field_name or {field_name} - direct field access (e.g., {image1} gets product_data['image1'])
            elseif (preg_match('/^([a-zA-Z0-9_]+)$/', $entry, $matches) || preg_match('/^\{([a-zA-Z0-9_]+)\}$/', $entry, $matches)) {
                $field_name = $matches[1];
                if (defined('WP_DEBUG') && WP_DEBUG) { error_log("PARSE_IMAGE_PLACEHOLDERS: Direct field match for '$field_name'"); }
                
                // Try exact field name first (e.g., 'image1')
                if (isset($product_data[$field_name]) && !empty($product_data[$field_name])) {
                    $val = $this->extract_text_value($product_data[$field_name]);
                    if (!empty($val)) {
                        $result_urls[] = $val;
                        if (defined('WP_DEBUG') && WP_DEBUG) { error_log("PARSE_IMAGE_PLACEHOLDERS: Found $field_name = " . substr($val, 0, 50)); }
                    }
                }
                // Try field_name.0 (old format)
                elseif (isset($product_data[$field_name . '.0'])) {
                    $result_urls[] = $product_data[$field_name . '.0'];
                }
            }
            // Plain URL (no placeholder - starts with http)
            elseif (preg_match('/^https?:\/\//', $entry)) {
                $result_urls[] = $entry;
            }
        }

        // Remove empty values and return
        return array_filter(array_map('trim', $result_urls));
    }

    /**
     * Parse template string with {placeholder} syntax.
     * Replaces all {field.path} placeholders with actual values from product data.
     * Example: "{price.#text} {price.@attributes.currency}" becomes "1299.99 USD"
     *
     * @since    1.0.0
     * @param    string $template The template string with placeholders
     * @param    array  $product_data The product data array
     * @return   string The parsed string with placeholders replaced
     */
    private function parse_template_string($template, $product_data) {
        if (defined('WP_DEBUG') && WP_DEBUG) { error_log("TEMPLATE_PARSE: Input template: " . $template); }
        
        // Find all {placeholder} patterns - supports field.path, field.@attr, field.#text, etc.
        $result = preg_replace_callback(
            '/\{([^}]+)\}/',
            function($matches) use ($product_data) {
                $field_path = $matches[1];
                
                // Try to extract value using the appropriate parser
                if (!empty($this->xml_parser)) {
                    $value = $this->xml_parser->extract_field_value($product_data, $field_path);
                } elseif (!empty($this->csv_parser)) {
                    $value = $this->csv_parser->extract_field_value($product_data, $field_path);
                } else {
                    // Fallback: direct key access
                    $value = isset($product_data[$field_path]) ? $product_data[$field_path] : '';
                }
                
                // Handle array values
                if (is_array($value)) {
                    $value = $this->extract_text_value($value);
                }
                
                if (defined('WP_DEBUG') && WP_DEBUG) { error_log("TEMPLATE_PARSE: Placeholder {" . $field_path . "} = " . print_r($value, true)); }
                
                return $value !== null ? $value : '';
            },
            $template
        );
        
        // Trim and clean up multiple spaces
        $result = trim(preg_replace('/\s+/', ' ', $result));
        
        if (defined('WP_DEBUG') && WP_DEBUG) { error_log("TEMPLATE_PARSE: Output result: " . $result); }
        
        return $result;
    }

    /**
     * Parse field placeholders in a template string for variation data.
     * Supports {field.path} syntax and direct field access.
     * Used for custom meta fields in variations where we work with simple arrays.
     *
     * @since    1.0.0
     * @param    string $template The template string with placeholders like {field_name}
     * @param    array  $var_data The variation data array
     * @return   string|null The parsed value or null if not found
     */
    private function parse_field_placeholders($template, $var_data) {
        if (empty($template) || !is_string($template)) {
            return null;
        }
        
        // Check if it's a placeholder template {field}
        if (preg_match('/^\{([^}]+)\}$/', trim($template), $matches)) {
            // Single placeholder - extract the field name
            $field_path = $matches[1];
            
            // Try direct access first
            if (isset($var_data[$field_path])) {
                $value = $var_data[$field_path];
                return is_array($value) ? $this->extract_text_value($value) : (string)$value;
            }
            
            // Try nested path with dots (e.g., "meta.supplier_id")
            if (strpos($field_path, '.') !== false) {
                $parts = explode('.', $field_path);
                $current = $var_data;
                
                foreach ($parts as $part) {
                    if (is_array($current) && isset($current[$part])) {
                        $current = $current[$part];
                    } else {
                        return null;
                    }
                }
                
                return is_array($current) ? $this->extract_text_value($current) : (string)$current;
            }
            
            return null;
        }
        
        // Multiple placeholders in template string
        if (strpos($template, '{') !== false) {
            $result = preg_replace_callback(
                '/\{([^}]+)\}/',
                function($matches) use ($var_data) {
                    $field_path = $matches[1];
                    
                    // Try direct access
                    if (isset($var_data[$field_path])) {
                        $value = $var_data[$field_path];
                        return is_array($value) ? $this->extract_text_value($value) : (string)$value;
                    }
                    
                    // Try nested path
                    if (strpos($field_path, '.') !== false) {
                        $parts = explode('.', $field_path);
                        $current = $var_data;
                        
                        foreach ($parts as $part) {
                            if (is_array($current) && isset($current[$part])) {
                                $current = $current[$part];
                            } else {
                                return '';
                            }
                        }
                        
                        return is_array($current) ? $this->extract_text_value($current) : (string)$current;
                    }
                    
                    return '';
                },
                $template
            );
            
            return trim($result);
        }
        
        // No placeholders - treat as direct field name
        if (isset($var_data[$template])) {
            $value = $var_data[$template];
            return is_array($value) ? $this->extract_text_value($value) : (string)$value;
        }
        
        return null;
    }

    /**
     * Extract text value from various XML/array structures.
     * Handles: string, ['@content' => 'text'], ['@attributes' => [...], '@content' => 'text'], 
     * or SimpleXML-style arrays where text is nested.
     *
     * @since    1.0.0
     * @param    mixed $value The value to extract text from
     * @return   string|null The extracted text value or null if not found
     */
    private function extract_text_value($value) {
        // Already a string
        if (is_string($value)) {
            return $value;
        }
        
        // Not an array - convert to string if possible
        if (!is_array($value)) {
            return is_scalar($value) ? (string)$value : null;
        }
        
        // Check for #text key (XML text content from our parser)
        if (isset($value['#text'])) {
            return is_string($value['#text']) ? $value['#text'] : null;
        }
        
        // Check for @content key (alternative XML parsing style)
        if (isset($value['@content'])) {
            return is_string($value['@content']) ? $value['@content'] : null;
        }
        
        // Check for 0 key with string value (common in SimpleXML)
        if (isset($value[0]) && is_string($value[0])) {
            return $value[0];
        }
        
        // Look for any string value that looks like a URL or text content
        // Skip @attributes key
        foreach ($value as $key => $subvalue) {
            if ($key === '@attributes') {
                continue;
            }
            if (is_string($subvalue) && !empty($subvalue)) {
                // Prefer values that look like URLs for image fields
                if (filter_var($subvalue, FILTER_VALIDATE_URL)) {
                    return $subvalue;
                }
            }
        }
        
        // Last resort - get first non-attribute string value
        foreach ($value as $key => $subvalue) {
            if ($key === '@attributes') {
                continue;
            }
            if (is_string($subvalue)) {
                return $subvalue;
            }
            // Recurse one level
            if (is_array($subvalue)) {
                $extracted = $this->extract_text_value($subvalue);
                if ($extracted !== null) {
                    return $extracted;
                }
            }
        }
        
        return null;
    }

    /**
     * Get all values for a field base name (e.g., "image" returns all image.0, image.1, etc.)
     *
     * @since    1.0.0
     * @param    string $field_base Base field name
     * @param    array $product_data Product data
     * @return   array Array of field values
     */
    private function get_all_field_values($field_base, $product_data) {
        $values = array();
        
        // Safety check - ensure we have valid inputs
        if (!is_string($field_base) || empty($field_base)) {
            $this->log('warning', "get_all_field_values: Invalid field_base provided");
            return $values;
        }
        
        if (!is_array($product_data)) {
            $this->log('warning', "get_all_field_values: product_data is not an array");
            return $values;
        }
        
        $this->log('debug', "get_all_field_values: Looking for field '$field_base'");
        $this->log('debug', "Available keys sample: " . implode(', ', array_slice(array_keys($product_data), 0, 30)));
        
        // ZERO: Handle nested path like "eans.ean" or "package_dimensions.width"
        if (strpos($field_base, '.') !== false && !preg_match('/\.\d+$/', $field_base)) {
            $path_parts = explode('.', $field_base);
            $current = $product_data;
            foreach ($path_parts as $part) {
                if (is_array($current) && isset($current[$part])) {
                    $current = $current[$part];
                } else {
                    $current = null;
                    break;
                }
            }
            if ($current !== null) {
                $extracted = $this->extract_text_value($current);
                if ($extracted !== null && is_string($extracted)) {
                    $this->log('debug', "Found nested value for '$field_base': " . substr($extracted, 0, 50));
                    return [$extracted];
                } elseif (is_array($current) && isset($current[0])) {
                    // Array of values
                    foreach ($current as $index => $val) {
                        $ext = $this->extract_text_value($val);
                        if ($ext !== null && is_string($ext)) {
                            $values[$index] = $ext;
                        }
                    }
                    if (!empty($values)) {
                        ksort($values);
                        return array_values($values);
                    }
                }
            }
        }
        
        // FIRST: Check if field exists as PHP array directly
        if (isset($product_data[$field_base]) && is_array($product_data[$field_base])) {
            // Check if it's an indexed array [0, 1, 2...]
            if (isset($product_data[$field_base][0])) {
                $this->log('debug', "Found PHP indexed array for '$field_base' with " . count($product_data[$field_base]) . " items");
                foreach ($product_data[$field_base] as $index => $value) {
                    if (!empty($value)) {
                        // Handle XML elements with attributes: ['@attributes' => [...], '@content' => 'actual value']
                        // Or SimpleXML style: element text is in @content or as direct value
                        $extracted = $this->extract_text_value($value);
                        
                        // Ensure extracted is a string for logging
                        $log_value = is_string($extracted) ? substr($extracted, 0, 100) : '[complex value]';
                        $this->log('debug', "  [$index] = " . $log_value);
                        
                        if (is_string($extracted) && !empty($extracted)) {
                            $values[$index] = $extracted;
                        }
                    }
                }
            } else {
                // Associative array - could be single element with attributes
                $this->log('debug', "Found associative array for '$field_base'");
                $extracted = $this->extract_text_value($product_data[$field_base]);
                if (!empty($extracted) && is_string($extracted)) {
                    $values[0] = $extracted;
                }
            }
        }
        // SECOND: Check if field exists as simple value
        elseif (isset($product_data[$field_base]) && !is_array($product_data[$field_base])) {
            $this->log('debug', "Found simple value for '$field_base'");
            $values[0] = $product_data[$field_base];
        }
        // THIRD: Legacy - try dot notation (field.0, field.1)
        else {
            $this->log('debug', "Trying legacy dot notation for '$field_base'");
            foreach ($product_data as $key => $value) {
                if (preg_match('/^' . preg_quote($field_base, '/') . '\.(\d+)$/', $key, $matches)) {
                    $index = intval($matches[1]);
                    $extracted = $this->extract_text_value($value);
                    if (is_string($extracted)) {
                        $this->log('debug', "  Found: $key = " . substr($extracted, 0, 100));
                        $values[$index] = $extracted;
                    }
                }
            }
        }
        
        $this->log('debug', "get_all_field_values: Found " . count($values) . " values for '$field_base'");
        
        // Sort by index and return values
        ksort($values);
        return array_values($values);
    }

    /**
     * Set product images.
     *
     * @since    1.0.0
     * @param    int $product_id Product ID
     * @param    array $product_data Product data containing image URLs
     */
    private function set_product_images($product_id, $product_data) {
        $this->log('debug', '=== SET_PRODUCT_IMAGES CALLED ===');
        $this->log('debug', 'Product ID: ' . $product_id);
        $this->log('debug', 'images field: ' . print_r($product_data['images'] ?? 'NOT SET', true));
        $this->log('debug', 'featured_image field: ' . print_r($product_data['featured_image'] ?? 'NOT SET', true));
        
        $image_urls = array();

        // Process 'images' field with placeholder support
        if (!empty($product_data['images'])) {
            $this->log('debug', 'Processing images field...');
            if (is_string($product_data['images'])) {
                $this->log('debug', 'Images is string: ' . $product_data['images']);
                // DEBUG: Log current_raw_product_data image keys
                $raw_image_keys = array_filter(array_keys($this->current_raw_product_data), function($k) { return strpos($k, 'image') !== false; });
                $this->log('debug', 'current_raw_product_data image keys: ' . implode(', ', $raw_image_keys));
                $this->log('debug', 'image1 value: ' . ($this->current_raw_product_data['image1'] ?? 'NOT SET'));
                $this->log('debug', 'image2 value: ' . ($this->current_raw_product_data['image2'] ?? 'NOT SET'));
                $this->log('debug', 'image3 value: ' . ($this->current_raw_product_data['image3'] ?? 'NOT SET'));
                // Parse placeholders like image*, image[1] against RAW product data
                $parsed_images = $this->parse_image_placeholders($product_data['images'], $this->current_raw_product_data);
                $this->log('debug', 'Parsed ' . count($parsed_images) . ' images');
                if (!empty($parsed_images)) {
                    $this->log('debug', 'Parsed image URLs: ' . implode(', ', array_map(function($u) { return substr($u, 0, 60); }, $parsed_images)));
                }
                $image_urls = array_merge($image_urls, $parsed_images);
            } else {
                $this->log('debug', 'Images is array');
                $additional_images = (array)$product_data['images'];
                $image_urls = array_merge($image_urls, $additional_images);
            }
        } else {
            $this->log('warning', 'Images field is EMPTY!');
        }

        // Process 'featured_image' field with placeholder support
        if (!empty($product_data['featured_image'])) {
            $this->log('debug', 'Featured image present: ' . $product_data['featured_image']);
            
            // Check if it's a placeholder template like {image2}
            if (is_string($product_data['featured_image']) && strpos($product_data['featured_image'], '{') !== false) {
                $this->log('debug', 'Featured image is placeholder template, parsing...');
                $parsed_featured = $this->parse_image_placeholders($product_data['featured_image'], $this->current_raw_product_data);
                if (!empty($parsed_featured)) {
                    $this->log('debug', 'Parsed featured image URL: ' . $parsed_featured[0]);
                    // If featured_image is specified, it takes priority as first image
                    array_unshift($image_urls, $parsed_featured[0]);
                } else {
                    $this->log('warning', 'Failed to parse featured_image placeholder!');
                }
            } else {
                // Direct URL - use as-is
                array_unshift($image_urls, $product_data['featured_image']);
            }
        } else {
            $this->log('warning', 'Featured image field is EMPTY!');
        }
        
        $this->log('debug', 'Total image URLs: ' . count($image_urls));
        
        // If no featured_image but we have images, first image becomes featured
        // (This is already handled by the order above)

        if (empty($image_urls)) {
            $this->log('warning', 'NO IMAGE URLS - exiting set_product_images');
            return;
        }

        // Use parallel download for better performance (5 concurrent downloads)
        $this->log('debug', 'Starting PARALLEL image download for ' . count($image_urls) . ' URLs');
        $attachment_ids = $this->download_images_parallel($image_urls, $product_id, 5);

        if (!empty($attachment_ids)) {
            $this->log('debug', 'Downloaded ' . count($attachment_ids) . ' images successfully');
            
            // Set featured image
            set_post_thumbnail($product_id, $attachment_ids[0]);
            $this->log('debug', 'Set featured image: ' . $attachment_ids[0]);

            // Set gallery images
            if (count($attachment_ids) > 1) {
                $gallery_ids = implode(',', array_slice($attachment_ids, 1));
                update_post_meta($product_id, '_product_image_gallery', $gallery_ids);
                $this->log('debug', 'Set gallery images: ' . $gallery_ids);
            } else {
                $this->log('debug', 'Only 1 image - no gallery');
            }
        } else {
            $this->log('error', 'NO ATTACHMENTS downloaded!');
        }
    }

    /**
     * Check if an image already exists in the media library by URL.
     * This prevents re-downloading the same image multiple times.
     *
     * @since    1.0.0
     * @param    string $image_url Image URL to check
     * @return   int|false Attachment ID if exists, false otherwise
     */
    private function get_existing_attachment_by_url($image_url) {
        global $wpdb;
        
        // Method 1: Check by _source_url meta (set during import)
        $attachment_id = $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_source_url' AND meta_value = %s LIMIT 1",
            $image_url
        ));
        
        if ($attachment_id) {
            // Verify attachment still exists
            if (get_post($attachment_id)) {
                return intval($attachment_id);
            }
        }
        
        // Method 2: Check by filename in guid (less reliable but catches manual uploads)
        $filename = sanitize_file_name(pathinfo($image_url, PATHINFO_FILENAME));
        if (!empty($filename) && strlen($filename) > 3) {
            $attachment_id = $wpdb->get_var($wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts} 
                WHERE post_type = 'attachment' 
                AND post_status = 'inherit'
                AND guid LIKE %s 
                LIMIT 1",
                '%' . $wpdb->esc_like($filename) . '%'
            ));
            
            if ($attachment_id && get_post($attachment_id)) {
                return intval($attachment_id);
            }
        }
        
        return false;
    }

    /**
     * Download multiple images using WordPress HTTP API.
     * Uses wp_remote_get() for WordPress.org compliance.
     *
     * @since    1.0.0
     * @param    array $image_urls Array of image URLs
     * @param    int $product_id Product ID
     * @param    int $max_concurrent Maximum concurrent downloads (not used, kept for compatibility)
     * @return   array Array of attachment IDs (preserving order)
     */
    private function download_images_parallel($image_urls, $product_id, $max_concurrent = 5) {
        // Include required files
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        
        $attachment_ids = array();
        $urls_to_download = array();
        $skipped_count = 0;
        
        // Filter valid URLs and check for existing attachments first
        foreach ($image_urls as $index => $url) {
            $url = trim($url);
            if (!empty($url) && filter_var($url, FILTER_VALIDATE_URL)) {
                // Check if this image already exists in media library
                $existing_id = $this->get_existing_attachment_by_url($url);
                if ($existing_id) {
                    $attachment_ids[$index] = $existing_id;
                    $skipped_count++;
                    $this->log('debug', 'Image already exists (ID: ' . $existing_id . '), skipping download: ' . basename($url));
                } else {
                    $urls_to_download[$index] = $url;
                }
            }
        }
        
        if ($skipped_count > 0) {
            $this->log('debug', 'Skipped ' . $skipped_count . ' images (already in media library)');
        }
        
        // If all images already exist, just return them
        if (empty($urls_to_download)) {
            $this->log('debug', 'All ' . count($attachment_ids) . ' images already exist - no downloads needed!');
            ksort($attachment_ids);
            return array_values($attachment_ids);
        }
        
        $this->log('debug', 'Downloading ' . count($urls_to_download) . ' NEW images using WordPress HTTP API');
        
        // Download each image using WordPress HTTP API
        foreach ($urls_to_download as $index => $url) {
            try {
                // Download using WordPress HTTP API
                $response = wp_remote_get($url, array(
                    'timeout' => 30,
                    'redirection' => 5,
                    'sslverify' => false,
                    'user-agent' => 'Mozilla/5.0 (compatible; WooCommerce Import)',
                    'headers' => array(
                        'Accept' => 'image/*,*/*',
                    ),
                ));
                
                // Check for errors
                if (is_wp_error($response)) {
                    $this->log('warning', 'Failed to download image ' . ($index + 1) . ': ' . $url . ' (' . $response->get_error_message() . ')');
                    continue;
                }
                
                $http_code = wp_remote_retrieve_response_code($response);
                $body = wp_remote_retrieve_body($response);
                
                if ($http_code !== 200 || empty($body) || strlen($body) < 100) {
                    $this->log('warning', 'Failed to download image ' . ($index + 1) . ': ' . $url . ' (HTTP: ' . $http_code . ')');
                    continue;
                }
                
                // Create temp file and write content
                $temp_file = wp_tempnam(basename($url));
                // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Writing downloaded image to temp file
                $write_result = file_put_contents($temp_file, $body);
                
                if ($write_result === false) {
                    $this->log('warning', 'Failed to write temp file for: ' . $url);
                    continue;
                }
                
                // Detect file type
                $file_info = wp_check_filetype(basename($url));
                
                // If no extension detected from URL, try to detect from content
                if (empty($file_info['ext'])) {
                    $mime_type = mime_content_type($temp_file);
                    $ext_map = array(
                        'image/jpeg' => 'jpg',
                        'image/png' => 'png',
                        'image/gif' => 'gif',
                        'image/webp' => 'webp'
                    );
                    $file_info['ext'] = isset($ext_map[$mime_type]) ? $ext_map[$mime_type] : 'jpg';
                    $file_info['type'] = $mime_type;
                }
                
                // Prepare file array
                $file_array = array(
                    'name' => sanitize_file_name(pathinfo($url, PATHINFO_FILENAME)) . '.' . $file_info['ext'],
                    'tmp_name' => $temp_file
                );
                
                // Upload file
                $attachment_id = media_handle_sideload($file_array, $product_id);
                
                // Clean up temp file
                @wp_delete_file($temp_file);
                
                if (is_wp_error($attachment_id)) {
                    $this->log('warning', 'Failed to attach image ' . ($index + 1) . ': ' . $attachment_id->get_error_message());
                    continue;
                }
                
                // Store source URL for future duplicate detection
                update_post_meta($attachment_id, '_source_url', $url);
                
                $attachment_ids[$index] = $attachment_id;
                $this->log('debug', 'Downloaded image ' . ($index + 1) . ', attachment ID: ' . $attachment_id);
                
            } catch (Exception $e) {
                $this->log('warning', 'Error processing image ' . ($index + 1) . ': ' . $e->getMessage());
            }
        }
        
        // Sort by original index to preserve order
        ksort($attachment_ids);
        
        $this->log('debug', 'Download completed: ' . count($attachment_ids) . ' images (downloaded: ' . count($urls_to_download) . ', cached: ' . $skipped_count . ')');
        
        return array_values($attachment_ids);
    }

    /**
     * Download and attach image to product.
     *
     * @since    1.0.0
     * @param    string $image_url Image URL
     * @param    int $product_id Product ID
     * @return   int|false Attachment ID or false on failure
     */
    private function download_and_attach_image($image_url, $product_id) {
        // Include required files
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');

        // Download image
        $temp_file = download_url($image_url);

        if (is_wp_error($temp_file)) {
            throw new Exception(esc_html($temp_file->get_error_message()));
        }

        // Get file info
        $file_info = wp_check_filetype(basename($image_url));
        if (!$file_info['ext']) {
            wp_delete_file($temp_file);
            throw new Exception(esc_html__('Invalid image file type.', 'bootflow-product-importer'));
        }

        // Prepare file array
        $file_array = array(
            'name' => basename($image_url),
            'tmp_name' => $temp_file
        );

        // Upload file
        $attachment_id = media_handle_sideload($file_array, $product_id);

        // Clean up temp file
        @wp_delete_file($temp_file);

        if (is_wp_error($attachment_id)) {
            throw new Exception(esc_html($attachment_id->get_error_message()));
        }

        // Store source URL for future duplicate detection
        update_post_meta($attachment_id, '_source_url', $image_url);

        return $attachment_id;
    }

    /**
     * Process custom fields.
     *
     * @since    1.0.0
     * @param    int $product_id Product ID
     * @param    array $product_data Raw product data
     */
    private function process_custom_fields($product_id, $product_data) {
        // Check if custom_fields exists in config
        if (!isset($this->config['custom_fields'])) {
            return;
        }
        
        $custom_fields = $this->config['custom_fields'];
        
        // If it's a string, decode it
        if (is_string($custom_fields)) {
            $custom_fields = json_decode($custom_fields, true);
        }

        if (empty($custom_fields) || !is_array($custom_fields)) {
            return;
        }

        foreach ($custom_fields as $field_config) {
            if (empty($field_config['name']) || empty($field_config['source'])) {
                continue;
            }

            // Use sanitize_text_field instead of sanitize_key to preserve Unicode characters (like "Tesīt")
            // sanitize_key() converts to lowercase and removes non-ASCII characters
            $field_name = sanitize_text_field($field_config['name']);
            $source_field = $field_config['source'];

            // Extract value
            if ($this->config['file_type'] === 'xml') {
                $value = $this->xml_parser->extract_field_value($product_data, $source_field);
            } else {
                $value = $this->csv_parser->extract_field_value($product_data, $source_field);
            }

            if ($value !== null) {
                // Process value if configured
                if (isset($field_config['processing_mode']) && $field_config['processing_mode'] !== 'direct') {
                    $value = $this->processor->process_field($value, $field_config, $product_data);
                }

                // Save as meta - use field name directly (no underscore prefix) so it shows in Custom Fields
                // Note: Fields starting with _ are hidden in WordPress admin
                update_post_meta($product_id, $field_name, $value);
            }
        }
    }

    /**
     * Process product attributes & variations.
     *
     * @since    1.0.0
     * @param    int $product_id Product ID
     * @param    array $product_data Raw product data
     */
    private function process_product_attributes($product_id, $product_data) {
        $log_file = WP_CONTENT_DIR . '/attributes_debug.log';
        
        
        
        // Check if attributes configuration exists
        if (!isset($this->config['field_mapping']['attributes_variations'])) {
            return;
        }

        
        $attributes_config = $this->config['field_mapping']['attributes_variations'];
        
        // If it's a string, decode it
        if (is_string($attributes_config)) {
            $attributes_config = json_decode($attributes_config, true);
        }

        // ═══════════════════════════════════════════════════════════════════════════
        // NORMALIZE FIRST: Convert new UI format to old format BEFORE any checks!
        // This ensures variation_attributes → attributes conversion happens early
        // ═══════════════════════════════════════════════════════════════════════════
        $product_mode = $attributes_config['product_mode'] ?? null;
        $variation_mode = $attributes_config['variation_mode'] ?? 'auto';
        
        
        // If new product_mode is set, convert to old format for compatibility
        if ($product_mode === 'variable') {
            $variation_mode = 'map';
            // Convert new variation_path to old map_config format
            if (!empty($attributes_config['variation_path']) && empty($attributes_config['map_config']['container_xpath'])) {
                $attributes_config['map_config'] = $attributes_config['map_config'] ?? array();
                $attributes_config['map_config']['container_xpath'] = $attributes_config['variation_path'];
            }
            // Convert new variation_fields to old map_config format
            if (!empty($attributes_config['variation_fields']) && is_array($attributes_config['variation_fields'])) {
                $vf = $attributes_config['variation_fields'];
                $attributes_config['map_config']['sku_source'] = $vf['sku'] ?? '';
                $attributes_config['map_config']['parent_sku_source'] = $vf['parent_sku'] ?? '';
                $attributes_config['map_config']['price_source'] = $vf['regular_price'] ?? '';
                $attributes_config['map_config']['sale_price_source'] = $vf['sale_price'] ?? '';
                $attributes_config['map_config']['sale_price_dates_from_source'] = $vf['sale_price_dates_from'] ?? '';
                $attributes_config['map_config']['sale_price_dates_to_source'] = $vf['sale_price_dates_to'] ?? '';
                $attributes_config['map_config']['stock_source'] = $vf['stock_quantity'] ?? '';
                $attributes_config['map_config']['stock_status_source'] = $vf['stock_status'] ?? '';
                $attributes_config['map_config']['manage_stock_source'] = $vf['manage_stock'] ?? '';
                $attributes_config['map_config']['low_stock_amount_source'] = $vf['low_stock_amount'] ?? '';
                $attributes_config['map_config']['backorders_source'] = $vf['backorders'] ?? '';
                $attributes_config['map_config']['backorders_default'] = $vf['backorders_default'] ?? '';
                $attributes_config['map_config']['weight_source'] = $vf['weight'] ?? '';
                $attributes_config['map_config']['weight_inherit'] = !empty($vf['weight_inherit']);
                $attributes_config['map_config']['length_source'] = $vf['length'] ?? '';
                $attributes_config['map_config']['width_source'] = $vf['width'] ?? '';
                $attributes_config['map_config']['height_source'] = $vf['height'] ?? '';
                $attributes_config['map_config']['dimensions_inherit'] = !empty($vf['dimensions_inherit']);
                $attributes_config['map_config']['description_source'] = $vf['description'] ?? '';
                $attributes_config['map_config']['shipping_class_source'] = $vf['shipping_class'] ?? '';
                $attributes_config['map_config']['image_source'] = $vf['image'] ?? '';
                $attributes_config['map_config']['virtual_source'] = $vf['virtual'] ?? '';
                $attributes_config['map_config']['downloadable_source'] = $vf['downloadable'] ?? '';
                $attributes_config['map_config']['download_limit_source'] = $vf['download_limit'] ?? '';
                $attributes_config['map_config']['download_expiry_source'] = $vf['download_expiry'] ?? '';
                $attributes_config['map_config']['downloads_source'] = $vf['downloads'] ?? '';
                // Product identifiers
                $attributes_config['map_config']['ean_source'] = $vf['ean'] ?? '';
                $attributes_config['map_config']['upc_source'] = $vf['upc'] ?? '';
                $attributes_config['map_config']['gtin_source'] = $vf['gtin'] ?? '';
                $attributes_config['map_config']['isbn_source'] = $vf['isbn'] ?? '';
                $attributes_config['map_config']['mpn_source'] = $vf['mpn'] ?? '';
            }
            // Pass custom meta fields for variations (can come as 'var_meta' or 'variation_meta' from JS)
            $var_meta = $attributes_config['var_meta'] ?? $attributes_config['variation_meta'] ?? array();
            if (!empty($var_meta) && is_array($var_meta)) {
                $attributes_config['map_config']['var_meta'] = $var_meta;
            }
            // Convert new variation_attributes to old attributes format
            if (!empty($attributes_config['variation_attributes']) && is_array($attributes_config['variation_attributes'])) {
                $attributes_config['attributes'] = array();
                foreach ($attributes_config['variation_attributes'] as $varAttr) {
                    $attributes_config['attributes'][] = array(
                        'name' => $varAttr['name'] ?? '',
                        'values_source' => $varAttr['source'] ?? '',
                        'array_index' => isset($varAttr['array_index']) ? $varAttr['array_index'] : null,
                        'visible' => 1,
                        'used_for_variations' => 1
                    );
                }
            }
        } elseif ($product_mode === 'attributes' || $product_mode === 'simple') {
            // Simple or attributes mode - no variations
            $variation_mode = 'none';
        }
        
        $attributes_config['variation_mode'] = $variation_mode;

        // ═══════════════════════════════════════════════════════════════════════════
        // NOW check for attributes (after normalization)
        // ═══════════════════════════════════════════════════════════════════════════
        
        // Also check for display_attributes and attribute_pairs (key-value mode)
        $has_variation_attributes_config = !empty($attributes_config['attributes']) && is_array($attributes_config['attributes']);
        $has_display_attributes_config = !empty($attributes_config['display_attributes']) && is_array($attributes_config['display_attributes']);
        $has_attribute_pairs_config = !empty($attributes_config['attribute_pairs']) && is_array($attributes_config['attribute_pairs']);
        
        
        // Only return if ALL are empty (and not variable product mode)
        if (!$has_variation_attributes_config && !$has_display_attributes_config && !$has_attribute_pairs_config && $product_mode !== 'variable') {
            return;
        }



        $product = wc_get_product($product_id);
        if (!$product) {
            return;
        }

        $map_config = $attributes_config['map_config'] ?? array();
        
        // Check variation mode - if MAP mode, auto-detect attributes from variations
        
        // AUTO-DETECT ATTRIBUTES FROM VARIATIONS (when in MAP mode)
        if ($variation_mode === 'map') {
            $container_xpath = $map_config['container_xpath'] ?? 'variations.variation';
            $variations_data = $this->get_nested_value($product_data, $container_xpath);
            
            if (!empty($variations_data)) {
                // Ensure array format
                if (!isset($variations_data[0])) {
                    $variations_data = array($variations_data);
                }
                
                
                // Check if we need to auto-detect attributes:
                // 1. No valid attributes configured, OR
                // 2. Configured attributes don't exist in THIS product's variations
                $need_auto_detect = true;
                $first_variation = $variations_data[0];
                $first_var_attrs = $this->get_nested_value($first_variation, 'attributes');
                
                foreach ($attributes_config['attributes'] as $attr) {
                    if (!empty($attr['name'])) {
                        // Check if this attribute name (lowercase) exists in the variation's attributes
                        $attr_key = strtolower(str_replace(' ', '_', $attr['name']));
                        
                        if (!empty($first_var_attrs) && is_array($first_var_attrs)) {
                            // Check for attribute in various formats
                            $found = false;
                            foreach (array_keys($first_var_attrs) as $key) {
                                if (strtolower($key) === $attr_key) {
                                    $found = true;
                                    break;
                                }
                            }
                            if ($found) {
                                $need_auto_detect = false;
                                break;
                            }
                        }
                    }
                }
                
                if ($need_auto_detect && defined('WP_DEBUG') && WP_DEBUG) { 
                }
                
                if ($need_auto_detect) {
                    
                    // Get attributes from first variation
                    $first_variation = $variations_data[0];
                    $attrs_data = $this->get_nested_value($first_variation, 'attributes');
                    
                    if (!empty($attrs_data) && is_array($attrs_data)) {
                        
                        // Create attributes config from detected keys
                        $auto_attributes = array();
                        
                        // ════════════════════════════════════════════════════════
                        // FORMAT A: <attribute name="Size">S</attribute>
                        // Parsed as: ['attribute' => [['@attributes' => ['name' => 'Size'], '#text' => 'S'], ...]]
                        // ════════════════════════════════════════════════════════
                        if (isset($attrs_data['attribute']) && is_array($attrs_data['attribute'])) {
                            $attr_items = $attrs_data['attribute'];
                            // Normalize single attribute to array
                            if (!isset($attr_items[0])) {
                                $attr_items = array($attr_items);
                            }
                            
                            // Check if first item has @attributes.name (XML attribute format)
                            $first_item = $attr_items[0];
                            if (is_array($first_item) && (
                                isset($first_item['@attributes']['name']) || 
                                isset($first_item['@name']) || 
                                (isset($first_item['name']) && isset($first_item['value']))
                            )) {
                                // Collect all unique attribute names from ALL variations
                                $all_attr_names = array();
                                foreach ($variations_data as $var) {
                                    $var_attrs = $this->get_nested_value($var, 'attributes');
                                    if (!empty($var_attrs) && isset($var_attrs['attribute'])) {
                                        $items = $var_attrs['attribute'];
                                        if (!isset($items[0])) $items = array($items);
                                        foreach ($items as $item) {
                                            if (is_array($item)) {
                                                $aname = $item['@attributes']['name'] ?? $item['@name'] ?? $item['name'] ?? '';
                                                if (!empty($aname) && !in_array($aname, $all_attr_names)) {
                                                    $all_attr_names[] = $aname;
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                // For each unique attribute name, collect all values across all variations
                                foreach ($all_attr_names as $attr_name) {
                                    $all_values = array();
                                    foreach ($variations_data as $var) {
                                        $var_attrs = $this->get_nested_value($var, 'attributes');
                                        if (!empty($var_attrs) && isset($var_attrs['attribute'])) {
                                            $items = $var_attrs['attribute'];
                                            if (!isset($items[0])) $items = array($items);
                                            foreach ($items as $item) {
                                                if (is_array($item)) {
                                                    $iname = $item['@attributes']['name'] ?? $item['@name'] ?? $item['name'] ?? '';
                                                    if (strcasecmp($iname, $attr_name) === 0) {
                                                        $val = $item['#text'] ?? $item['#value'] ?? $item['value'] ?? '';
                                                        if (!empty($val) && is_string($val)) {
                                                            $all_values[] = trim($val);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    $all_values = array_unique($all_values);
                                    
                                    if (!empty($all_values)) {
                                        $auto_attributes[] = array(
                                            'name' => $attr_name,
                                            'xml_attribute_key' => $attr_name,
                                            'values_source' => '',
                                            'visible' => 1,
                                            'used_for_variations' => 1,
                                            '_auto_values' => $all_values
                                        );
                                    }
                                }
                            }
                        }
                        
                        // ════════════════════════════════════════════════════════
                        // FORMAT B: <size>S</size> <color>Red</color>
                        // Parsed as: ['size' => 'S', 'color' => 'Red']
                        // ════════════════════════════════════════════════════════
                        if (empty($auto_attributes)) {
                        foreach (array_keys($attrs_data) as $attr_key) {
                            // Skip numeric keys and special elements
                            if (is_numeric($attr_key) || $attr_key === '@attributes') {
                                continue;
                            }
                            
                            
                            // Collect all values for this attribute from all variations
                            $all_values = array();
                            foreach ($variations_data as $var) {
                                $var_attrs = $this->get_nested_value($var, 'attributes');
                                if (isset($var_attrs[$attr_key]) && !empty($var_attrs[$attr_key])) {
                                    $all_values[] = $var_attrs[$attr_key];
                                }
                            }
                            $all_values = array_unique($all_values);
                            
                            $auto_attributes[] = array(
                                'name' => ucfirst($attr_key),  // Capitalize for display
                                'xml_attribute_key' => $attr_key,
                                'values_source' => '',
                                'visible' => 1,
                                'used_for_variations' => 1,
                                '_auto_values' => $all_values  // Pre-collected values
                            );
                            
                        }
                        } // End FORMAT B (if empty($auto_attributes))
                        
                        // Replace empty attributes with auto-detected ones
                        if (!empty($auto_attributes)) {
                            $attributes_config['attributes'] = $auto_attributes;
                        }
                    } else {
                    }
                }
            }
        }
        
        // CRITICAL: Check if any attributes are marked as "used for variations"
        // AND if actual variation data exists in XML/CSV
        $has_variation_attributes = false;
        foreach ($attributes_config['attributes'] as $attr_config) {
            if (isset($attr_config['used_for_variations']) && $attr_config['used_for_variations'] == 1) {
                $has_variation_attributes = true;
                break;
            }
        }
        
        // Check if actual variation data exists in product_data
        // This prevents creating empty variable products when XML has no <variations> block
        $has_actual_variations = false;
        if ($has_variation_attributes && $variation_mode === 'map') {
            $map_config = $attributes_config['map_config'] ?? array();
            $variation_paths = array('variations.variation', 'variations', 'variants.variant', 'variants', 'variation', 'variant');
            
            // Check configured container_xpath first
            if (!empty($map_config['container_xpath'])) {
                $custom_path = trim($map_config['container_xpath'], '/');
                $custom_path = str_replace('//', '.', $custom_path);
                array_unshift($variation_paths, $custom_path);
            }
            
            foreach ($variation_paths as $path) {
                $variations_data = $this->get_nested_value($product_data, $path);
                if (!empty($variations_data) && is_array($variations_data)) {
                    $has_actual_variations = true;
                    break;
                }
            }
            
            if (!$has_actual_variations) {
                // Reset to simple product mode - don't create variations
                $has_variation_attributes = false;
            }
        }
        
        if ($has_variation_attributes) {
            
            // Change product type to variable
            wp_set_object_terms($product_id, 'variable', 'product_type');
            
            // Reload product as variable product object
            $product = wc_get_product($product_id);
            
        } else {
        }
        

        $product_attributes = array();

        // Process variation attributes (only if they exist)
        if (!empty($attributes_config['attributes']) && is_array($attributes_config['attributes'])) {
        foreach ($attributes_config['attributes'] as $index => $attr_config) {
            if (empty($attr_config['name'])) {
                continue;
            }

            // Auto-add pa_ prefix if not present (WooCommerce requirement)
            $original_name = $attr_config['name'];
            if (strpos($original_name, 'pa_') !== 0) {
                $attr_name = 'pa_' . sanitize_title($original_name);
                $attr_label = $original_name; // Use original as label (e.g., "Materiāls", "Material")
            } else {
                $attr_name = sanitize_title($original_name);
                $attr_label = str_replace('pa_', '', $original_name);
            }
            
            
            // Get values from configured source
            $raw_value = null;
            $values_source = $attr_config['values_source'] ?? '';
            $xml_attr_name = $attr_config['xml_attribute_name'] ?? '';
            $xml_attr_key = $attr_config['xml_attribute_key'] ?? '';  // NEW: explicit XML key (e.g., "size", "color")
            $array_index = isset($attr_config['array_index']) ? $attr_config['array_index'] : null;
            
            // Check if we're in "map" mode - auto-extract from variations
            $variation_mode = $attributes_config['variation_mode'] ?? 'auto';
            $map_config = $attributes_config['map_config'] ?? array();
            
            // USE PRE-COLLECTED VALUES if available (from auto-detection)
            if (!empty($attr_config['_auto_values'])) {
                $raw_value = $attr_config['_auto_values'];
            }
            // AUTO-EXTRACT from variations when in "map" mode
            // Use xml_attribute_key if provided, otherwise fall back to attr_label
            else if ($variation_mode === 'map') {
                // Determine which key to use for extraction
                $search_key = !empty($xml_attr_key) ? $xml_attr_key : $attr_label;
                
                // Find variations in product data
                $container_xpath = $map_config['container_xpath'] ?? 'variations.variation';
                $variations_data = $this->get_nested_value($product_data, $container_xpath);
                
                if (!empty($variations_data)) {
                    // Ensure array format
                    if (!isset($variations_data[0])) {
                        $variations_data = array($variations_data);
                    }
                    
                    
                    // Collect all unique values for this attribute from all variations
                    $collected_values = array();
                    
                    foreach ($variations_data as $var_data) {
                        $value = null;
                        
                        // Method 1: Use array_index if provided (e.g., attributes.attribute[0])
                        if ($array_index !== null && is_numeric($array_index)) {
                            // Try source path with array index
                            $possible_paths = array(
                                $values_source,                    // e.g., "attributes.attribute"
                                'attributes.attribute',            // common pattern
                                'attribute'
                            );
                            
                            foreach ($possible_paths as $base_path) {
                                if (empty($base_path)) continue;
                                $array_data = $this->get_nested_value($var_data, $base_path);
                                if (is_array($array_data) && isset($array_data[$array_index])) {
                                    $value = $array_data[$array_index];
                                    break;
                                }
                            }
                        }
                        
                        // Method 2: Fall back to key-based search
                        if (empty($value)) {
                            $key_lower = strtolower($search_key);
                            $key_clean = sanitize_title($search_key);
                            
                            $attr_paths = array(
                                'attributes.' . $key_lower,
                                'attributes.' . $search_key,
                                'attributes.' . $key_clean,
                                $key_lower,
                                $search_key,
                                $key_clean
                            );
                            
                            // Also add values_source if provided
                            if (!empty($values_source)) {
                                array_unshift($attr_paths, $values_source);
                            }
                            
                            foreach ($attr_paths as $path) {
                                $found = $this->get_nested_value($var_data, $path);
                                if (!empty($found) && is_string($found)) {
                                    $value = $found;
                                    break;
                                }
                            }
                        }
                        
                        // Method 3: Handle <attribute name="Size">S</attribute> XML format
                        // Where attrs_data['attribute'] is an array with @attributes.name and #text or value
                        if (empty($value)) {
                            $attrs_data = $this->get_nested_value($var_data, 'attributes');
                            if (is_array($attrs_data) && isset($attrs_data['attribute'])) {
                                $attr_array = $attrs_data['attribute'];
                                // Ensure it's an array of attributes (not single attribute)
                                if (!isset($attr_array[0])) {
                                    $attr_array = array($attr_array);
                                }
                                foreach ($attr_array as $attr_item) {
                                    if (is_array($attr_item)) {
                                        // Check @attributes.name or @name or name
                                        $item_name = $attr_item['@attributes']['name'] ?? $attr_item['@name'] ?? $attr_item['name'] ?? '';
                                        if (strcasecmp($item_name, $search_key) === 0) {
                                            // Get value from #text, #value, value, or the item itself if string
                                            $val = $attr_item['#text'] ?? $attr_item['#value'] ?? $attr_item['value'] ?? '';
                                            if (!empty($val) && is_string($val)) {
                                                $value = $val;
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        
                        if (!empty($value) && is_string($value)) {
                            $collected_values[] = trim($value);
                        }
                    }
                    
                    // Get unique values
                    $collected_values = array_unique($collected_values);
                    
                    if (!empty($collected_values)) {
                        $raw_value = $collected_values;
                    } else {
                    }
                } else {
                }
            }
            // Special handling for XML <attributes><attribute> structure
            // If xml_attribute_name is set, use it to match XML attributes by name
            else if ($this->config['file_type'] === 'xml' && 
                !empty($xml_attr_name) &&
                isset($product_data['attributes']['attribute'])) {
                
                
                $xml_attributes = $product_data['attributes']['attribute'];
                // Normalize to array if single attribute
                if (!isset($xml_attributes[0])) {
                    $xml_attributes = array($xml_attributes);
                }
                
                
                // Match by XML attribute name
                foreach ($xml_attributes as $xml_attr) {
                    $xml_name = $xml_attr['name'] ?? '';
                    if (strcasecmp($xml_name, $xml_attr_name) === 0) {
                        $raw_value = isset($xml_attr['value']) ? $xml_attr['value'] : null;
                        break;
                    }
                }
                
                if ($raw_value === null) {
                }
            } else if (!empty($values_source)) {
                // Standard field extraction from values_source
                
                // Extract value from XML/CSV
                try {
                    // Check if source contains {placeholder} syntax (like other fields use)
                    if (strpos($values_source, '{') !== false && strpos($values_source, '}') !== false) {
                        // Parse template string - replace all {field} with actual values
                        $raw_value = $this->parse_template_string($values_source, $product_data);
                    } else {
                        // Simple field name - extract directly
                        if ($this->config['file_type'] === 'xml') {
                            $raw_value = $this->xml_parser->extract_field_value($product_data, $values_source);
                        } else {
                            $raw_value = $this->csv_parser->extract_field_value($product_data, $values_source);
                        }
                    }
                } catch (Exception $e) {
                    continue;
                }
            } else if (empty($raw_value)) {
                // Only error if raw_value wasn't already set by map mode auto-extraction
                continue;
            }
            
            if (empty($raw_value)) {
                continue;
            }


            // Parse values based on mode
            $values_mode = $attr_config['values_mode'] ?? 'single';
            
            $values = array();
            if ($values_mode === 'split' && is_string($raw_value)) {
                // Split by comma or pipe
                $values = array_map('trim', preg_split('/[,|]/', $raw_value));
            } elseif (is_array($raw_value)) {
                // Already an array (multiple XML elements)
                $values = $raw_value;
            } else {
                // Single value
                $values = array($raw_value);
            }

            // Filter out empty values
            $values = array_filter($values, function($v) {
                return !empty($v);
            });

            if (empty($values)) {
                continue;
            }


            // Register attribute taxonomy if doesn't exist
            $this->register_attribute_taxonomy($attr_name, $attr_label);

            // Create/get terms
            $term_ids = array();
            foreach ($values as $value) {
                // FIXED: Correct parameter order - value first, then taxonomy
                $term_result = $this->get_or_create_attribute_term($value, $attr_name);
                if ($term_result && isset($term_result->term_id)) {
                    $term_ids[] = $term_result->term_id;
                } else {
                }
            }

            if (empty($term_ids)) {
                continue;
            }

            // Set product attribute
            $is_visible = isset($attr_config['visible']) && $attr_config['visible'] == 1;
            $is_variation = isset($attr_config['used_for_variations']) && $attr_config['used_for_variations'] == 1;


            $product_attributes[$attr_name] = array(
                'name' => $attr_name,
                'value' => '', // WooCommerce uses taxonomy terms, not this field
                'position' => $index,
                'is_visible' => $is_visible ? 1 : 0,
                'is_variation' => $is_variation ? 1 : 0,
                'is_taxonomy' => 1
            );

            // Set terms to product
            wp_set_object_terms($product_id, $term_ids, $attr_name);
        }
        } // End of if (!empty($attributes_config['attributes']))

        // =====================================================
        // PROCESS KEY-VALUE ATTRIBUTE PAIRS (BigBuy format)
        // e.g., {attribute1} → "Colour", {value1} → "Blue"
        // Also handles ARRAY-based Key-Value pairs:
        // e.g., attributes.attribute[0].name → "Material", attributes.attribute[0].value → "100% Cotton"
        // =====================================================
        $attribute_pairs = $attributes_config['attribute_pairs'] ?? array();
        $attr_input_mode = $attributes_config['attr_input_mode'] ?? 'standard';
        
        if ($attr_input_mode === 'key_value' && !empty($attribute_pairs) && is_array($attribute_pairs)) {
            
            $attr_position = count($product_attributes);
            
            foreach ($attribute_pairs as $pair) {
                $name_field = $pair['name_field'] ?? '';
                $value_field = $pair['value_field'] ?? '';
                
                if (empty($name_field) || empty($value_field)) {
                    continue;
                }
                
                // Detect array-based key-value pairs:
                // If name_field contains a path like {attributes.attribute.name}, it may reference an array
                // Extract the base container path and child field names
                $array_pairs = array(); // Will hold array of [name, value] pairs if array-based
                
                if (preg_match('/^\{([^}]+)\}$/', trim($name_field), $nm) && preg_match('/^\{([^}]+)\}$/', trim($value_field), $vm)) {
                    $name_path = $nm[1]; // e.g., "attributes.attribute.name"
                    $value_path = $vm[1]; // e.g., "attributes.attribute.value"
                    
                    // Find the common parent path and the child field names
                    $name_parts = explode('.', $name_path);
                    $value_parts = explode('.', $value_path);
                    $name_child = array_pop($name_parts); // "name"
                    $value_child = array_pop($value_parts); // "value"
                    $name_parent = implode('.', $name_parts); // "attributes.attribute"
                    $value_parent = implode('.', $value_parts); // "attributes.attribute"
                    
                    // If both share the same parent, try to get the array
                    if ($name_parent === $value_parent && !empty($name_parent)) {
                        $container_data = $this->get_nested_value($product_data, $name_parent);
                        
                        if (is_array($container_data)) {
                            // Check if it's a sequential array (indexed)
                            if (isset($container_data[0])) {
                                // Array of items: [{name: "Material", value: "Cotton"}, ...]
                                foreach ($container_data as $item) {
                                    if (is_array($item) && !empty($item[$name_child]) && !empty($item[$value_child])) {
                                        $array_pairs[] = array(
                                            'name' => trim($item[$name_child]),
                                            'value' => trim($item[$value_child])
                                        );
                                    }
                                }
                            } elseif (isset($container_data[$name_child]) && isset($container_data[$value_child])) {
                                // Single item: {name: "Material", value: "Cotton"}
                                $array_pairs[] = array(
                                    'name' => trim($container_data[$name_child]),
                                    'value' => trim($container_data[$value_child])
                                );
                            }
                        }
                    }
                }
                
                // If we found array-based pairs, process each one
                if (!empty($array_pairs)) {
                    foreach ($array_pairs as $ap) {
                        $original_name = $ap['name'];
                        $attr_value_str = $ap['value'];
                        
                        if (empty($original_name) || empty($attr_value_str)) continue;
                        
                        if (strpos($original_name, 'pa_') !== 0) {
                            $attr_name = 'pa_' . sanitize_title($original_name);
                            $attr_label = $original_name;
                        } else {
                            $attr_name = sanitize_title($original_name);
                            $attr_label = str_replace('pa_', '', $original_name);
                        }
                        
                        // Parse values
                        $values = array();
                        if (preg_match('/[,|]/', $attr_value_str)) {
                            $values = array_map('trim', preg_split('/[,|]/', $attr_value_str));
                        } else {
                            $values = array(trim($attr_value_str));
                        }
                        $values = array_filter($values, function($v) { return !empty($v); });
                        
                        if (empty($values)) continue;
                        
                        // Register attribute taxonomy
                        $this->register_attribute_taxonomy($attr_name, $attr_label);
                        
                        // Create/get terms
                        $term_ids = array();
                        foreach ($values as $value) {
                            $term_result = $this->get_or_create_attribute_term($value, $attr_name);
                            if ($term_result && isset($term_result->term_id)) {
                                $term_ids[] = $term_result->term_id;
                            }
                        }
                        
                        if (empty($term_ids)) continue;
                        
                        $product_attributes[$attr_name] = array(
                            'name' => $attr_name,
                            'value' => '',
                            'position' => $attr_position++,
                            'is_visible' => 1,
                            'is_variation' => 0,
                            'is_taxonomy' => 1
                        );
                        
                        wp_set_object_terms($product_id, $term_ids, $attr_name);
                    }
                } else {
                // Original single-pair logic (BigBuy format: {attribute1} → "Colour")
                $attr_name_value = $this->parse_template_string($name_field, $product_data);
                if (empty($attr_name_value)) {
                    continue;
                }
                
                // Parse attribute value from template (e.g., {value1} → "Blue")
                $attr_value = $this->parse_template_string($value_field, $product_data);
                if (empty($attr_value)) {
                    continue;
                }
                
                
                // Prepare taxonomy name from the dynamic attribute name
                $original_name = trim($attr_name_value);
                if (strpos($original_name, 'pa_') !== 0) {
                    $attr_name = 'pa_' . sanitize_title($original_name);
                    $attr_label = $original_name;
                } else {
                    $attr_name = sanitize_title($original_name);
                    $attr_label = str_replace('pa_', '', $original_name);
                }
                
                
                // Parse values (handle array or string with comma/pipe separators)
                $values = array();
                if (is_array($attr_value)) {
                    $values = $attr_value;
                } else if (is_string($attr_value)) {
                    if (preg_match('/[,|]/', $attr_value)) {
                        $values = array_map('trim', preg_split('/[,|]/', $attr_value));
                    } else {
                        $values = array(trim($attr_value));
                    }
                }
                
                $values = array_filter($values, function($v) {
                    return !empty($v);
                });
                
                if (empty($values)) {
                    continue;
                }
                
                
                // Register attribute taxonomy
                $this->register_attribute_taxonomy($attr_name, $attr_label);
                
                // Create/get terms
                $term_ids = array();
                foreach ($values as $value) {
                    $term_result = $this->get_or_create_attribute_term($value, $attr_name);
                    if ($term_result && isset($term_result->term_id)) {
                        $term_ids[] = $term_result->term_id;
                    }
                }
                
                if (empty($term_ids)) {
                    continue;
                }
                
                // Add to product attributes
                $product_attributes[$attr_name] = array(
                    'name' => $attr_name,
                    'value' => '',
                    'position' => $attr_position++,
                    'is_visible' => 1,
                    'is_variation' => 0,
                    'is_taxonomy' => 1
                );
                
                // Set terms to product
                wp_set_object_terms($product_id, $term_ids, $attr_name);
            } // end else (single-pair logic)
            }
            
        }

        // =====================================================
        // PROCESS DISPLAY ATTRIBUTES (non-variation attributes)
        // =====================================================
        $display_attributes = $attributes_config['display_attributes'] ?? array();
        if (!empty($display_attributes) && is_array($display_attributes)) {
            
            $attr_position = count($product_attributes); // Continue position after variation attributes
            
            foreach ($display_attributes as $display_attr) {
                if (empty($display_attr['name'])) {
                    continue;
                }
                
                $original_name = $display_attr['name'];
                $source_field = $display_attr['source'] ?? '';
                
                
                // Get value from source field in product_data
                $raw_value = null;
                if (!empty($source_field)) {
                    // Check if source contains {placeholder} syntax (like other fields use)
                    if (strpos($source_field, '{') !== false && strpos($source_field, '}') !== false) {
                        // Parse template string - replace all {field} with actual values
                        $raw_value = $this->parse_template_string($source_field, $product_data);
                    } else {
                        // Simple field name - try direct access or nested path
                        if (isset($product_data[$source_field])) {
                            $raw_value = $product_data[$source_field];
                        } else {
                            // Try nested path extraction
                            $raw_value = $this->get_nested_value($product_data, $source_field);
                        }
                    }
                }
                
                if (empty($raw_value)) {
                    continue;
                }
                
                // Prepare taxonomy name
                if (strpos($original_name, 'pa_') !== 0) {
                    $attr_name = 'pa_' . sanitize_title($original_name);
                    $attr_label = $original_name;
                } else {
                    $attr_name = sanitize_title($original_name);
                    $attr_label = str_replace('pa_', '', $original_name);
                }
                
                
                // Parse values (handle array or string with comma/pipe separators)
                $values = array();
                if (is_array($raw_value)) {
                    $values = $raw_value;
                } else if (is_string($raw_value)) {
                    // Check if contains comma or pipe, then split
                    if (preg_match('/[,|]/', $raw_value)) {
                        $values = array_map('trim', preg_split('/[,|]/', $raw_value));
                    } else {
                        $values = array(trim($raw_value));
                    }
                }
                
                $values = array_filter($values, function($v) {
                    return !empty($v);
                });
                
                if (empty($values)) {
                    continue;
                }
                
                
                // Register attribute taxonomy
                $this->register_attribute_taxonomy($attr_name, $attr_label);
                
                // Create/get terms
                $term_ids = array();
                foreach ($values as $value) {
                    $term_result = $this->get_or_create_attribute_term($value, $attr_name);
                    if ($term_result && isset($term_result->term_id)) {
                        $term_ids[] = $term_result->term_id;
                    }
                }
                
                if (empty($term_ids)) {
                    continue;
                }
                
                // Set visibility (display attributes are always visible, never used for variations)
                $is_visible = isset($display_attr['visible']) ? ($display_attr['visible'] == 1) : true;
                
                $product_attributes[$attr_name] = array(
                    'name' => $attr_name,
                    'value' => '',
                    'position' => $attr_position++,
                    'is_visible' => $is_visible ? 1 : 0,
                    'is_variation' => 0, // Display attributes are NOT for variations
                    'is_taxonomy' => 1
                );
                
                // Set terms to product
                wp_set_object_terms($product_id, $term_ids, $attr_name);
            }
            
        }

        // Save attributes to product
        if (!empty($product_attributes)) {
            update_post_meta($product_id, '_product_attributes', $product_attributes);
            
            // CRITICAL: Generate variations if product is variable type
            if ($has_variation_attributes) {
                // Pass product_data for "map" mode to read variations from XML
                $this->generate_product_variations($product_id, $product_attributes, $attributes_config, $product_data);
            }
        } else {
        }
        
        // CRITICAL: Check if product is variable type but has no variations
        // This can happen when type=variable is set but no variation data exists in XML
        $final_product = wc_get_product($product_id);
        if ($final_product && $final_product->is_type('variable')) {
            $variation_count = count($final_product->get_children());
            if ($variation_count === 0) {
                wp_set_object_terms($product_id, 'simple', 'product_type');
                // Ensure stock status is set correctly
                $stock_status = get_post_meta($product_id, '_stock_status', true);
                if (empty($stock_status)) {
                    update_post_meta($product_id, '_stock_status', 'instock');
                }
            }
        }
    }
    
    /**
     * Generate product variations from attributes.
     *
     * @since    1.0.0
     * @param    int $product_id Parent product ID
     * @param    array $product_attributes Saved attributes array
     * @param    array $attributes_config Attributes configuration
     * @param    array $product_data Raw product data from XML/CSV (for map mode)
     */
    private function generate_product_variations($product_id, $product_attributes, $attributes_config, $product_data = array()) {
        $log_file = WP_CONTENT_DIR . '/variations_debug.log';
        
        // NORMALIZE: Support both old and new UI formats
        $product_mode = $attributes_config['product_mode'] ?? null;
        $variation_mode = $attributes_config['variation_mode'] ?? 'auto';
        
        // Convert new format to old format
        if ($product_mode === 'variable') {
            $variation_mode = 'map';
            // Ensure map_config has container_xpath from variation_path
            if (!empty($attributes_config['variation_path']) && empty($attributes_config['map_config']['container_xpath'])) {
                $attributes_config['map_config'] = $attributes_config['map_config'] ?? array();
                $attributes_config['map_config']['container_xpath'] = $attributes_config['variation_path'];
            }
            // Convert variation_fields to map_config
            if (!empty($attributes_config['variation_fields'])) {
                $vf = $attributes_config['variation_fields'];
                $attributes_config['map_config']['sku_source'] = $vf['sku'] ?? '';
                $attributes_config['map_config']['price_source'] = $vf['regular_price'] ?? '';
                $attributes_config['map_config']['sale_price_source'] = $vf['sale_price'] ?? '';
                $attributes_config['map_config']['sale_price_dates_from_source'] = $vf['sale_price_dates_from'] ?? '';
                $attributes_config['map_config']['sale_price_dates_to_source'] = $vf['sale_price_dates_to'] ?? '';
                $attributes_config['map_config']['stock_source'] = $vf['stock_quantity'] ?? '';
                $attributes_config['map_config']['stock_status_source'] = $vf['stock_status'] ?? '';
                $attributes_config['map_config']['manage_stock_source'] = $vf['manage_stock'] ?? '';
                $attributes_config['map_config']['low_stock_amount_source'] = $vf['low_stock_amount'] ?? '';
                $attributes_config['map_config']['weight_source'] = $vf['weight'] ?? '';
                $attributes_config['map_config']['length_source'] = $vf['length'] ?? '';
                $attributes_config['map_config']['width_source'] = $vf['width'] ?? '';
                $attributes_config['map_config']['height_source'] = $vf['height'] ?? '';
                $attributes_config['map_config']['description_source'] = $vf['description'] ?? '';
                $attributes_config['map_config']['shipping_class_source'] = $vf['shipping_class'] ?? '';
                $attributes_config['map_config']['image_source'] = $vf['image'] ?? '';
                $attributes_config['map_config']['virtual_source'] = $vf['virtual'] ?? '';
                $attributes_config['map_config']['downloadable_source'] = $vf['downloadable'] ?? '';
                // Product identifiers
                $attributes_config['map_config']['ean_source'] = $vf['ean'] ?? '';
                $attributes_config['map_config']['upc_source'] = $vf['upc'] ?? '';
                $attributes_config['map_config']['gtin_source'] = $vf['gtin'] ?? '';
                $attributes_config['map_config']['isbn_source'] = $vf['isbn'] ?? '';
                $attributes_config['map_config']['mpn_source'] = $vf['mpn'] ?? '';
            }
        } elseif ($product_mode === 'simple' || $product_mode === 'attributes') {
            return;
        }
        
        
        // First, delete all existing variations to regenerate fresh
        $existing_variations = get_posts(array(
            'post_type' => 'product_variation',
            'post_parent' => $product_id,
            'posts_per_page' => -1,
            'fields' => 'ids'
        ));
        
        if (!empty($existing_variations)) {
            foreach ($existing_variations as $variation_id) {
                wp_delete_post($variation_id, true);
            }
        }
        
        $parent_product = wc_get_product($product_id);
        $variation_count = 0;
        
        // MAP MODE: Read variations directly from XML/CSV data
        if ($variation_mode === 'map' && !empty($product_data)) {
            $variation_count = $this->create_mapped_variations($product_id, $product_attributes, $attributes_config, $product_data, $parent_product);
        } else {
            // AUTO MODE: Generate all combinations from attributes
            $variation_count = $this->create_auto_variations($product_id, $product_attributes, $attributes_config, $parent_product);
        }
        
        
        // CRITICAL: If no variations were created, convert back to simple product
        // This prevents "out of stock" issue for variable products without variations
        if ($variation_count === 0) {
            wp_set_object_terms($product_id, 'simple', 'product_type');
            
            // Reload product to get correct type
            $parent_product = wc_get_product($product_id);
            if ($parent_product) {
                // Ensure stock status is set correctly for simple product
                $current_stock_status = get_post_meta($product_id, '_stock_status', true);
                if (empty($current_stock_status) || $current_stock_status === 'outofstock') {
                    // Check if we have stock quantity
                    $stock_qty = get_post_meta($product_id, '_stock', true);
                    if (!empty($stock_qty) && intval($stock_qty) > 0) {
                        update_post_meta($product_id, '_stock_status', 'instock');
                    }
                }
            }
            return; // Skip sync since it's no longer variable
        }
        
        // Sync variation data with parent
        if (function_exists('WC_Product_Variable::sync')) {
            WC_Product_Variable::sync($product_id);
        }
        
        // Force sync stock status - WooCommerce sometimes doesn't do this correctly
        $children = get_posts(array(
            'post_type' => 'product_variation',
            'post_parent' => $product_id,
            'posts_per_page' => -1,
            'fields' => 'ids'
        ));
        
        // CRITICAL: Force all variations to be instock if they don't manage stock
        // WooCommerce sync() can reset stock_status to outofstock even when manage_stock=no
        foreach ($children as $child_id) {
            $child_manage_stock = get_post_meta($child_id, '_manage_stock', true);
            $child_stock_status = get_post_meta($child_id, '_stock_status', true);
            
            // If not managing stock and status is outofstock, force to instock
            if ($child_manage_stock === 'no' && $child_stock_status !== 'instock') {
                update_post_meta($child_id, '_stock_status', 'instock');
            }
        }
        
        $has_stock = false;
        foreach ($children as $child_id) {
            $child_stock_status = get_post_meta($child_id, '_stock_status', true);
            if ($child_stock_status === 'instock') {
                $has_stock = true;
                break;
            }
        }
        
        // Update parent stock status directly
        $new_stock_status = $has_stock ? 'instock' : 'outofstock';
        update_post_meta($product_id, '_stock_status', $new_stock_status);
        
        // Sync the variable product to update prices and other aggregated data
        WC_Product_Variable::sync($product_id);
        
        // CRITICAL: Fix variations AGAIN after second sync - sync can reset stock_status
        global $wpdb;
        foreach ($children as $child_id) {
            $child_manage_stock = get_post_meta($child_id, '_manage_stock', true);
            $child_stock_status = get_post_meta($child_id, '_stock_status', true);
            
            // If not managing stock and status is outofstock, force to instock
            if ($child_manage_stock === 'no' && $child_stock_status !== 'instock') {
                $wpdb->update(
                    $wpdb->postmeta,
                    array('meta_value' => 'instock'),
                    array('post_id' => $child_id, 'meta_key' => '_stock_status'),
                    array('%s'),
                    array('%d', '%s')
                );
            }
        }
        
        // IMPORTANT: Re-set parent stock status AFTER sync because sync can reset it
        // Use direct DB query to bypass any WooCommerce hooks
        $wpdb->update(
            $wpdb->postmeta,
            array('meta_value' => $new_stock_status),
            array('post_id' => $product_id, 'meta_key' => '_stock_status'),
            array('%s'),
            array('%d', '%s')
        );
        
        // Clear ALL WooCommerce product caches to ensure stock status is reflected
        // Note: We use direct cache deletion instead of wc_delete_product_transients()
        // to avoid triggering hooks that might reset stock status
        wp_cache_delete('product-' . $product_id, 'products');
        wp_cache_delete($product_id, 'post_meta');
        clean_post_cache($product_id);
        
    }
    
    /**
     * Create variations from mapped XML/CSV data.
     *
     * @since    1.0.0
     * @param    int $product_id Parent product ID
     * @param    array $product_attributes Saved attributes array
     * @param    array $attributes_config Attributes configuration
     * @param    array $product_data Raw product data
     * @param    WC_Product $parent_product Parent product object
     * @return   int Number of variations created
     */
    private function create_mapped_variations($product_id, $product_attributes, $attributes_config, $product_data, $parent_product) {
        $log_file = WP_CONTENT_DIR . '/variations_debug.log';
        $variation_count = 0;
        
        // DEBUG: Log what product_data contains
        if (defined('WP_DEBUG') && WP_DEBUG) { 
            if (isset($product_data['variations'])) {
                if (is_array($product_data['variations'])) {
                }
            } else {
            }
        }
        
        // Get map configuration
        $map_config = $attributes_config['map_config'] ?? array();
        
        // Try to find variations in product data
        // Common paths: variations.variation, variants.variant, variation, etc.
        $variations_data = null;
        $possible_paths = array(
            'variations.variation',
            'variations',
            'variants.variant', 
            'variants',
            'variation',
            'variant'
        );
        
        // First try configured container_xpath if provided
        if (!empty($map_config['container_xpath'])) {
            $custom_path = trim($map_config['container_xpath'], '/');
            $custom_path = str_replace('//', '.', $custom_path);
            array_unshift($possible_paths, $custom_path);
        }
        
        foreach ($possible_paths as $path) {
            $data = $this->get_nested_value($product_data, $path);
            if (!empty($data)) {
                $variations_data = $data;
                break;
            }
        }
        
        if (empty($variations_data)) {
            // Fall back to auto mode
            return $this->create_auto_variations($product_id, $product_attributes, $attributes_config, $parent_product);
        }
        
        // Ensure variations_data is an array of variations
        if (!isset($variations_data[0])) {
            $variations_data = array($variations_data);
        }
        
        
        // Check if auto-detect mode is enabled
        $attribute_detection_mode = $attributes_config['attribute_detection_mode'] ?? 'manual';
        $auto_attributes_path = $attributes_config['auto_attributes_path'] ?? 'attributes';
        $auto_create_attributes = $attributes_config['auto_create_attributes'] ?? true;
        
        
        // Get attribute info for matching
        $attr_configs = $attributes_config['attributes'] ?? array();
        $variation_attrs_map = array(); // Maps attribute name to full config
        
        if ($attribute_detection_mode === 'auto') {
            // AUTO-DETECT MODE: Dynamically discover attributes from first variation
            
            // Get attributes from first variation to discover structure
            $first_var = $variations_data[0] ?? array();
            $attrs_data = $this->get_nested_value($first_var, $auto_attributes_path) ?? $first_var;
            
            if (is_array($attrs_data)) {
                foreach ($attrs_data as $attr_key => $attr_value) {
                    // Skip non-string values (nested arrays, etc.)
                    if (!is_string($attr_value) && !is_numeric($attr_value)) {
                        continue;
                    }
                    
                    // Skip common non-attribute fields
                    $skip_fields = array('sku', 'price', 'regular_price', 'sale_price', 'stock', 'stock_quantity', 'manage_stock', 'stock_status', 'weight', 'length', 'width', 'height', 'description', 'image', 'virtual', 'downloadable', 'parent_sku', 'gtin', 'ean', 'upc', 'isbn', 'mpn', 'enabled', 'status', 'backorders', 'shipping_class', 'tax_class', 'download_limit', 'download_expiry', 'downloads', 'low_stock_amount', 'sale_price_dates_from', 'sale_price_dates_to', 'menu_order');
                    if (in_array(strtolower($attr_key), $skip_fields)) {
                        continue;
                    }
                    
                    // This is an attribute! Create/get taxonomy
                    $attr_name = ucfirst(str_replace('_', ' ', $attr_key));
                    $taxonomy_name = $this->sanitize_attribute_name($attr_name);
                    
                    // Create attribute if needed
                    if ($auto_create_attributes) {
                        $this->ensure_attribute_taxonomy_exists($attr_name, $taxonomy_name);
                    }
                    
                    $variation_attrs_map[$attr_name] = array(
                        'taxonomy' => $taxonomy_name,
                        'source_key' => $attr_key,  // Direct key in attributes object
                        'source' => '',
                        'array_index' => null
                    );
                    
                }
            }
            
            // Also need to update parent product with these attributes
            $this->update_parent_with_auto_attributes($product_id, $variation_attrs_map, $variations_data, $auto_attributes_path, $parent_product);
            
        } else {
            // MANUAL MODE: Use configured attributes
            foreach ($attr_configs as $attr_config) {
                if (!empty($attr_config['used_for_variations'])) {
                    $attr_name = $attr_config['name'];
                    $taxonomy_name = $this->sanitize_attribute_name($attr_name);
                    $variation_attrs_map[$attr_name] = array(
                        'taxonomy' => $taxonomy_name,
                        'source' => $attr_config['values_source'] ?? '',
                        'array_index' => isset($attr_config['array_index']) ? $attr_config['array_index'] : null
                    );
                }
            }
        }
        
        // Process each variation from source data
        foreach ($variations_data as $var_index => $var_data) {
            
            if (!is_array($var_data)) {
                continue;
            }
            
            // Create variation product
            $variation = new WC_Product_Variation();
            $variation->set_parent_id($product_id);
            
            // Extract variation attributes (e.g., size=S, color=Black)
            $var_attributes = array();
            
            // Try to find attributes in variation data
            $attrs_data = $this->get_nested_value($var_data, 'attributes') ?? $var_data;
            
            
            foreach ($variation_attrs_map as $attr_name => $attr_cfg) {
                $taxonomy_name = $attr_cfg['taxonomy'];
                $source = $attr_cfg['source'] ?? '';
                $array_index = $attr_cfg['array_index'] ?? null;
                $source_key = $attr_cfg['source_key'] ?? null; // For auto-detect mode
                
                // Try different paths to find attribute value
                $attr_value = null;
                
                // AUTO-DETECT MODE: Use source_key to directly access attribute in attrs_data
                if ($source_key !== null) {
                    // Get attributes data at the configured path
                    $attrs_data_for_var = $this->get_nested_value($var_data, $auto_attributes_path) ?? $var_data;
                    
                    if (is_array($attrs_data_for_var) && isset($attrs_data_for_var[$source_key])) {
                        $attr_value = $attrs_data_for_var[$source_key];
                    }
                }
                
                // MANUAL MODE fallback: Try various path patterns
                if (empty($attr_value)) {
                // XML: <attributes><size>S</size><color>Black</color></attributes>
                $attr_name_lower = strtolower($attr_name);
                $attr_name_underscore = strtolower(str_replace(' ', '_', $attr_name));
                
                // Try direct access first (most reliable for standard XML)
                // Format 1: <attributes><size>S</size><color>Black</color></attributes>
                $direct_paths = array(
                    'attributes.' . $attr_name_lower,
                    'attributes.' . $attr_name,
                    'attributes.' . $attr_name_underscore,
                    $attr_name_lower,
                    $attr_name,
                );
                
                foreach ($direct_paths as $path) {
                    $value = $this->get_nested_value($var_data, $path);
                    if (!empty($value) && is_string($value)) {
                        $attr_value = $value;
                        break;
                    }
                }
                
                // Format 2: <attributes><attribute name="Size">S</attribute></attributes>
                // In this case attrs_data will have 'attribute' array with '@attributes.name' and '#text'
                if (empty($attr_value) && is_array($attrs_data) && isset($attrs_data['attribute'])) {
                    $attr_array = $attrs_data['attribute'];
                    // Ensure it's an array of attributes (not single attribute)
                    if (!isset($attr_array[0])) {
                        $attr_array = array($attr_array);
                    }
                    foreach ($attr_array as $attr_item) {
                        if (is_array($attr_item)) {
                            // Check @attributes.name or @name
                            $item_name = $attr_item['@attributes']['name'] ?? $attr_item['@name'] ?? $attr_item['name'] ?? '';
                            if (strcasecmp($item_name, $attr_name) === 0) {
                                // Get value from #text or direct value
                                $attr_value = $attr_item['#text'] ?? $attr_item['#value'] ?? $attr_item['value'] ?? (is_string($attr_item) ? $attr_item : '');
                                if ($attr_value) {
                                    break;
                                }
                            }
                        }
                    }
                }
                
                // If array_index is set, use it to access array element
                if (empty($attr_value) && $array_index !== null && is_numeric($array_index)) {
                    // Try source path with array index
                    $possible_paths = array(
                        $source,                           // e.g., "attributes.attribute"
                        'attributes.attribute',            // common pattern
                        'attribute'
                    );
                    
                    foreach ($possible_paths as $base_path) {
                        if (empty($base_path)) continue;
                        $array_data = $this->get_nested_value($var_data, $base_path);
                        if (is_array($array_data) && isset($array_data[$array_index])) {
                            $attr_value = $array_data[$array_index];
                            break;
                        }
                    }
                }
                
                // Fallback: Try using source path directly (cleaned up)
                if (empty($attr_value) && !empty($source)) {
                    // Clean source - remove variations.variation[0]. prefix if present
                    $clean_source = preg_replace('/^variations\.variation\[\d+\]\./', '', $source);
                    $clean_source = preg_replace('/^variations\.variation\./', '', $clean_source);
                    
                    if ($clean_source !== $source) {
                    }
                
                    $possible_attr_paths = array(
                        $clean_source,
                        strtolower($attr_name),
                        $attr_name,
                        'attributes.' . strtolower($attr_name),
                        'attributes.' . $attr_name,
                        strtolower(str_replace(' ', '_', $attr_name)),
                    );
                
                    foreach ($possible_attr_paths as $attr_path) {
                        $value = $this->get_nested_value($var_data, $attr_path);
                        if (!empty($value) && is_string($value)) {
                            $attr_value = $value;
                            break;
                        }
                    }
                }
                } // End of manual mode fallback
                
                if ($attr_value) {
                    // Create/get term and use slug
                    $term = $this->get_or_create_attribute_term($attr_value, $taxonomy_name);
                    if ($term) {
                        $var_attributes[$taxonomy_name] = $term->slug;
                    }
                }
            }
            
            if (empty($var_attributes)) {
                continue;
            }
            
            $variation->set_attributes($var_attributes);
            
            // Set SKU
            $var_sku = $this->get_variation_field($var_data, $map_config, 'sku', array('sku', 'SKU', 'variation_sku'));
            if ($var_sku) {
                // Check if SKU is unique
                $existing_id = wc_get_product_id_by_sku($var_sku);
                if (!$existing_id) {
                    $variation->set_sku($var_sku);
                } else {
                }
            }
            
            // Set Price
            $var_price = $this->get_variation_field($var_data, $map_config, 'price', array('price', 'regular_price', 'Price'));
            if ($var_price !== null) {
                $price_clean = preg_replace('/[^0-9.,]/', '', $var_price);
                $price_clean = str_replace(',', '.', $price_clean);
                $variation->set_regular_price($price_clean);
                $variation->set_price($price_clean);
            } else {
                // Use parent price
                $parent_price = $parent_product->get_regular_price();
                if ($parent_price) {
                    $variation->set_regular_price($parent_price);
                    $variation->set_price($parent_price);
                }
            }
            
            // Set Sale Price
            $var_sale_price = $this->get_variation_field($var_data, $map_config, 'sale_price', array('sale_price', 'special_price'));
            if ($var_sale_price !== null) {
                $sale_clean = preg_replace('/[^0-9.,]/', '', $var_sale_price);
                $sale_clean = str_replace(',', '.', $sale_clean);
                $variation->set_sale_price($sale_clean);
            }
            
            // Set Stock
            $var_stock = $this->get_variation_field($var_data, $map_config, 'stock', array('stock', 'stock_quantity', 'qty', 'quantity'));
            $var_stock_status = $this->get_variation_field($var_data, $map_config, 'stock_status', array('stock_status'));
            $var_manage_stock = $this->get_variation_field($var_data, $map_config, 'manage_stock', array('manage_stock'));
            
            // Debug: log stock values
            if (defined('WP_DEBUG') && WP_DEBUG) { 
            }
            
            if ($var_stock !== null && $var_stock !== '') {
                // Stock quantity is provided - enable stock management
                $variation->set_manage_stock(true);
                $variation->set_stock_quantity((int)$var_stock);
                $variation->set_stock_status((int)$var_stock > 0 ? 'instock' : 'outofstock');
            } elseif ($var_manage_stock !== null) {
                // Manage stock field is explicitly set
                $should_manage = in_array(strtolower($var_manage_stock), array('yes', '1', 'true', 'on'));
                $variation->set_manage_stock($should_manage);
                if (!$should_manage) {
                    // Not managing stock - set status from mapping or default to instock
                    $status = 'instock';
                    if ($var_stock_status !== null && !empty($var_stock_status)) {
                        $status = strtolower($var_stock_status) === 'outofstock' ? 'outofstock' : 'instock';
                    }
                    $variation->set_stock_status($status);
                }
            } else {
                // No stock info provided - don't manage stock, set as in stock
                $variation->set_manage_stock(false);
                // Check if stock_status is explicitly set
                if ($var_stock_status !== null && !empty($var_stock_status)) {
                    $status = strtolower($var_stock_status) === 'outofstock' ? 'outofstock' : 'instock';
                    $variation->set_stock_status($status);
                } else {
                    $variation->set_stock_status('instock');
                }
            }
            
            // Set Backorders
            $var_backorders = $this->get_variation_field($var_data, $map_config, 'backorders', array('backorders'));
            $backorders_default = $map_config['backorders_default'] ?? '';
            if ($var_backorders !== null && !empty($var_backorders)) {
                // Map from source value
                $backorders_value = strtolower($var_backorders);
                if (in_array($backorders_value, array('no', 'notify', 'yes'))) {
                    $variation->set_backorders($backorders_value);
                }
            } elseif (!empty($backorders_default)) {
                // Use default value from dropdown
                $variation->set_backorders($backorders_default);
            }
            
            // Check for weight/dimensions inheritance from parent
            $weight_inherit = !empty($map_config['weight_inherit']);
            $dimensions_inherit = !empty($map_config['dimensions_inherit']);
            
            // Set Weight (with inheritance option)
            $var_weight = $this->get_variation_field($var_data, $map_config, 'weight', array('weight', 'Weight'));
            if ($weight_inherit && ($var_weight === null || $var_weight === '')) {
                // Inherit from parent
                $parent_weight = $parent_product->get_weight();
                if ($parent_weight) {
                    $variation->set_weight(floatval($parent_weight));
                }
            } elseif ($var_weight !== null && $var_weight !== '') {
                $variation->set_weight(floatval($var_weight));
            }
            
            // Set Dimensions (with inheritance option)
            $var_length = $this->get_variation_field($var_data, $map_config, 'length', array('length', 'Length'));
            $var_width = $this->get_variation_field($var_data, $map_config, 'width', array('width', 'Width'));
            $var_height = $this->get_variation_field($var_data, $map_config, 'height', array('height', 'Height'));
            
            if ($dimensions_inherit && ($var_length === null || $var_length === '') && ($var_width === null || $var_width === '') && ($var_height === null || $var_height === '')) {
                // Inherit all dimensions from parent
                $parent_length = $parent_product->get_length();
                $parent_width = $parent_product->get_width();
                $parent_height = $parent_product->get_height();
                if ($parent_length) { $variation->set_length(floatval($parent_length)); }
                if ($parent_width) { $variation->set_width(floatval($parent_width)); }
                if ($parent_height) { $variation->set_height(floatval($parent_height)); }
            } else {
                // Use variation-specific dimensions
                if ($var_length !== null && $var_length !== '') {
                    $variation->set_length(floatval($var_length));
                }
                if ($var_width !== null && $var_width !== '') {
                    $variation->set_width(floatval($var_width));
                }
                if ($var_height !== null && $var_height !== '') {
                    $variation->set_height(floatval($var_height));
                }
            }
            
            // Set Description
            $var_description = $this->get_variation_field($var_data, $map_config, 'description', array('description', 'Description'));
            if ($var_description !== null) {
                $variation->set_description($var_description);
            }
            
            // Set Shipping Class
            $var_shipping_class = $this->get_variation_field($var_data, $map_config, 'shipping_class', array('shipping_class'));
            if ($var_shipping_class !== null && !empty($var_shipping_class)) {
                $shipping_class_id = $this->get_shipping_class_id($var_shipping_class);
                if ($shipping_class_id) {
                    $variation->set_shipping_class_id($shipping_class_id);
                }
            } else {
                // No direct shipping class mapping — apply Shipping Class Engine per-variation
                // Build a pseudo product_data with this variation's own price/weight for condition checks
                $var_product_data = array(
                    'regular_price' => $variation->get_regular_price(),
                    'price'         => $variation->get_price(),
                    'weight'        => $variation->get_weight(),
                    'length'        => $variation->get_length(),
                    'width'         => $variation->get_width(),
                    'height'        => $variation->get_height(),
                    'sku'           => $variation->get_sku(),
                    'categories'    => '', // inherit from parent context if needed
                    'brand'         => '',
                );
                // Temporarily clear raw data so engine uses variation's own values (not parent fallback)
                $saved_raw = $this->_current_raw_product_data ?? null;
                $this->_current_raw_product_data = null;
                $this->apply_shipping_class_engine($variation, $var_product_data);
                $this->_current_raw_product_data = $saved_raw;
            }
            
            // Set Low Stock Amount
            $var_low_stock = $this->get_variation_field($var_data, $map_config, 'low_stock_amount', array('low_stock_amount', 'low_stock_threshold'));
            if ($var_low_stock !== null) {
                $variation->set_low_stock_amount((int)$var_low_stock);
            }
            
            // Set Sale Price Dates
            $var_sale_from = $this->get_variation_field($var_data, $map_config, 'sale_price_dates_from', array('sale_price_dates_from', 'sale_date_from'));
            if ($var_sale_from !== null && !empty($var_sale_from)) {
                $date_from = strtotime($var_sale_from);
                if ($date_from) {
                    $variation->set_date_on_sale_from($date_from);
                }
            }
            
            $var_sale_to = $this->get_variation_field($var_data, $map_config, 'sale_price_dates_to', array('sale_price_dates_to', 'sale_date_to'));
            if ($var_sale_to !== null && !empty($var_sale_to)) {
                $date_to = strtotime($var_sale_to);
                if ($date_to) {
                    $variation->set_date_on_sale_to($date_to);
                }
            }
            
            // Set Virtual - variation value overrides parent, otherwise inherit from parent
            $var_virtual = $this->get_variation_field($var_data, $map_config, 'virtual', array('virtual'));
            if ($var_virtual !== null && $var_virtual !== '') {
                // Variation has explicit virtual setting - use it
                $is_virtual = in_array(strtolower($var_virtual), array('yes', '1', 'true', 'on'));
                $variation->set_virtual($is_virtual);
            } else {
                // Inherit from parent product
                $parent_virtual = $parent_product->get_virtual();
                $variation->set_virtual($parent_virtual);
            }
            
            // Set Downloadable - variation value overrides parent, otherwise inherit from parent
            $var_downloadable = $this->get_variation_field($var_data, $map_config, 'downloadable', array('downloadable'));
            if ($var_downloadable !== null && $var_downloadable !== '') {
                // Variation has explicit downloadable setting - use it
                $is_downloadable = in_array(strtolower($var_downloadable), array('yes', '1', 'true', 'on'));
                $variation->set_downloadable($is_downloadable);
            } else {
                // Inherit from parent product
                $parent_downloadable = $parent_product->get_downloadable();
                $variation->set_downloadable($parent_downloadable);
            }
            
            // Set Download Limit
            $var_download_limit = $this->get_variation_field($var_data, $map_config, 'download_limit', array('download_limit'));
            if ($var_download_limit !== null && $var_download_limit !== '') {
                $variation->set_download_limit((int)$var_download_limit);
            }
            
            // Set Download Expiry
            $var_download_expiry = $this->get_variation_field($var_data, $map_config, 'download_expiry', array('download_expiry'));
            if ($var_download_expiry !== null && $var_download_expiry !== '') {
                $variation->set_download_expiry((int)$var_download_expiry);
            }
            
            // Set Downloads (downloadable files)
            $var_downloads = $this->get_variation_field($var_data, $map_config, 'downloads', array('downloads', 'downloadable_files', 'download_files'));
            if ($var_downloads !== null && !empty($var_downloads)) {
                $downloads = $this->parse_downloadable_files($var_downloads);
                if (!empty($downloads)) {
                    $variation->set_downloads($downloads);
                    // Auto-enable downloadable if files are set
                    $variation->set_downloadable(true);
                }
            }
            
            // Set Image (skip example.com URLs and use try-catch)
            $var_image = $this->get_variation_field($var_data, $map_config, 'image', array('image', 'image_url', 'img', 'photo'));
            if ($var_image && filter_var($var_image, FILTER_VALIDATE_URL)) {
                // Skip example.com or placeholder URLs
                if (strpos($var_image, 'example.com') === false && strpos($var_image, 'placeholder') === false) {
                    try {
                        $image_id = $this->download_and_attach_image($var_image, $product_id);
                        if ($image_id) {
                            $variation->set_image_id($image_id);
                        }
                    } catch (Exception $e) {
                    }
                } else {
                }
            }
            
            // Save variation
            try {
                $variation_id = $variation->save();
                
                if ($variation_id) {
                    $variation_count++;
                    
                    // CRITICAL: Force stock status after save to prevent WooCommerce from overriding
                    // WooCommerce sometimes resets stock_status during save() process
                    $saved_stock_status = get_post_meta($variation_id, '_stock_status', true);
                    
                    // Determine intended status based on mapping/data
                    if ($var_stock !== null && $var_stock !== '') {
                        // Stock quantity was provided - base status on quantity
                        $intended_status = ((int)$var_stock > 0) ? 'instock' : 'outofstock';
                    } elseif ($var_stock_status !== null && !empty($var_stock_status)) {
                        // Stock status was explicitly mapped - use it
                        $intended_status = (strtolower($var_stock_status) === 'outofstock') ? 'outofstock' : 'instock';
                    } else {
                        // No stock info - default to instock
                        $intended_status = 'instock';
                    }
                    
                    // Fix if saved status doesn't match intended
                    if ($saved_stock_status !== $intended_status) {
                        update_post_meta($variation_id, '_stock_status', $intended_status);
                    }
                    
                    // Ensure manage_stock is set correctly
                    $saved_manage_stock = get_post_meta($variation_id, '_manage_stock', true);
                    if ($var_stock === null && $saved_manage_stock !== 'no') {
                        update_post_meta($variation_id, '_manage_stock', 'no');
                    }
                    
                    // Set Product Identifiers (EAN, UPC, GTIN, ISBN, MPN) - must be after save
                    $identifier_fields = array('ean', 'upc', 'gtin', 'isbn', 'mpn');
                    foreach ($identifier_fields as $id_field) {
                        $var_id_value = $this->get_variation_field($var_data, $map_config, $id_field, array($id_field, strtoupper($id_field)));
                        if ($var_id_value !== null && !empty($var_id_value)) {
                            update_post_meta($variation_id, '_' . $id_field, sanitize_text_field($var_id_value));
                        }
                    }
                    
                    // Set Custom Meta Fields for variations (var_meta from mapping)
                    $var_meta_fields = $map_config['var_meta'] ?? array();
                    if (!empty($var_meta_fields) && is_array($var_meta_fields)) {
                        foreach ($var_meta_fields as $meta_item) {
                            $meta_key = $meta_item['key'] ?? '';
                            $meta_source = $meta_item['source'] ?? '';
                            
                            if (empty($meta_key) || empty($meta_source)) {
                                continue;
                            }
                            
                            // Parse the source value from variation data
                            $meta_value = $this->parse_field_placeholders($meta_source, $var_data);
                            
                            if ($meta_value !== null && $meta_value !== '') {
                                // Ensure meta key starts with underscore if it's meant to be hidden
                                $clean_key = sanitize_key($meta_key);
                                update_post_meta($variation_id, $clean_key, sanitize_text_field($meta_value));
                            }
                        }
                    }
                } else {
                }
            } catch (Exception $e) {
            }
        }
        
        return $variation_count;
    }
    
    /**
     * Get variation field value from mapped config or default paths.
     *
     * @param array $var_data Variation data
     * @param array $map_config Map configuration
     * @param string $field_name Field name (sku, price, stock, etc.)
     * @param array $default_paths Default paths to try
     * @return mixed|null Field value or null
     */
    private function get_variation_field($var_data, $map_config, $field_name, $default_paths = array()) {
        // First try mapped field
        $mapped_source = $map_config[$field_name . '_source'] ?? '';
        if (!empty($mapped_source)) {
            // Clean the source path - remove {curly braces} wrapper
            $clean_source = trim($mapped_source);
            if (preg_match('/^\{(.+)\}$/', $clean_source, $matches)) {
                $clean_source = $matches[1];
            }
            
            // Convert absolute variation path to relative path
            // E.g., "variations.variation[0].sku" → "sku"
            // E.g., "variations.variation.sku" → "sku"
            $container_xpath = $map_config['container_xpath'] ?? 'variations.variation';
            $prefix_patterns = array(
                $container_xpath . '[0].',
                $container_xpath . '[1].',
                $container_xpath . '[2].',
                $container_xpath . '.',
                // Also try common defaults
                'variations.variation[0].',
                'variations.variation.',
            );
            
            foreach ($prefix_patterns as $prefix) {
                if (strpos($clean_source, $prefix) === 0) {
                    $clean_source = substr($clean_source, strlen($prefix));
                    break;
                }
            }
            
            $value = $this->get_nested_value($var_data, $clean_source);
            if ($value !== null && $value !== '') {
                return $value;
            }
        }
        
        // Try default paths
        foreach ($default_paths as $path) {
            $value = $this->get_nested_value($var_data, $path);
            if ($value !== null && $value !== '') {
                return $value;
            }
        }
        
        return null;
    }
    
    /**
     * Parse downloadable files from string or array.
     * 
     * Formats supported:
     * - Single URL: https://example.com/file.pdf
     * - Name|URL: File Name|https://example.com/file.pdf
     * - Multiple comma-separated: Name1|URL1,Name2|URL2
     * - Multiple URLs concatenated: URL1URL2 (split by http/https)
     *
     * @param string|array $downloads Downloads data
     * @return array Array of WC_Product_Download objects
     */
    private function parse_downloadable_files($downloads) {
        $download_objects = array();
        
        // Handle array input (e.g., from XML)
        if (is_array($downloads)) {
            $downloads = implode(',', array_filter($downloads));
        }
        
        $downloads = trim($downloads);
        if (empty($downloads)) {
            return array();
        }
        
        // Check if URLs are concatenated without separator (URL1URL2)
        // Split by http:// or https:// keeping the protocol
        if (preg_match('/https?:\/\/.*https?:\/\//', $downloads) && strpos($downloads, ',') === false && strpos($downloads, '|') === false) {
            // Split by http(s):// but keep the protocol in result
            $parts = preg_split('/(https?:\/\/)/', $downloads, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
            $urls = array();
            for ($i = 0; $i < count($parts); $i++) {
                if (preg_match('/^https?:$/', $parts[$i] . ':')) {
                    // This is a protocol, combine with next part
                    if (isset($parts[$i + 1])) {
                        $urls[] = $parts[$i] . $parts[$i + 1];
                        $i++;
                    }
                }
            }
            if (!empty($urls)) {
                $downloads = implode(',', $urls);
            }
        }
        
        // Split by comma for multiple files
        $files = array_map('trim', explode(',', $downloads));
        
        foreach ($files as $index => $file) {
            if (empty($file)) {
                continue;
            }
            
            $name = '';
            $url = '';
            
            // Check if format is Name|URL
            if (strpos($file, '|') !== false) {
                $parts = explode('|', $file, 2);
                $name = trim($parts[0]);
                $url = trim($parts[1]);
            } else {
                // Just URL
                $url = $file;
                // Generate name from filename
                $path_parts = wp_parse_url($url, PHP_URL_PATH);
                if ($path_parts) {
                    $name = basename($path_parts);
                } else {
                    $name = 'Download ' . ($index + 1);
                }
            }
            
            // Validate URL
            if (!filter_var($url, FILTER_VALIDATE_URL)) {
                continue;
            }
            
            // Create WC_Product_Download object
            $download = new WC_Product_Download();
            $download->set_id(md5($url)); // Generate unique ID from URL
            $download->set_name($name);
            $download->set_file($url);
            
            $download_objects[] = $download;
        }
        
        return $download_objects;
    }
    
    /**
     * Get shipping class ID by name or slug.
     *
     * @param string $shipping_class_name Shipping class name or slug
     * @return int|false Shipping class term ID or false
     */
    private function get_shipping_class_id($shipping_class_name) {
        if (empty($shipping_class_name)) {
            return false;
        }
        
        // First try to find by slug
        $term = get_term_by('slug', sanitize_title($shipping_class_name), 'product_shipping_class');
        if ($term) {
            return $term->term_id;
        }
        
        // Try to find by name
        $term = get_term_by('name', $shipping_class_name, 'product_shipping_class');
        if ($term) {
            return $term->term_id;
        }
        
        // Create if doesn't exist
        $result = wp_insert_term($shipping_class_name, 'product_shipping_class');
        if (!is_wp_error($result)) {
            return $result['term_id'];
        }
        
        return false;
    }
    
    /**
     * Get or create attribute term.
     *
     * @param string $term_name Term name
     * @param string $taxonomy Taxonomy name
     * @return WP_Term|false Term object or false
     */
    private function get_or_create_attribute_term($term_name, $taxonomy) {
        $term_name = trim($term_name);
        if (empty($term_name)) {
            return false;
        }
        
        // Check if term exists
        $term = get_term_by('name', $term_name, $taxonomy);
        if ($term) {
            return $term;
        }
        
        // Also check by slug
        $term_slug = sanitize_title($term_name);
        $term = get_term_by('slug', $term_slug, $taxonomy);
        if ($term) {
            return $term;
        }
        
        // Create new term
        $result = wp_insert_term($term_name, $taxonomy);
        if (!is_wp_error($result)) {
            return get_term($result['term_id'], $taxonomy);
        }
        
        return false;
    }
    
    /**
     * Create variations automatically from attribute combinations.
     *
     * @since    1.0.0
     * @param    int $product_id Parent product ID
     * @param    array $product_attributes Saved attributes array
     * @param    array $attributes_config Attributes configuration
     * @param    WC_Product $parent_product Parent product object
     * @return   int Number of variations created
     */
    private function create_auto_variations($product_id, $product_attributes, $attributes_config, $parent_product) {
        $log_file = WP_CONTENT_DIR . '/variations_debug.log';
        $variation_count = 0;
        
        // Get all variation attributes (is_variation = 1)
        $variation_attributes = array();
        foreach ($product_attributes as $attr_name => $attr_data) {
            if (!empty($attr_data['is_variation'])) {
                // Get all terms for this attribute
                $terms = get_terms(array(
                    'taxonomy' => $attr_name,
                    'hide_empty' => false,
                    'object_ids' => $product_id
                ));
                
                if (!is_wp_error($terms) && !empty($terms)) {
                    $variation_attributes[$attr_name] = wp_list_pluck($terms, 'slug');
                }
            }
        }
        
        if (empty($variation_attributes)) {
            return 0;
        }
        
        // Generate all possible combinations
        $combinations = $this->get_attribute_combinations($variation_attributes);
        
        foreach ($combinations as $combination) {
            // Create variation
            $variation = new WC_Product_Variation();
            $variation->set_parent_id($product_id);
            
            // Set attributes for this variation
            $variation->set_attributes($combination);
            
            // Get variation config for pricing and stock
            $auto_config = $attributes_config['auto_config'] ?? array();
            
            // Set price (default to parent price)
            $parent_price = $parent_product->get_regular_price();
            if (!empty($parent_price)) {
                $variation->set_regular_price($parent_price);
                $variation->set_price($parent_price);
            }
            
            // Set SKU pattern if configured
            if (!empty($auto_config['sku_pattern'])) {
                $parent_sku = $parent_product->get_sku();
                $sku_suffix = implode('-', array_values($combination));
                $variation_sku = $parent_sku . '-' . $sku_suffix;
                $variation->set_sku($variation_sku);
            }
            
            // Set stock
            if (isset($auto_config['stock_mode'])) {
                if ($auto_config['stock_mode'] === 'fixed' && isset($auto_config['stock_fixed'])) {
                    $variation->set_manage_stock(true);
                    $variation->set_stock_quantity((int)$auto_config['stock_fixed']);
                    $variation->set_stock_status('instock');
                } elseif ($auto_config['stock_mode'] === 'parent') {
                    $parent_stock = $parent_product->get_stock_quantity();
                    if ($parent_stock !== null) {
                        $variation->set_manage_stock(true);
                        $variation->set_stock_quantity($parent_stock);
                        $variation->set_stock_status('instock');
                    }
                }
            } else {
                // Default: inherit from parent
                $variation->set_stock_status('instock');
            }
            
            // Inherit Virtual/Downloadable from parent product (auto-generated variations)
            $variation->set_virtual($parent_product->get_virtual());
            $variation->set_downloadable($parent_product->get_downloadable());
            if (defined('WP_DEBUG') && WP_DEBUG) { 
            }
            
            // Apply Shipping Class Engine per-variation (auto variations inherit parent price)
            $var_product_data = array(
                'regular_price' => $variation->get_regular_price(),
                'price'         => $variation->get_price(),
                'weight'        => $variation->get_weight(),
                'length'        => $variation->get_length(),
                'width'         => $variation->get_width(),
                'height'        => $variation->get_height(),
                'sku'           => $variation->get_sku(),
            );
            $saved_raw = $this->_current_raw_product_data ?? null;
            $this->_current_raw_product_data = null;
            $this->apply_shipping_class_engine($variation, $var_product_data);
            $this->_current_raw_product_data = $saved_raw;
            
            $variation_id = $variation->save();
            
            if ($variation_id) {
                $variation_count++;
            }
        }
        
        return $variation_count;
    }
    
    /**
     * Get all possible attribute combinations for variations.
     *
     * @since    1.0.0
     * @param    array $attributes Associative array of attributes and their values
     * @return   array Array of all possible combinations
     */
    private function get_attribute_combinations($attributes) {
        if (empty($attributes)) {
            return array();
        }
        
        $result = array(array());
        
        foreach ($attributes as $attr_name => $values) {
            $temp = array();
            foreach ($result as $result_item) {
                foreach ($values as $value) {
                    $temp[] = array_merge($result_item, array($attr_name => $value));
                }
            }
            $result = $temp;
        }
        
        return $result;
    }

    /**
     * Register WooCommerce attribute taxonomy.
     *
     * @since    1.0.0
     * @param    string $attr_name Attribute name (e.g., "pa_material")
     * @param    string $attr_label Attribute label (e.g., "Material")
     */
    private function register_attribute_taxonomy($attr_name, $attr_label) {
        global $wpdb;

        // Check if attribute already exists in WooCommerce
        $attribute_slug = str_replace('pa_', '', $attr_name);
        $attribute_id = $wpdb->get_var($wpdb->prepare(
            "SELECT attribute_id FROM {$wpdb->prefix}woocommerce_attribute_taxonomies WHERE attribute_name = %s",
            $attribute_slug
        ));

        if (!$attribute_id) {
            // Create new attribute
            $wpdb->insert(
                $wpdb->prefix . 'woocommerce_attribute_taxonomies',
                array(
                    'attribute_name' => $attribute_slug,
                    'attribute_label' => $attr_label,
                    'attribute_type' => 'select',
                    'attribute_orderby' => 'menu_order',
                    'attribute_public' => 0
                )
            );

            // Clear WooCommerce attribute cache
            delete_transient('wc_attribute_taxonomies');
            
        } else {
            // Update label if it's incorrect (e.g., contains "pa_" prefix)
            $current_label = $wpdb->get_var($wpdb->prepare(
                "SELECT attribute_label FROM {$wpdb->prefix}woocommerce_attribute_taxonomies WHERE attribute_id = %d",
                $attribute_id
            ));
            
            // Fix label if it starts with pa_ or is different from expected
            if ($current_label && (strpos($current_label, 'pa_') === 0 || $current_label !== $attr_label)) {
                $wpdb->update(
                    $wpdb->prefix . 'woocommerce_attribute_taxonomies',
                    array('attribute_label' => $attr_label),
                    array('attribute_id' => $attribute_id)
                );
                
                // Clear WooCommerce attribute cache
                delete_transient('wc_attribute_taxonomies');
                
            }
        }

        // Register taxonomy for this request
        if (!taxonomy_exists($attr_name)) {
            register_taxonomy($attr_name, 'product', array(
                'labels' => array('name' => $attr_label),
                'hierarchical' => false,
                'show_ui' => false,
                'query_var' => true,
                'rewrite' => false,
            ));
        }
    }

    /**
     * Schedule background processing.
     *
     * @since    1.0.0
     */
    private function schedule_background_processing() {
        wp_schedule_single_event(time(), 'wc_xml_csv_ai_import_process_chunk', array($this->import_id, 0, 5));
    }

    /**
     * Schedule next processing chunk.
     *
     * @since    1.0.0
     * @param    int $offset Next offset
     * @param    int $limit Chunk size
     */
    private function schedule_next_chunk($offset, $limit) {
        $upload_dir = wp_upload_dir();
        $log_file = $upload_dir['basedir'] . '/woo_xml_csv_ai_smart_import_logs/import_debug.log';
        
        // Check if this exact event already exists to prevent duplicates
        $existing = wp_next_scheduled('wc_xml_csv_ai_import_process_chunk', array($this->import_id, $offset, $limit));
        if ($existing) {
            return;
        }
        
        // Also clear any existing events for this import with offset=0 if we're scheduling a higher offset
        if ($offset > 0) {
            $offset0_scheduled = wp_next_scheduled('wc_xml_csv_ai_import_process_chunk', array($this->import_id, 0, $limit));
            if ($offset0_scheduled) {
                wp_unschedule_event($offset0_scheduled, 'wc_xml_csv_ai_import_process_chunk', array($this->import_id, 0, $limit));
            }
        }
        
        // Schedule immediately (time() instead of time()+5) for faster processing
        $result = wp_schedule_single_event(time(), 'wc_xml_csv_ai_import_process_chunk', array($this->import_id, $offset, $limit));
    }

    /**
     * Update import status.
     *
     * @since    1.0.0
     * @param    string $status New status
     */
    private function update_import_status($status) {
        global $wpdb;

        $wpdb->update(
            $wpdb->prefix . 'wc_itp_imports',
            array('status' => $status),
            array('id' => $this->import_id)
        );
    }

    /**
     * Phase 2: Resolve product relationships after all products are imported.
     * Handles: Grouped product children, Upsells, Cross-sells
     * This is called when import completes to link products by SKU.
     *
     * @since    1.0.0
     */
    private function resolve_product_relationships() {
        global $wpdb;
        
        $this->log('info', __('Starting Phase 2: Resolving product relationships...', 'bootflow-product-importer'));
        
        $resolved_count = 0;
        $error_count = 0;
        
        // 1. Resolve Grouped Product Children
        $grouped_products = $wpdb->get_results($wpdb->prepare(
            "SELECT p.ID, pm.meta_value as pending_skus
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
             INNER JOIN {$wpdb->postmeta} pm_import ON p.ID = pm_import.post_id
             WHERE pm.meta_key = '_pending_grouped_skus'
               AND pm_import.meta_key = '_wc_import_id'
               AND pm_import.meta_value = %s
               AND p.post_type = 'product'",
            $this->import_id
        ));
        
        
        foreach ($grouped_products as $grouped) {
            try {
                $product = wc_get_product($grouped->ID);
                if (!$product || !$product instanceof WC_Product_Grouped) {
                    continue;
                }
                
                $sku_list = $grouped->pending_skus;
                $child_ids = $this->resolve_skus_to_ids($sku_list);
                
                if (!empty($child_ids)) {
                    $product->set_children($child_ids);
                    $product->save();
                    
                    // Remove the pending meta
                    delete_post_meta($grouped->ID, '_pending_grouped_skus');
                    
                    // translators: placeholder values
                    $this->log('info', sprintf(__('Resolved grouped product ID %1$d with %2$d children', 'bootflow-product-importer'), $grouped->ID, count($child_ids)));
                    $resolved_count++;
                } else {
                    // translators: placeholder values
                    $this->log('warning', sprintf(__('Could not resolve children for grouped product ID %1$d (SKUs: %2$s)', 'bootflow-product-importer'), $grouped->ID, $sku_list));
                    $error_count++;
                }
            } catch (Exception $e) {
                // translators: placeholder values
                $this->log('error', sprintf(__('Error resolving grouped product ID %1$d: %2$s', 'bootflow-product-importer'), $grouped->ID, $e->getMessage()));
                $error_count++;
            }
        }
        
        // 2. Resolve Upsells
        $upsell_products = $wpdb->get_results($wpdb->prepare(
            "SELECT p.ID, pm.meta_value as pending_skus
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
             INNER JOIN {$wpdb->postmeta} pm_import ON p.ID = pm_import.post_id
             WHERE pm.meta_key = '_pending_upsell_skus'
               AND pm_import.meta_key = '_wc_import_id'
               AND pm_import.meta_value = %s
               AND p.post_type = 'product'",
            $this->import_id
        ));
        
        foreach ($upsell_products as $item) {
            try {
                $product = wc_get_product($item->ID);
                if (!$product) {
                    continue;
                }
                
                $upsell_ids = $this->resolve_skus_to_ids($item->pending_skus);
                
                if (!empty($upsell_ids)) {
                    $product->set_upsell_ids($upsell_ids);
                    $product->save();
                    delete_post_meta($item->ID, '_pending_upsell_skus');
                    $resolved_count++;
                }
            } catch (Exception $e) {
                $error_count++;
            }
        }
        
        // 3. Resolve Cross-sells
        $crosssell_products = $wpdb->get_results($wpdb->prepare(
            "SELECT p.ID, pm.meta_value as pending_skus
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
             INNER JOIN {$wpdb->postmeta} pm_import ON p.ID = pm_import.post_id
             WHERE pm.meta_key = '_pending_crosssell_skus'
               AND pm_import.meta_key = '_wc_import_id'
               AND pm_import.meta_value = %s
               AND p.post_type = 'product'",
            $this->import_id
        ));
        
        foreach ($crosssell_products as $item) {
            try {
                $product = wc_get_product($item->ID);
                if (!$product) {
                    continue;
                }
                
                $crosssell_ids = $this->resolve_skus_to_ids($item->pending_skus);
                
                if (!empty($crosssell_ids)) {
                    $product->set_cross_sell_ids($crosssell_ids);
                    $product->save();
                    delete_post_meta($item->ID, '_pending_crosssell_skus');
                    $resolved_count++;
                }
            } catch (Exception $e) {
                $error_count++;
            }
        }
        
        // translators: placeholder values
        $this->log('info', sprintf(__('Phase 2 completed: %1$d relationships resolved, %2$d errors', 'bootflow-product-importer'), $resolved_count, $error_count));
    }

    /**
     * Phase 3: Sync stock status for all variable products.
     * This must run LAST to ensure WooCommerce hooks don't override our stock status.
     * Uses direct DB queries to bypass all WooCommerce hooks.
     * Public because it's called from shutdown hook.
     *
     * @since    1.0.0
     */
    public function sync_variable_products_stock_status() {
        global $wpdb;
        
        $this->log('info', __('Starting Phase 3: Syncing variable products stock status...', 'bootflow-product-importer'));
        
        // Get all variable products (no prepare needed - no user input)
        $variable_products = $wpdb->get_col(
            "SELECT DISTINCT p.ID
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->term_relationships} tr ON p.ID = tr.object_id
             INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
             INNER JOIN {$wpdb->terms} t ON tt.term_id = t.term_id
             WHERE p.post_type = 'product'
               AND tt.taxonomy = 'product_type'
               AND t.slug = 'variable'
               AND p.post_status = 'publish'"
        );
        
        $synced_count = 0;
        
        foreach ($variable_products as $product_id) {
            // Get all variations for this product
            $children = $wpdb->get_col($wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts} WHERE post_parent = %d AND post_type = 'product_variation'",
                $product_id
            ));
            
            if (empty($children)) {
                continue;
            }
            
            // Check if any variation has instock status
            $placeholders = implode(',', array_fill(0, count($children), '%d'));
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Placeholders dynamically built for IN clause
            $instock_count = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->postmeta} 
                 WHERE post_id IN ({$placeholders}) 
                 AND meta_key = '_stock_status' 
                 AND meta_value = 'instock'",
                array_map('intval', $children)
            ));
            
            $new_stock_status = ($instock_count > 0) ? 'instock' : 'outofstock';
            
            // Direct SQL update - bypass all hooks
            $wpdb->query($wpdb->prepare(
                "UPDATE {$wpdb->postmeta} SET meta_value = %s WHERE post_id = %d AND meta_key = '_stock_status'",
                $new_stock_status,
                $product_id
            ));
            
            $synced_count++;
        }
        
        // translators: placeholder values
        $this->log('info', sprintf(__('Phase 3 completed: %d variable products stock status synced', 'bootflow-product-importer'), $synced_count));
    }

    /**
     * Convert comma-separated SKU list to array of product IDs.
     *
     * @since    1.0.0
     * @param    string $sku_list Comma-separated SKU list
     * @return   array Array of product IDs
     */
    private function resolve_skus_to_ids($sku_list) {
        if (empty($sku_list)) {
            return array();
        }
        
        $skus = array_map('trim', explode(',', $sku_list));
        $ids = array();
        
        foreach ($skus as $sku) {
            if (empty($sku)) {
                continue;
            }
            
            $product_id = wc_get_product_id_by_sku($sku);
            if ($product_id) {
                $ids[] = $product_id;
            } else {
                // translators: placeholder values
                $this->log('warning', sprintf(__('Could not find product with SKU: %s', 'bootflow-product-importer'), $sku));
            }
        }
        
        return $ids;
    }

    /**
     * Handle missing products - products that were in previous import but not in current.
     * This is called when import completes and handle_missing is enabled.
     *
     * @since    1.0.0
     */
    private function handle_missing_products() {
        global $wpdb;
        
        $action = $this->config['missing_action'] ?? 'draft';
        $delete_variations = $this->config['delete_variations'] ?? 1;
        
        // translators: placeholder values
        $this->log('info', sprintf(__('Processing missing products with action: %s', 'bootflow-product-importer'), $action));
        
        // Find all products that:
        // 1. Have _wc_import_id = current import ID (were last updated by this import)
        // 2. Have _wc_import_date OLDER than import start time (not updated in THIS run)
        
        // Get import start time from the import record
        $import = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}wc_itp_imports WHERE id = %d",
            $this->import_id
        ));
        
        if (!$import) {
            return;
        }
        
        // CRITICAL FIX: Use the saved import start time from when this run began
        // This fixes the bug where last_run was from the last chunk, not the import start
        $import_start_option_key = 'wc_import_start_time_' . $this->import_id;
        $import_start_time = get_option($import_start_option_key);
        
        // Fallback to created_at if no saved start time (shouldn't happen in normal flow)
        if (empty($import_start_time)) {
            $import_start_time = $import->created_at;
        } else {
        }
        
        
        // Query for products that belong to this import but weren't updated in this run
        $missing_products = $wpdb->get_results($wpdb->prepare(
            "SELECT p.ID, p.post_title, pm_sku.meta_value as sku, pm_date.meta_value as import_date
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm_import ON p.ID = pm_import.post_id AND pm_import.meta_key = '_wc_import_id'
             LEFT JOIN {$wpdb->postmeta} pm_sku ON p.ID = pm_sku.post_id AND pm_sku.meta_key = '_sku'
             LEFT JOIN {$wpdb->postmeta} pm_date ON p.ID = pm_date.post_id AND pm_date.meta_key = '_wc_import_date'
             WHERE pm_import.meta_value = %s
               AND p.post_type IN ('product', 'product_variation')
               AND p.post_status NOT IN ('trash', 'auto-draft')
               AND (pm_date.meta_value IS NULL OR pm_date.meta_value < %s)",
            $this->import_id,
            $import_start_time
        ));
        
        $count = count($missing_products);
        
        if ($count === 0) {
            $this->log('info', __('No missing products found.', 'bootflow-product-importer'));
            return;
        }
        
        $processed = 0;
        $errors = 0;
        
        foreach ($missing_products as $product) {
            try {
                $product_id = $product->ID;
                $sku = $product->sku ?? 'N/A';
                
                
                // Get product object
                $wc_product = wc_get_product($product_id);
                if (!$wc_product) {
                    continue;
                }
                
                // Check if this is a variation - if parent is being processed, skip variation
                if ($wc_product->is_type('variation')) {
                    // Variations will be handled with their parent
                    continue;
                }
                
                switch ($action) {
                    case 'draft':
                        // Move to draft
                        wp_update_post(array(
                            'ID' => $product_id,
                            'post_status' => 'draft'
                        ));
                        // translators: placeholder values
                        $this->log('info', sprintf(__('Product "%1$s" (SKU: %2$s) moved to draft - no longer in feed.', 'bootflow-product-importer'), $product->post_title, $sku), $sku);
                        break;
                        
                    case 'outofstock':
                        // Mark as out of stock
                        $wc_product->set_stock_status('outofstock');
                        $wc_product->set_manage_stock(true);
                        $wc_product->set_stock_quantity(0);
                        $wc_product->save();
                        // translators: placeholder values
                        $this->log('info', sprintf(__('Product "%1$s" (SKU: %2$s) marked as out of stock - no longer in feed.', 'bootflow-product-importer'), $product->post_title, $sku), $sku);
                        break;
                        
                    case 'backorder':
                        // Allow backorder
                        $wc_product->set_stock_status('onbackorder');
                        $wc_product->set_manage_stock(true);
                        $wc_product->set_stock_quantity(0);
                        $wc_product->set_backorders('yes');
                        $wc_product->save();
                        // translators: placeholder values
                        $this->log('info', sprintf(__('Product "%1$s" (SKU: %2$s) set to backorder - no longer in feed.', 'bootflow-product-importer'), $product->post_title, $sku), $sku);
                        break;
                        
                    case 'trash':
                        // Move to trash
                        wp_trash_post($product_id);
                        // translators: placeholder values
                        $this->log('info', sprintf(__('Product "%1$s" (SKU: %2$s) moved to trash - no longer in feed.', 'bootflow-product-importer'), $product->post_title, $sku), $sku);
                        break;
                        
                    case 'delete':
                        // Permanently delete
                        wp_delete_post($product_id, true);
                        // translators: placeholder values
                        $this->log('warning', sprintf(__('Product "%1$s" (SKU: %2$s) permanently deleted - no longer in feed.', 'bootflow-product-importer'), $product->post_title, $sku), $sku);
                        break;
                }
                
                // Handle variations for variable products
                if ($delete_variations && $wc_product->is_type('variable') && $action !== 'delete') {
                    $variation_ids = $wc_product->get_children();
                    foreach ($variation_ids as $var_id) {
                        $variation = wc_get_product($var_id);
                        if (!$variation) continue;
                        
                        switch ($action) {
                            case 'draft':
                                wp_update_post(array('ID' => $var_id, 'post_status' => 'draft'));
                                break;
                            case 'outofstock':
                                $variation->set_stock_status('outofstock');
                                $variation->set_stock_quantity(0);
                                $variation->save();
                                break;
                            case 'backorder':
                                $variation->set_stock_status('onbackorder');
                                $variation->set_stock_quantity(0);
                                $variation->set_backorders('yes');
                                $variation->save();
                                break;
                            case 'trash':
                                wp_trash_post($var_id);
                                break;
                        }
                    }
                }
                
                $processed++;
                
            } catch (Exception $e) {
                $errors++;
                // translators: placeholder values
                $this->log('error', sprintf(__('Error processing missing product ID %1$d: %2$s', 'bootflow-product-importer'), $product->ID, $e->getMessage()));
            }
        }
        
        // translators: placeholder values
        $this->log('info', sprintf(__('Missing products cleanup completed: %1$d processed, %2$d errors.', 'bootflow-product-importer'), $processed, $errors));
        
        // Clean up the import start time option after processing is complete
        delete_option($import_start_option_key);
    }

    /**
     * Log import message.
     *
     * @since    1.0.0
     * @param    string $type Log type
     * @param    string $message Log message
     * @param    string $sku Product SKU (optional)
     */
    private function log($type, $message, $sku = '') {
        global $wpdb;

        // Don't save debug logs to database - they clutter the UI
        // Debug logs only go to error_log when WP_DEBUG is enabled
        if ($type === 'debug') {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[WC Import Debug] ' . $message);
            }
            return;
        }

        $wpdb->insert(
            $wpdb->prefix . 'wc_itp_import_logs',
            array(
                'import_id' => $this->import_id,
                'level' => $type,  // Changed from log_type to level to match table structure
                'message' => $message,
                'product_sku' => $sku,
                'created_at' => current_time('mysql')
            ),
            array('%d', '%s', '%s', '%s', '%s')
        );
    }

    /**
     * Validate import data.
     *
     * @since    1.0.0
     * @param    array $import_data Import configuration
     */
    private function validate_import_data($import_data) {
        $import_name = $import_data['import_name'] ?? $import_data['name'] ?? '';
        if (empty($import_name)) {
            throw new Exception(esc_html__('Import name is required.', 'bootflow-product-importer'));
        }

        if (empty($import_data['file_path']) || !file_exists($import_data['file_path'])) {
            throw new Exception(esc_html__('Valid file path is required.', 'bootflow-product-importer'));
        }

        if (!in_array($import_data['file_type'], array('xml', 'csv'))) {
            throw new Exception(esc_html__('File type must be XML or CSV.', 'bootflow-product-importer'));
        }
    }

    /**
     * Apply Shipping Class Engine rules to assign shipping class.
     * Evaluates rules top-to-bottom, first matching rule wins.
     *
     * @since    1.0.0
     * @param    WC_Product $product Product object
     * @param    array $product_data Product data array
     * @return   bool True if a shipping class was assigned, false otherwise
     */
    private function apply_shipping_class_engine($product, $product_data) {
        $sc_config = $this->config['field_mapping']['shipping_class_engine'] ?? null;
        
        // Check if shipping class engine is enabled
        if (empty($sc_config) || empty($sc_config['enabled'])) {
            return false;
        }
        
        $rules = $sc_config['rules'] ?? array();
        if (empty($rules)) {
            return false;
        }
        
        $this->log('debug', 'Shipping Class Engine: evaluating ' . count($rules) . ' rules');
        
        $matched_class = '';
        $matched_rule_name = '';
        
        // Separate conditional rules from default
        $conditional_rules = array();
        $default_rule = null;
        
        foreach ($rules as $rule) {
            if (!empty($rule['is_default'])) {
                $default_rule = $rule;
            } else {
                $conditional_rules[] = $rule;
            }
        }
        
        // Evaluate conditional rules first (top-to-bottom, first match wins)
        foreach ($conditional_rules as $rule) {
            if (empty($rule['enabled'])) {
                continue;
            }
            
            $shipping_class = $rule['shipping_class'] ?? '';
            if (empty($shipping_class)) {
                continue;
            }
            
            // Check conditions
            if ($this->check_shipping_rule_conditions($rule, $product_data)) {
                $matched_class = $shipping_class;
                $matched_rule_name = $rule['name'] ?? $rule['id'] ?? 'unnamed';
                $this->log('debug', sprintf('Shipping Class Engine: Rule "%s" matched → class "%s"', $matched_rule_name, $matched_class));
                break;
            }
        }
        
        // If no conditional rule matched, use default
        if (empty($matched_class) && $default_rule) {
            $matched_class = $default_rule['shipping_class'] ?? '';
            $matched_rule_name = 'Default';
        }
        
        // Assign shipping class if we have one
        if (!empty($matched_class)) {
            $shipping_class_slug = sanitize_title($matched_class);
            $shipping_class_term = get_term_by('slug', $shipping_class_slug, 'product_shipping_class');
            
            // Create shipping class if it doesn't exist
            if (!$shipping_class_term || is_wp_error($shipping_class_term)) {
                $new_term = wp_insert_term(
                    $matched_class, // Original name (or slug if no name)
                    'product_shipping_class',
                    array('slug' => $shipping_class_slug)
                );
                if (!is_wp_error($new_term)) {
                    $shipping_class_term = get_term($new_term['term_id'], 'product_shipping_class');
                    $this->log('debug', sprintf('Shipping Class Engine: Created new shipping class "%s"', $matched_class));
                } else {
                    $this->log('error', sprintf('Shipping Class Engine: Failed to create shipping class "%s": %s', $matched_class, $new_term->get_error_message()));
                    return false;
                }
            }
            
            if ($shipping_class_term && !is_wp_error($shipping_class_term)) {
                $product->set_shipping_class_id($shipping_class_term->term_id);
                $this->log('debug', sprintf('Shipping Class Engine: Assigned "%s" (rule: %s) to SKU: %s', 
                    $matched_class, $matched_rule_name, $product_data['sku'] ?? 'unknown'));
                return true;
            }
        }
        
        return false;
    }

    /**
     * Extract the maximum value of a specific field from variation data in raw XML/CSV.
     * Used by Shipping Class Engine to get max variation price/weight when parent values are 0.
     *
     * @since    1.0.0
     * @param    array $raw_data Raw product data (XML/CSV)
     * @param    string $field_type 'price' or 'weight'
     * @return   float Maximum variation value, or 0 if not found
     */
    private function extract_max_variation_value($raw_data, $field_type = 'price') {
        // Try to find variations in raw data using common paths
        $variations_data = null;
        $possible_paths = array(
            'variations.variation',
            'variations',
            'variants.variant',
            'variants',
            'variation',
            'variant'
        );
        
        foreach ($possible_paths as $path) {
            $data = $this->get_nested_value($raw_data, $path);
            if (!empty($data) && is_array($data)) {
                $variations_data = $data;
                break;
            }
        }
        
        if (empty($variations_data)) {
            return 0;
        }
        
        // Normalize: if single variation (associative array), wrap in numeric array
        if (!isset($variations_data[0])) {
            $variations_data = array($variations_data);
        }
        
        // Define field paths to check based on type
        if ($field_type === 'price') {
            $field_paths = array('regular_price', 'price', 'Price', 'RegularPrice', 'sale_price');
        } elseif ($field_type === 'weight') {
            $field_paths = array('weight', 'Weight', 'package_weight');
        } else {
            return 0;
        }
        
        $max_value = 0;
        foreach ($variations_data as $var_data) {
            if (!is_array($var_data)) {
                continue;
            }
            foreach ($field_paths as $field_path) {
                $value = $this->get_nested_value($var_data, $field_path);
                if ($value !== null && $value !== '') {
                    $clean_value = preg_replace('/[^0-9.,]/', '', (string) $value);
                    $clean_value = str_replace(',', '.', $clean_value);
                    $numeric_value = floatval($clean_value);
                    if ($numeric_value > $max_value) {
                        $max_value = $numeric_value;
                    }
                    break; // Found a value for this variation, move to next
                }
            }
        }
        
        return $max_value;
    }

    /**
     * Check if a shipping class rule's conditions are met.
     *
     * @since    1.0.0
     * @param    array $rule Rule configuration
     * @param    array $product_data Product data
     * @return   bool True if conditions match
     */
    private function check_shipping_rule_conditions($rule, $product_data) {
        $conditions = $rule['conditions'] ?? array();
        $logic = $rule['condition_logic'] ?? 'AND';
        
        if (empty($conditions)) {
            return true; // No conditions = always matches
        }
        
        foreach ($conditions as $condition) {
            $type = $condition['type'] ?? '';
            $matches = false;
            
            switch ($type) {
                case 'weight_range':
                    $weight = floatval($product_data['weight'] ?? 0);
                    // For variable products, parent weight may be 0 — use max variation weight instead
                    if ($weight <= 0 && !empty($this->_current_raw_product_data)) {
                        $max_var_weight = $this->extract_max_variation_value($this->_current_raw_product_data, 'weight');
                        if ($max_var_weight > 0) {
                            $weight = $max_var_weight;
                            $this->log('debug', sprintf('Shipping Class Engine: Using max variation weight %.2f (parent weight was 0)', $weight));
                        }
                    }
                    $from = floatval($condition['weight_from'] ?? 0);
                    $to = !empty($condition['weight_to']) ? floatval($condition['weight_to']) : PHP_FLOAT_MAX;
                    $matches = ($weight >= $from && $weight <= $to);
                    break;
                    
                case 'price_range':
                    $price = floatval($product_data['regular_price'] ?? ($product_data['price'] ?? 0));
                    // For variable products, parent price is 0 — use max variation price instead
                    if ($price <= 0 && !empty($this->_current_raw_product_data)) {
                        $max_var_price = $this->extract_max_variation_value($this->_current_raw_product_data, 'price');
                        if ($max_var_price > 0) {
                            $price = $max_var_price;
                            $this->log('debug', sprintf('Shipping Class Engine: Using max variation price %.2f (parent price was 0)', $price));
                        }
                    }
                    $from = floatval($condition['price_from'] ?? 0);
                    $to = !empty($condition['price_to']) ? floatval($condition['price_to']) : PHP_FLOAT_MAX;
                    $matches = ($price >= $from && $price <= $to);
                    break;
                    
                case 'volume_range':
                    $length = floatval($product_data['length'] ?? 0);
                    $width = floatval($product_data['width'] ?? 0);
                    $height = floatval($product_data['height'] ?? 0);
                    $volume = $length * $width * $height;
                    $from = floatval($condition['volume_from'] ?? 0);
                    $to = !empty($condition['volume_to']) ? floatval($condition['volume_to']) : PHP_FLOAT_MAX;
                    $matches = ($volume >= $from && $volume <= $to);
                    break;
                    
                case 'category':
                    $category = $product_data['categories'] ?? '';
                    $operator = $condition['operator'] ?? 'contains';
                    $value = $condition['value'] ?? '';
                    $matches = $this->check_condition_operator($category, $operator, $value);
                    break;
                    
                case 'brand':
                    $brand = $product_data['brand'] ?? '';
                    $operator = $condition['operator'] ?? 'contains';
                    $value = $condition['value'] ?? '';
                    $matches = $this->check_condition_operator($brand, $operator, $value);
                    break;
                    
                case 'xml_field':
                    $field_name = $condition['field'] ?? '';
                    $field_value = $product_data[$field_name] ?? '';
                    $operator = $condition['operator'] ?? 'equals';
                    $value = $condition['value'] ?? '';
                    $matches = $this->check_condition_operator($field_value, $operator, $value);
                    break;
                    
                case 'sku_pattern':
                    $sku = $product_data['sku'] ?? '';
                    $operator = $condition['operator'] ?? 'contains';
                    $value = $condition['value'] ?? '';
                    $matches = $this->check_condition_operator($sku, $operator, $value);
                    break;
            }
            
            // AND logic: all must match (short-circuit on first fail)
            if ($logic === 'AND' && !$matches) {
                return false;
            }
            
            // OR logic: any can match (short-circuit on first success)
            if ($logic === 'OR' && $matches) {
                return true;
            }
        }
        
        // AND: all passed → true. OR: none passed → false
        return ($logic === 'AND');
    }

    /**
     * Auto-assign shipping class based on product dimensions and weight using PHP formula.
     *
     * @since    1.0.0
     * @param    WC_Product $product Product object
     * @param    array $product_data Product data array with dimensions and weight
     */
    private function auto_assign_shipping_class($product, $product_data) {
        // Check if shipping class formula is configured
        $field_mappings = $this->config['field_mapping'] ?? array();
        $shipping_formula = $field_mappings['shipping_class_formula']['formula'] ?? '';
        
        // Skip if no formula configured
        if (empty($shipping_formula)) {
            return;
        }
        
        // Get dimensions and weight
        $weight = !empty($product_data['weight']) ? floatval($product_data['weight']) : 0;
        $length = !empty($product_data['length']) ? floatval($product_data['length']) : 0;
        $width = !empty($product_data['width']) ? floatval($product_data['width']) : 0;
        $height = !empty($product_data['height']) ? floatval($product_data['height']) : 0;
        
        // Skip if no dimensions/weight provided
        if ($weight == 0 && $length == 0 && $width == 0 && $height == 0) {
            return;
        }
        
        try {
            // Execute formula to get shipping class slug
            $shipping_class_slug = $this->execute_shipping_class_formula(
                $shipping_formula,
                $weight,
                $length,
                $width,
                $height
            );
            
            if (empty($shipping_class_slug)) {
                return;
            }
            
            // Get shipping class term by slug
            $shipping_class_term = get_term_by('slug', $shipping_class_slug, 'product_shipping_class');
            
            if ($shipping_class_term && !is_wp_error($shipping_class_term)) {
                // Set shipping class ID
                $product->set_shipping_class_id($shipping_class_term->term_id);
                
                // Log assignment
                if (defined('WP_DEBUG') && WP_DEBUG) { 
                    error_log(sprintf(
                        'Auto-assigned shipping class "%s" (%s) to SKU=%s based on: weight=%skg, dimensions=%s×%s×%scm',
                        $shipping_class_term->name,
                        $shipping_class_slug,
                        $product_data['sku'] ?? '',
                        $weight,
                        $length,
                        $width,
                        $height
                    )); 
                }
            } else {
                // Shipping class doesn't exist - log warning
                if (defined('WP_DEBUG') && WP_DEBUG) { 
                    error_log(sprintf(
                        'WARNING: Shipping class "%s" not found for SKU=%s. Please create it in: WooCommerce → Settings → Shipping → Shipping classes',
                        $shipping_class_slug,
                        $product_data['sku'] ?? ''
                    )); 
                }
            }
        } catch (Exception $e) {
            // Log formula execution error
            if (defined('WP_DEBUG') && WP_DEBUG) { 
                error_log(sprintf(
                    'ERROR: Shipping class formula error for SKU=%s: %s',
                    $product_data['sku'] ?? '',
                    $e->getMessage()
                )); 
            }
        }
    }
    
    /**
     * Execute shipping class formula with provided dimensions and weight.
     *
     * @since    1.0.0
     * @param    string $formula PHP formula code
     * @param    float $weight Product weight
     * @param    float $length Product length
     * @param    float $width Product width
     * @param    float $height Product height
     * @return   string Shipping class slug
     */
    private function execute_shipping_class_formula($formula, $weight, $length, $width, $height) {
        // PRO feature check - Shipping formulas require PRO license
        if (!WC_XML_CSV_AI_Import_Features::is_available('php_processing')) {
            if (isset($this->logger) && $this->logger) {
                $this->logger->log('info', 'Shipping formula blocked - PRO license required');
            }
            return ''; // Return empty without formula processing
        }
        
        // Prepare formula for execution
        $formula = trim($formula);
        
        if (empty($formula)) {
            return '';
        }
        
        // Log formula execution attempt
        if (isset($this->logger) && $this->logger) {
            $this->logger->log(
                'debug',
                'Executing shipping class formula',
                array(
                    'weight' => $weight,
                    'length' => $length,
                    'width' => $width,
                    'height' => $height,
                    'formula_preview' => substr($formula, 0, 100)
                )
            );
        } else {
            if (defined('WP_DEBUG') && WP_DEBUG) { error_log('Executing shipping class formula: weight=' . $weight . ', length=' . $length . ', width=' . $width . ', height=' . $height); }
        }
        
        // Wrap in function for sandboxing with proper error handling
        $wrapped_formula = '
            return (function($weight, $length, $width, $height) {
                try {
                    ' . $formula . '
                } catch (Throwable $e) {
                    return "";
                }
            })(' . var_export($weight, true) . ', ' 
                . var_export($length, true) . ', ' 
                . var_export($width, true) . ', ' 
                . var_export($height, true) . ');
        ';
        
        // Execute formula
        try {
            $result = @eval($wrapped_formula);
            
            if ($result === false) {
                throw new Exception('Formula returned false - possible syntax error');
            }
            
            if (isset($this->logger) && $this->logger) {
                $this->logger->log(
                    'debug',
                    'Shipping class formula result: ' . var_export($result, true),
                    array(
                        'weight' => $weight,
                        'dimensions' => "{$length}x{$width}x{$height}"
                    )
                );
            } else {
                if (defined('WP_DEBUG') && WP_DEBUG) { error_log('Shipping class formula result: ' . var_export($result, true)); }
            }
            
            return is_string($result) ? trim($result) : '';
            
        } catch (Throwable $e) {
            $error_msg = 'Shipping formula error: ' . $e->getMessage();
            
            if (isset($this->logger) && $this->logger) {
                $this->logger->log(
                    'error',
                    $error_msg,
                    array(
                        'formula' => $formula,
                        'weight' => $weight,
                        'length' => $length,
                        'width' => $width,
                        'height' => $height
                    )
                );
            }
            
            if (defined('WP_DEBUG') && WP_DEBUG) { error_log($error_msg . ' | Formula: ' . substr($formula, 0, 200)); }
            
            // Don't throw exception - just return empty and log error
            return '';
        }
    }

    /**
     * Enhanced debug logging with timestamp and context.
     * Logs to both file and database.
     *
     * @param string $message Log message
     * @param array $context Additional context data
     */
    private function log_debug($message, $context = array()) {
        global $wpdb;
        
        // Generate timestamp with milliseconds using WordPress timezone
        $timestamp = current_time('Y-m-d H:i:s') . '.' . sprintf('%03d', floor(microtime(true) * 1000) % 1000);
        
        // Format context as JSON if not empty
        $context_str = !empty($context) ? ' | Context: ' . json_encode($context, JSON_UNESCAPED_UNICODE) : '';
        
        // Log to file in uploads directory
        $upload_dir = wp_upload_dir();
        $log_dir = $upload_dir['basedir'] . '/woo_xml_csv_ai_smart_import_logs';
        if (!file_exists($log_dir)) {
            wp_mkdir_p($log_dir);
        }
        $log_file = $log_dir . '/import_debug.log';
        $log_entry = "[{$timestamp}] {$message}{$context_str}\n";
        if (defined('WP_DEBUG') && WP_DEBUG) { error_log($log_entry, 3, $log_file); }
        
        // Log to database (for admin panel viewing)
        if (isset($this->import_id) && $this->import_id > 0) {
            $table_name = $wpdb->prefix . 'wc_itp_import_logs';
            
            // Check if table exists
            if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") == $table_name) {
                $wpdb->insert(
                    $table_name,
                    array(
                        'import_id' => $this->import_id,
                        'level' => 'debug',
                        'message' => $message,
                        'context' => !empty($context) ? json_encode($context, JSON_UNESCAPED_UNICODE) : null,
                        'created_at' => current_time('mysql')
                    ),
                    array('%d', '%s', '%s', '%s', '%s')
                );
            }
        }
    }
    
    /**
     * Get nested value from array using dot notation.
     *
     * @param array $array Source array
     * @param string $path Dot-notation path (e.g., "variations.variation.price")
     * @return mixed|null Value or null if not found
     */
    private function get_nested_value($array, $path) {
        if (empty($path) || !is_array($array)) {
            return $array;
        }
        
        $keys = explode('.', $path);
        $value = $array;
        
        foreach ($keys as $key) {
            // Handle array notation like [0]
            if (preg_match('/(.+)\[(\d+)\]/', $key, $matches)) {
                $key = $matches[1];
                $index = intval($matches[2]);
                
                if (isset($value[$key]) && is_array($value[$key]) && isset($value[$key][$index])) {
                    $value = $value[$key][$index];
                } else {
                    return null;
                }
            } elseif (isset($value[$key])) {
                $value = $value[$key];
            } else {
                return null;
            }
        }
        
        return $value;
    }
    
    /**
     * Sanitize attribute name for WooCommerce taxonomy.
     *
     * @param string $name Attribute name
     * @return string Sanitized attribute name with pa_ prefix
     */
    private function sanitize_attribute_name($name) {
        $name = trim($name);
        
        // Already has pa_ prefix
        if (strpos($name, 'pa_') === 0) {
            return sanitize_title($name);
        }
        
        // Add pa_ prefix
        return 'pa_' . sanitize_title($name);
    }
    
    /**
     * Ensure attribute taxonomy exists in WooCommerce.
     * Creates the attribute if it doesn't exist.
     *
     * @param string $attr_name Human-readable attribute name (e.g., "Size")
     * @param string $taxonomy_name Taxonomy name with pa_ prefix (e.g., "pa_size")
     * @return bool True if attribute exists or was created
     */
    private function ensure_attribute_taxonomy_exists($attr_name, $taxonomy_name) {
        $log_file = WP_CONTENT_DIR . '/variations_debug.log';
        
        // Remove pa_ prefix for attribute slug
        $attribute_slug = str_replace('pa_', '', $taxonomy_name);
        
        // Check if attribute taxonomy already exists
        if (taxonomy_exists($taxonomy_name)) {
            return true;
        }
        
        // Check if attribute exists in WooCommerce attributes table
        $attribute_id = wc_attribute_taxonomy_id_by_name($attribute_slug);
        
        if ($attribute_id) {
            // Attribute exists but taxonomy not registered - register it
            register_taxonomy($taxonomy_name, 'product', array(
                'hierarchical' => false,
                'labels' => array('name' => $attr_name),
                'show_ui' => false,
                'query_var' => true,
                'rewrite' => false,
            ));
            return true;
        }
        
        // Create new attribute
        $args = array(
            'name' => $attr_name,
            'slug' => $attribute_slug,
            'type' => 'select',
            'order_by' => 'menu_order',
            'has_archives' => false
        );
        
        $result = wc_create_attribute($args);
        
        if (is_wp_error($result)) {
            return false;
        }
        
        // Register the taxonomy immediately so we can use it
        register_taxonomy($taxonomy_name, 'product', array(
            'hierarchical' => false,
            'labels' => array('name' => $attr_name),
            'show_ui' => false,
            'query_var' => true,
            'rewrite' => false,
        ));
        
        
        return true;
    }
    
    /**
     * Update parent product with auto-detected attributes.
     *
     * @param int $product_id Parent product ID
     * @param array $variation_attrs_map Map of attributes discovered
     * @param array $variations_data All variations data
     * @param string $auto_attributes_path Path to attributes in variation data
     * @param WC_Product $parent_product Parent product object
     */
    private function update_parent_with_auto_attributes($product_id, $variation_attrs_map, $variations_data, $auto_attributes_path, $parent_product) {
        $log_file = WP_CONTENT_DIR . '/variations_debug.log';
        
        if (empty($variation_attrs_map)) {
            return;
        }
        
        // Collect all unique values for each attribute from all variations
        $all_values = array();
        foreach ($variation_attrs_map as $attr_name => $attr_cfg) {
            $all_values[$attr_name] = array();
        }
        
        foreach ($variations_data as $var_data) {
            $attrs_data = $this->get_nested_value($var_data, $auto_attributes_path) ?? $var_data;
            
            if (!is_array($attrs_data)) {
                continue;
            }
            
            foreach ($variation_attrs_map as $attr_name => $attr_cfg) {
                $source_key = $attr_cfg['source_key'] ?? strtolower(str_replace(' ', '_', $attr_name));
                $value = $attrs_data[$source_key] ?? null;
                
                if (!empty($value) && is_string($value)) {
                    $all_values[$attr_name][$value] = $value;
                }
            }
        }
        
        // Build WooCommerce product attributes array
        $product_attributes = array();
        
        foreach ($variation_attrs_map as $attr_name => $attr_cfg) {
            $taxonomy_name = $attr_cfg['taxonomy'];
            $values = array_values($all_values[$attr_name] ?? array());
            
            if (empty($values)) {
                continue;
            }
            
            // Add terms to taxonomy
            foreach ($values as $term_value) {
                if (!term_exists($term_value, $taxonomy_name)) {
                    $term_result = wp_insert_term($term_value, $taxonomy_name);
                    if (is_wp_error($term_result)) {
                    }
                }
            }
            
            // Create attribute for product
            $product_attributes[$taxonomy_name] = array(
                'name' => $taxonomy_name,
                'value' => '',
                'is_visible' => 1,
                'is_variation' => 1,
                'is_taxonomy' => 1,
            );
            
            // Set object terms (link product to attribute values)
            wp_set_object_terms($product_id, $values, $taxonomy_name);
            
        }
        
        // Save attributes to product
        update_post_meta($product_id, '_product_attributes', $product_attributes);
        
    }
}