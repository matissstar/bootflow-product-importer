<?php
/**
 * License stub for FREE version
 * Returns 'free' tier and upgrade URL, no API calls
 */
if (!defined('WPINC')) {
    die;
}

class WC_XML_CSV_AI_Import_License {
    public static function get_tier() {
        return 'free';
    }
    
    public static function is_valid() {
        return false;
    }
    
    public static function is_pro_plugin() {
        return false;
    }
    
    public static function get_license_key() {
        return '';
    }
    
    public static function get_license_data() {
        return array();
    }
    
    public static function get_license_status() {
        return '';
    }
    
    public static function can($feature) {
        return false;
    }
    
    public static function is_at_least($minimum_tier) {
        return $minimum_tier === 'free';
    }
    
    public static function get_limit($feature, $default = 0) {
        return $default;
    }
    
    public static function get_upgrade_url() {
        return 'https://bootflow.io/woocommerce-xml-csv-importer/';
    }
    
    public static function get_tier_name($tier = null) {
        return 'Free';
    }
    
    public static function clear_cache() {}
    
    public static function get_all_features() {
        return array();
    }
    
    public static function render_upgrade_notice($feature_name = '') {
        return '<div class="notice notice-info"><p>' . esc_html__('Upgrade to PRO for this feature.', 'bootflow-product-importer') . ' <a href="https://bootflow.io/pricing" target="_blank">bootflow.io/pricing</a></p></div>';
    }
    
    public static function activate_license($license_key) {
        return array('success' => false, 'message' => __('License activation is only available in the Pro version.', 'bootflow-product-importer'));
    }
    
    public static function deactivate_license() {
        return array('success' => false, 'message' => __('License deactivation is only available in the Pro version.', 'bootflow-product-importer'));
    }
    
    public static function maybe_show_license_notice() {}
}

function wc_xml_csv_ai_get_tier() {
    return 'free';
}
