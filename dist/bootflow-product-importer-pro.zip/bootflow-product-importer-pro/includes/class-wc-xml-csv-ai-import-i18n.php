<?php
/**
 * Define the internationalization functionality.
 *
 * @since      1.0.0
 * @package    WC_XML_CSV_AI_Import
 * @subpackage WC_XML_CSV_AI_Import/includes
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Define the internationalization functionality.
 * Supports admin language override via user meta.
 */
class WC_XML_CSV_AI_Import_i18n {

    /**
     * Supported locales with their native names.
     *
     * @var array
     */
    private static $supported_locales = array(
        'en_US' => 'English',
        'lv'    => 'Latviešu',
        'es_ES' => 'Español',
        'de_DE' => 'Deutsch',
        'fr_FR' => 'Français',
        'pt_BR' => 'Português (BR)',
        'ja'    => '日本語',
        'it_IT' => 'Italiano',
        'nl_NL' => 'Nederlands',
        'ru_RU' => 'Русский',
        'zh_CN' => '简体中文',
        'pl_PL' => 'Polski',
        'tr_TR' => 'Türkçe',
        'sv_SE' => 'Svenska',
        'id_ID' => 'Indonesia',
        'ar'    => 'العربية',
    );

    /**
     * Get supported locales.
     *
     * @return array
     */
    public static function get_supported_locales() {
        return self::$supported_locales;
    }

    /**
     * Get the active locale for admin UI.
     * Priority: user override > WP locale > en_US
     *
     * @return string
     */
    public static function get_admin_locale() {
        $user_locale = get_user_meta(get_current_user_id(), 'bootflow_admin_language', true);
        
        if ($user_locale && $user_locale !== 'auto' && array_key_exists($user_locale, self::$supported_locales)) {
            return $user_locale;
        }
        
        // Use WP locale
        $wp_locale = get_locale();
        if (array_key_exists($wp_locale, self::$supported_locales)) {
            return $wp_locale;
        }
        
        // Fallback to English
        return 'en_US';
    }

    /**
     * Load the plugin text domain for translation.
     *
     * @since    1.0.0
     */
    public function load_plugin_textdomain() {
        // Check for admin locale override
        if (is_admin()) {
            $admin_locale = self::get_admin_locale();
            if ($admin_locale && $admin_locale !== 'en_US') {
                // Override locale for this plugin's textdomain
                add_filter('plugin_locale', function($locale, $domain) use ($admin_locale) {
                    if ($domain === 'bootflow-product-importer') {
                        return $admin_locale;
                    }
                    return $locale;
                }, 10, 2);
            }
        }

        // WP.org compliance: text domain must match plugin slug
        // phpcs:ignore PluginCheck.CodeAnalysis.DiscouragedFunctions.load_plugin_textdomainFound -- Required for development/non-WP.org translation loading
        load_plugin_textdomain(
            'bootflow-product-importer',
            false,
            dirname(dirname(plugin_basename(__FILE__))) . '/languages/'
        );
    }

    /**
     * Handle AJAX language switch.
     */
    public static function ajax_switch_language() {
        check_ajax_referer('bootflow_switch_language', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permission denied');
        }
        
        $locale = sanitize_text_field($_POST['locale'] ?? '');
        
        if ($locale !== 'auto' && !array_key_exists($locale, self::$supported_locales)) {
            wp_send_json_error('Invalid locale');
        }
        
        update_user_meta(get_current_user_id(), 'bootflow_admin_language', $locale);
        wp_send_json_success(array('locale' => $locale));
    }
}